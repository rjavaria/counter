package au.com.alu.oss.util.text.perllike;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Miscellaneous functions, including many functions inspired by equivalent perl functions.
 * 
 * @author rtorkel
 *
 */
public class Misc
{
    private static final String[] NO_STRINGS = {};
    
    /**
     * Corresponds to Perl split, with some small differences. You can either not match the
     * separators at all or match complete separators.
     * <p>
     * The other behaviour concerns strange, undocumented (as far as I can tell) and inexplicable
     * perl behaviour. Normally, perl split
     * will return an empty string for the absence of a gap between sucessive separators. For
     * example, split /;/, "a;;b" will return three elements, "a", "" and "b". But "a;b;;" will
     * return just "a" and "b" and no "" as the third token which the author of this function
     * (Rasmus Torkel) finds strange. So, this function will return "a", "b" and "" for "a;b;;"
     * with separator ";".
     * @param separatorPatternStr Used to make a Java pattern. If you want to match the separators
     *                            as well as the separated tokens, put parentheses around the
     *                            pattern expression to match the whole expression.
     *                            However, do not put multiple pairs of parentheses or put
     *                            parentheses around only part of the separator.
     * @param s the string to be split
     * @return
     */
    public static String[]
    split(String separatorPatternStr,
          String s)
    {
        ArrayList al = new ArrayList();
        split(separatorPatternStr, s, al);
        return (String[])al.toArray(NO_STRINGS);
    }
    
    private static void
    split(String    separatorPatternStr,
          String    s,
          ArrayList al)
    {
        if (s.length() == 0)
        {
            return;
        }
        Pattern fullPattern = Pattern.compile("^(.*?)" + separatorPatternStr + "(.*\\s*)$");
        Matcher matcher = fullPattern.matcher(s);
        if (matcher.matches())
        {
            int groupCount = matcher.groupCount();
            for (int i = 1; i < groupCount; i++)
            {
                String group = matcher.group(i);
                al.add(group);
            }
            String remainder = matcher.group(groupCount);
            split(separatorPatternStr, remainder, al);
        }
        else
        {
            al.add(s);
        }
    }
    
    public static String
    join(String   separator,
         String[] args)
    {
        StringBuffer buf = new StringBuffer(100);
        for (int i = 0; i < args.length; i++)
        {
            if (i > 0)
            {
                buf.append(separator);
            }
            buf.append(args[i]);
        }
        return buf.toString();
    }
    
    public static String
    pad(String arg,
        int    argWidth)
    {
        boolean padLeft = true;
        if (argWidth < 0)
        {
            padLeft = false;
            argWidth = 0 - argWidth;
        }
        StringBuffer buf = new StringBuffer(argWidth);
        int padLength = argWidth - arg.length();
        if (padLeft && padLength > 0)
        {
            appendSpaces(buf, padLength);
        }
        buf.append(arg);
        if (!padLeft && padLength > 0)
        {
            appendSpaces(buf, padLength);
        }
        return buf.toString();
    }
    
    public static String
    pad(int arg,
        int argWidth)
    {
        return pad("" + arg, argWidth);
    }
    
    public static String
    pad(long arg,
        int  argWidth)
    {
        return pad("" + arg, argWidth);
    }
    
    private static void
    appendSpaces(StringBuffer buf,
                 int          spaceQty)
    {
        for (int i = 0; i < spaceQty; i++)
        {
            buf.append(" ");
        }
    }
}
