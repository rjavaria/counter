package com.nokia.oss.mdf.rda.ldma.reader;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.nokia.oss.mdf.rda.ldma.common.LdmaConstants;

public class CSVReader {
	
	public DataFileMap readFile(String fileName) {
		
		final String METHOD = "DataFileMap::readFile#";
		System.out.println("Reading data file : "+fileName);
		DataFileMap dataFMap = new DataFileMap();
		
		try {
			BufferedReader reader = new BufferedReader(new FileReader(fileName));
			
			String line = "";
			 try {
				int linenum = 0;
				List<String> columnList = new ArrayList<>();
				while ((line = reader.readLine()) != null) 
				 {
					String key = LdmaConstants.ROW + linenum;
					line.trim();
					if(linenum == 0) {
						String[] headers = line.split(",");
						for(String header : headers) {
							columnList.add(header);
						}
					}
					else {
						dataFMap.addRow(key, columnList, line);
			  		}
					linenum ++;
				 }
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return dataFMap;
	}
}
	
