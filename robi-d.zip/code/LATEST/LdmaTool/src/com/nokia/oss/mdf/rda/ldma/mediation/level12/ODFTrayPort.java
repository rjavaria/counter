package com.nokia.oss.mdf.rda.ldma.mediation.level12;

import java.util.Map;

import com.nokia.oss.mdf.rda.ldma.common.LdmaConstants;
import com.nokia.oss.mdf.rda.ldma.mediation.entity.EntityElement;

public class ODFTrayPort extends EntityElement {

	public ODFTrayPort(Map<String, String> rowMap, String portId) {
		super(rowMap, portId);
	}
	
	@Override
	protected String constructName() {
		StringBuilder builder = new StringBuilder();
		builder.append(getRowData().get(LdmaConstants.Level12FILE1.COLUMN_A));
		builder.append(LdmaConstants.HYPHEN);
		builder.append(LdmaConstants.Level12EntityType.ODF);
		builder.append(LdmaConstants.HYPHEN);
		builder.append(getRowData().get(LdmaConstants.Level12FILE1.COLUMN_C));
		builder.append(LdmaConstants.SLASH);
		builder.append(getRowData().get(LdmaConstants.Level12FILE1.COLUMN_D));
		builder.append(LdmaConstants.SLASH);
		builder.append(this.getId());
		return builder.toString();
	}

	@Override
	protected String constructType() {
		return LdmaConstants.Level12EntityType.ODF_TRAYPORT;
	}
}
