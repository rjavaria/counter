package com.nokia.oss.mdf.rda.ldma.mediation.level12;

import java.util.Map;

import com.nokia.oss.mdf.rda.ldma.common.LdmaConstants;
import com.nokia.oss.mdf.rda.ldma.mediation.entity.EntityElement;

public class ODFTray extends EntityElement {

	public ODFTray(Map<String, String> rowMap) {
		super(rowMap);
	}
	
	@Override
	protected String constructName() {
		StringBuilder builder = new StringBuilder();
		builder.append(getRowData().get(LdmaConstants.Level12FILE1.COLUMN_A));
		builder.append(LdmaConstants.HYPHEN);
		builder.append(LdmaConstants.Level12EntityType.ODF);
		builder.append(LdmaConstants.HYPHEN);
		builder.append(getRowData().get(LdmaConstants.Level12FILE1.COLUMN_C));
		builder.append(LdmaConstants.SLASH);
		builder.append(getRowData().get(LdmaConstants.Level12FILE1.COLUMN_D));
		return builder.toString();
	}

	@Override
	protected String constructType() {
		return LdmaConstants.Level12EntityType.ODF_TRAY;
	}
}