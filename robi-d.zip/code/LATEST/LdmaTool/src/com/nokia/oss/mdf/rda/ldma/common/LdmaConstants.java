package com.nokia.oss.mdf.rda.ldma.common;

public final class LdmaConstants {
	
	public final static String ROW = "row";
	public final static String HYPHEN = "-";
	public final static String SLASH = "/";
	
	public static class OperationType {
		public final static String INSERT = "Insert";
		public final static String UPDATE = "Update";
		public final static String DELETE = "Delete";
	}
	
	public static class LevelType {
		public final static String LEVEL12 = "Level12";
		public final static String LEVEL3 = "Level3";
		public final static String ALL = "AllLevels";
	}
	
	public static class Level12FILE1 {
		public final static String COLUMN_A = "Site Code";
		public final static String COLUMN_B = "Site Name";
		public final static String COLUMN_C = "ODF Number";
		public final static String COLUMN_D = "Tray No.";
		public final static String COLUMN_E = "Ports";
	}
	
	public static class Level12EntityType {
		public final static String ODF = "ODF";
		public final static String ODF_CHASSIS = "ODF Chassis";
		public final static String ODF_TRAY = "ODF Tray";
		public final static String ODF_TRAYPORT = "ODF Tray Port";
		public final static String ODF_PORT = "ODF Port";
	}
}
