package com.nokia.oss.mdf.rda.ldma.mediation.entity;

import java.util.HashMap;
import java.util.Map;

import com.nokia.oss.mdf.rda.ldma.reader.DataFileMap;

public abstract class EntityComponent implements IEntityComponent {

	private Map<String, String> rowData;
	private String name;
	private String type;
	Map<String, String> features = new HashMap<String, String>();
	
	public EntityComponent(Map<String, String> rowMap) {
		this.rowData = rowMap;
		name = getName();
		type = getType();
		//features = getFeatures();
	}
	
	@Override
	public void createAll(Map<String, DataFileMap> fileMaps) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void createAll(DataFileMap fileMap) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void create(Map<String, String> fileMap) {
		// TODO Auto-generated method stub
		
	}
	
	protected abstract String  getName(); 
	protected abstract String  getType(); 
	
	protected Map<String, String> getRowData() {
		return rowData;
	}
}
