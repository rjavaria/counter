package com.nokia.oss.mdf.rda.ldma.reader;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DataFileMap {

	private HashMap<String, Map<String, String>> dataFileMap = null;
	public DataFileMap() {
		dataFileMap = new HashMap<String, Map<String,String>>();
	}
	
	/** 
	 * @param key (ex row0, row1)
	 * @param columnList (List of A,B,C)
	 * @param line (each line from CSV)
	 */
	public void addRow(String key, List<String> columnList, String line) {
		Map<String, String> rowMap = new HashMap<String, String>();
		String[] tokens = line.split(",");
		int index = 0;
		for(String token : tokens) {
			rowMap.put(columnList.get(index), token);
			index ++;
		}
		dataFileMap.put(key, rowMap);
	}
	
	/**
	 * 
	 * @param key
	 * @return row as map
	 */
	public Map<String, String> getRow(String key) {
		return dataFileMap.get(key);
	}
	
	public int getNumberOfRows() {
		return dataFileMap.size();
	}
}