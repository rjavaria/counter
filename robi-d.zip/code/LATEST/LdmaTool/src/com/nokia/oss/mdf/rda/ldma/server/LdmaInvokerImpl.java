package com.nokia.oss.mdf.rda.ldma.server;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import com.alu.oss.mdf.rda.metadata.delta.DeltaEntity;
import com.nokia.oss.mdf.rda.ldma.builder.LdmaModelFactory;
import com.nokia.oss.mdf.rda.ldma.common.LdmaConstants;
import com.nokia.oss.mdf.rda.ldma.common.LdmaException;
import com.nokia.oss.mdf.rda.ldma.context.ILdmaContext;
import com.nokia.oss.mdf.rda.ldma.context.L12LdmaContext;
import com.nokia.oss.mdf.rda.ldma.reader.CSVReader;
import com.nokia.oss.mdf.rda.ldma.reader.DataFileMap;

public class LdmaInvokerImpl implements ILdmaInvoker {
	@Override
	public void execute(String level, String operation) 
				throws LdmaException {
		final String METHOD = "LdmaInvokerImpl:execute#";
		
		System.out.println(METHOD +"Executing...");
		ILdmaContext context = null;
		if(LdmaConstants.LevelType.LEVEL12.equals(level)) {
			String file = "C:\\Data\\Site with ODF Tray Port Into.csv";
			CSVReader reader = new CSVReader();
			DataFileMap fileMap = reader.readFile(file);
			
			Map<String, DataFileMap> filesMap = new HashMap<String, DataFileMap>();
			filesMap.put(file, fileMap);
			context = new L12LdmaContext(level, operation, filesMap);
			DeltaEntity entity = LdmaModelFactory.getInstance().create(context);
			
			//generate xml from DeltaEntity
			try {
				JAXBContext jaxbContext = JAXBContext.newInstance(DeltaEntity.class);
				Marshaller m = jaxbContext.createMarshaller();
				m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
				//m.marshal(entity, System.out);
				System.out.println(METHOD +"Successfully generated xml");
				m.marshal(entity, new File("C:\\Data\\output.xml"));
			} catch (JAXBException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new LdmaException(e.getMessage());
			}
		}
	}
}
