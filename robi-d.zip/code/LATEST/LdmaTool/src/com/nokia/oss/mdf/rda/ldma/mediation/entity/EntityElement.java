package com.nokia.oss.mdf.rda.ldma.mediation.entity;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public abstract class EntityElement {
	
	private Map<String, String> rowData;
	private String name;
	private String id;
	private String type;
	Map<String, String> features = new HashMap<String, String>();
	
	public EntityElement(Map<String, String> rowMap) {
		this.rowData = rowMap;
		this.name = constructName();
		this.type = constructType();
		//features = getFeatures();
	}
	
	public EntityElement(Map<String, String> rowMap, String id) {
		this.rowData = rowMap;
		this.id = id;
		this.name = constructName();
		this.type = constructType();
		//features = getFeatures();
	}
	
	protected abstract String  constructName(); 
	protected abstract String  constructType(); 
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Map<String, String> getFeatures() {
		return features;
	}

	public void setFeatures(Map<String, String> features) {
		this.features = features;
	}

	public void setRowData(Map<String, String> rowData) {
		this.rowData = rowData;
	}

	protected Map<String, String> getRowData() {
		return rowData;
	}
	
	protected void add(List<EntityElement> list) {
		Iterator<EntityElement> iter = list.iterator();
		
		boolean bExist = false;
		
		while(iter.hasNext()) {
			EntityElement entity = iter.next();
			String entityName = entity.getName();
			if(this.name.equals(entityName)) {
				bExist = true;
				break;
			}
		}
		
		if(!bExist) {
			list.add(this);
		}
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("{");
		builder.append("name : "+this.name);
		builder.append(", ");
		builder.append("type : "+this.type);
		builder.append("}\n");
		return builder.toString();
	}
}
