package com.nokia.oss.mdf.rda.ldma.mediation.entity;

import java.util.List;
import java.util.Map;

import com.nokia.oss.mdf.rda.ldma.reader.DataFileMap;

public interface IEntityComponent {
	public void createAll(Map<String, DataFileMap> fileMaps);
	public void createAll(DataFileMap fileMap);
	public void create(Map<String, String> rowMap);
	
	public Map<String, List<EntityElement>> getAll();
	public String printComponent(String name);
}
