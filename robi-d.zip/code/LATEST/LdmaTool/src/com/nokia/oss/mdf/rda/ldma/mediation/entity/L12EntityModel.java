package com.nokia.oss.mdf.rda.ldma.mediation.entity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.nokia.oss.mdf.rda.ldma.common.LdmaConstants;
import com.nokia.oss.mdf.rda.ldma.mediation.level12.ODFChassis;
import com.nokia.oss.mdf.rda.ldma.mediation.level12.ODFTray;
import com.nokia.oss.mdf.rda.ldma.mediation.level12.ODFTrayPort;
import com.nokia.oss.mdf.rda.ldma.reader.DataFileMap;

public class L12EntityModel implements IEntityComponent {

	private String siteCode;
	
	private Map<String, List<EntityElement>> component = new HashMap<>();
	private List<EntityElement> chassisList = new ArrayList<>();
	private List<EntityElement> trayList = new ArrayList<>();
	private List<EntityElement> trayPortList = new ArrayList<>();

	public L12EntityModel(String siteCode) {
		this.siteCode = siteCode;
		component.put(LdmaConstants.Level12EntityType.ODF_CHASSIS, chassisList);
		component.put(LdmaConstants.Level12EntityType.ODF_TRAY, trayList);
		component.put(LdmaConstants.Level12EntityType.ODF_TRAYPORT, trayPortList);
	}
	
	@Override
	public void createAll(Map<String, DataFileMap> fileMaps) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void createAll(DataFileMap fileMap) {
		int numRows = fileMap.getNumberOfRows();		
		for(int i=0; i<numRows; i++) {
			Map<String, String> rowMap = fileMap.getRow(LdmaConstants.ROW+(i+1));
			String siteCode = rowMap.get(LdmaConstants.Level12FILE1.COLUMN_A);
			if(this.siteCode.equals(siteCode)) {
				create(rowMap);
			}
		}
	}

	@Override
	public void create(Map<String, String> rowMap) {
		EntityElement odfChassis = new ODFChassis(rowMap);
		odfChassis.add(chassisList);
		
		EntityElement odfTray = new ODFTray(rowMap);
		odfTray.add(trayList);
		
		String numPorts = rowMap.get(LdmaConstants.Level12FILE1.COLUMN_E);
		int portCounts = Integer.parseInt(numPorts);
		for(int i=1; i<=portCounts; i++) {
			EntityElement odfTrayPort = new ODFTrayPort(rowMap, String.valueOf(i));
			odfTrayPort.add(trayPortList);
		}
	}
	
	@Override
	public Map<String, List<EntityElement>> getAll() {
		return component;
	}
	
	@Override
	public String printComponent(String name) {
		StringBuilder builder = new StringBuilder();
		
		Set<String> keys = component.keySet();
		Iterator<String> iter = keys.iterator();
		builder.append("====== "+name +" ======\n");
		while(iter.hasNext())
		{
			String key = iter.next();
			List<EntityElement> entites = component.get(key);
			Iterator<EntityElement> iterEntites = entites.iterator();
			while(iterEntites.hasNext()) {
				EntityElement entity = iterEntites.next();
				builder.append(entity.toString());
			}
		}
		builder.append("=====================");
		return builder.toString();
	}
	
	public String getSiteCode() {
		return siteCode;
	}

	public void setSiteCode(String siteCode) {
		this.siteCode = siteCode;
	}

	public List<EntityElement> getChassisList() {
		return chassisList;
	}

	public void setChassisList(List<EntityElement> chassisList) {
		this.chassisList = chassisList;
	}
}
