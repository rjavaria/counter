package com.alu.oss.mdf.rda.metadata.sure;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.NONE)
public class StatusEntity extends Entity{
	
	private static final long serialVersionUID = 1L;

	@XmlElement(name = "Value")
	private String value;

	public StatusEntity() {
		super(EntityType.STATUS);
	}

	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
	
	@Override
	public void setName(String name)
	{
		this.value = name;

	}
	
	@Override
	public String getName()
	{
		return this.value;
	}
	
	
	@Override
    public boolean equals(Object obj)
	{
		if (this == obj) return true;
        if ( !(obj instanceof StatusEntity) ) return false;

        final StatusEntity castObj =(StatusEntity) obj;

        if ( castObj.getName() != null){
        	if ( castObj.getValue().equals(getValue())) return true;
        }
	        
        return false;
	}
	
	@Override
	public List<String> getComparableAttributes() {
		return new ArrayList<String>(Arrays.asList("value", "type", "discoveredName"));
	}

	@Override
	public StatusEntity clone()
	{
		StatusEntity clone = new StatusEntity();
		clone.setId(id);
		clone.setName(name);
		clone.setType(type);
		clone.setTemplate(template);
		clone.setState(state);
		clone.setStatus(status);
		clone.setFeatureEntities(featureEntities);
		clone.setDiscoveredName(discoveredName);
		clone.setNeName(neName);
		clone.setSequence(sequence);
		clone.setReconciliationGroup(reconciliationGroup);
		clone.setReconParents(reconParents);
		clone.setRoots(roots);
		
		clone.setValue(value);
		
		return clone;
	}
	
	@Override
	public StatusEntity cloneWithoutParents()
	{
		return this.clone();
	}
}
