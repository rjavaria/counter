package com.alu.oss.mdf.rda.metadata.sure;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.bind.annotation.*;

import com.alu.oss.mdf.rda.metadata.RDAMetadata;
import com.alu.oss.mdf.rda.metadata.sure.nm.NMEntityFactory;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
		"id",
		"name",
	    "discoveredName",
	    "neName",
        "type",
		"template",
	    "featureEntities",
	    "state",
	    "status"
    })
public class Entity implements RDAMetadata, Comparable<Entity>
{
	
	private static final long serialVersionUID = -5787512318099139306L;

	@XmlElement(name="id")
	protected  Object id;
	
	@XmlElement(name="Name")
	protected String name;

	@XmlElement(name="Type", required=false)
	protected String type;
	
	@XmlElement(name="Template", required=false)
	protected String template;
	
	@XmlElement(name="State", required=false)
	protected String state;
	
	@XmlElement(name="Status", required=false)
	protected String status;
	
	@XmlElementWrapper(name="Features", required=false)
	@XmlElement(name="Feature", required=false)
	protected List<FeatureEntity> featureEntities = new ArrayList<FeatureEntity>();
	
	@XmlTransient
	protected String sequence;
	
	@XmlElement(name="DiscoveredName", required=false)
	protected String discoveredName;
	
	@XmlElement(name="NeName", required=false)
	protected String neName;

	@XmlTransient
	final protected EntityType entityType;
	
	@XmlTransient
	protected ReconciliationGroup reconciliationGroup = ReconciliationGroup.INFRASTRUCTURE;
	
	@XmlTransient
	protected List<Entity> reconParents = new ArrayList<Entity>();
	
	@XmlTransient
	protected List<String> roots = new ArrayList<String>();
	
	//Constructors
	public Entity()
	{
		this.entityType = EntityType.UNKNOWN;
	}
	
	public Entity(EntityType entityType)
	{
		this.entityType = entityType;
	}
	
	//getters and setters
	public Object getId(){
		return id;
	}
	
	public void setId(Object id){
		this.id = id;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getTemplate() {
		return template;
	}

	public void setTemplate(String template) {
		this.template = template;
	}

	public List<FeatureEntity> getFeatureEntities() {
		return featureEntities;
	}

	public void setFeatureEntities(List<FeatureEntity> featureEntities) {
		this.featureEntities = featureEntities;
	}

	public EntityType getEntityType() {
		return entityType;
	}
	
	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	public String getSequence() {
		return sequence;
	}

	public void setSequence(String sequence) {
		this.sequence = sequence;
	}
	
	public ReconciliationGroup getReconciliationGroup() {
		return reconciliationGroup;
	}

	public void setReconciliationGroup(ReconciliationGroup reconciliationGroup) {
		this.reconciliationGroup = reconciliationGroup;
	}
	
	public String getNeName() {
		return neName;
	}

	public void setNeName(String neName) {
		this.neName = neName;
	}


	public List<Entity> getReconParents()
	{
		return reconParents;
	}
	
	public void setReconParents(List<Entity> reconParents)
	{
		this.reconParents = reconParents;
	}
	
	public void setReconParents(EntityType parentEntityType, List<String> parentNames, HashMap<String, ReconciliationGroup> entitiesMap)
	{
		for(String parentName:parentNames)
		{
			setReconParent(parentEntityType, parentName, entitiesMap);
		}
	}
	
	public void setReconParent(EntityType parentEntityType, String parentName, HashMap<String, ReconciliationGroup> entitiesMap)
	{
		ReconciliationGroup parentReconGroup = entitiesMap.get(parentEntityType+":"+parentName);
		
		Entity reconParent = null;
		try {
			reconParent = NMEntityFactory.getRdaMetaEntity(parentEntityType, parentName);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(reconParent != null)
			if(!this.reconParents.contains(reconParent))
				if(parentReconGroup != null && this.getReconciliationGroup() == parentReconGroup)
					this.reconParents.add(reconParent);
	}
	
	public List<String> getRoots() {
		return roots;
	}

	public void setRoots(List<String> roots) 
	{
		for(String root:roots)
		{
			if(!this.roots.contains(root))
				this.roots.add(root);
		}
	}

	public void setRoot(String root) {
		if(!this.roots.contains(root))
			this.roots.add(root);
	}

	//Overridden methods
	@Override
    public boolean equals(Object obj)
	{
		if (this == obj) return true;
        if ( !(obj instanceof Entity) ) return false;

        final Entity castObj = (Entity) obj;

        if ( castObj.getName() != null && castObj.getEntityType() != null)
        {
        	if ( castObj.getName().equals(getName()) && 
        			castObj.getEntityType() == getEntityType())//checking the EntityType because cannot perform exact type cast here.  
        		return true;
        }
	        
        return false;

	}
	
	@Override
	public int hashCode()
	{
		if( getName() != null && getEntityType() != null)
		{
			return (getEntityType()+getName()).hashCode();
		}
		else 
		{
			return super.hashCode();
		}
	}
		
	public int compareTo(Entity o) 
	{
		try
		{
			int sequence_this = Integer.parseInt(getSequence());
			int sequence_other = Integer.parseInt(o.getSequence());
		
			return sequence_this - sequence_other;
		}catch(NumberFormatException e)
		{
			return 0;
		}
	}
	
	@Override
	public String toString() 
	{
		return getName();
	}
	
	@Override
	public Entity clone()
	{
		Entity clone = new Entity(entityType);
		clone.setId(id);
		clone.setName(name);
		clone.setType(type);
		clone.setTemplate(template);
		clone.setState(state);
		clone.setStatus(status);
		clone.setFeatureEntities(featureEntities);
		clone.setDiscoveredName(discoveredName);
		clone.setNeName(neName);
		clone.setSequence(sequence);
		clone.setReconciliationGroup(reconciliationGroup);
		clone.setReconParents(reconParents);
		clone.setRoots(roots);
		
		return clone;
	}
	
	//Business methods
	public Entity cloneWithoutParents()
	{		
		return this.clone();
	}
	
	public Entity cloneWithoutParent(Entity parentEntity)
	{		
		return this.clone();
	}
	
	public void removeBrokenAssociations(NetworkEntity networkEntity) 
	{
	}
	
	public List<String> getComparableAttributes()
	{
		return new ArrayList<String>();
	}

	public List<Entity> getParents()
	{
		return new ArrayList<Entity>();
	}

	public List<Entity> getParents(EntityType parentEntityType)
	{
		return new ArrayList<Entity>();
	}
	
	public String getDiscoveredName() {
		return discoveredName;
	}

	public void setDiscoveredName(String discoveredName) {
		this.discoveredName = discoveredName;
	}
	
}
