package com.alu.oss.mdf.rda.metadata.sure;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)
public class StateEntity extends Entity {
	
	private static final long serialVersionUID = 1L;

	@XmlElement(name = "Value")
	private String value;

	public StateEntity() {
		super(EntityType.STATE);
	}

	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
	@Override
	public void setName(String name)
	{
		this.value = name;

	}
	
	@Override
	public String getName()
	{
		return this.value;
	}

	
	
	@Override
    public boolean equals(Object obj)
	{
		if (this == obj) return true;
        if ( !(obj instanceof StateEntity) ) return false;

        final StateEntity castObj =(StateEntity) obj;

        if ( castObj.getName() != null){
        	if ( castObj.getValue().equals(getValue())) return true;
        }
	        
        return false;
	}
	
	@Override
	public List<String> getComparableAttributes() {
		return new ArrayList<String>(Arrays.asList("value", "type", "discoveredName"));
	}
	
	@Override
	public StateEntity clone()
	{
		StateEntity clone = new StateEntity();
		clone.setId(id);
		clone.setName(name);
		clone.setType(type);
		clone.setTemplate(template);
		clone.setState(state);
		clone.setStatus(status);
		clone.setFeatureEntities(featureEntities);
		clone.setDiscoveredName(discoveredName);
		clone.setNeName(neName);
		clone.setSequence(sequence);
		clone.setReconciliationGroup(reconciliationGroup);
		clone.setReconParents(reconParents);
		clone.setRoots(roots);
		
		clone.setValue(value);
		
		return clone;
	}
	
	@Override
	public StateEntity cloneWithoutParents()
	{
		return this.clone();
	}

}