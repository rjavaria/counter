package com.alu.oss.mdf.rda.metadata.sure;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

import com.alu.oss.mdf.rda.metadata.sure.nm.NMEntityFactory;

@XmlAccessorType(XmlAccessType.FIELD)
public class CustomerEntity extends Entity {
	
	private static final long serialVersionUID = -8361567618290151746L;

	@XmlElement(name="Address", required=false)
	private String address;
	
	@XmlElement(name="Email", required=false)
	private String email;
	
	@XmlElement(name="NameDetail", required=false)
	private String nameDetail;
	
	@XmlElement(name="PhoneBiz", required=false)
	private String phoneBiz;
	
	@XmlElement(name="PhoneHome", required=false)
	private String phoneHome;
	
	@XmlElement(name="PhoneMobile", required=false)
	private String phoneMobile;
	
	@XmlElementWrapper(name="PathNames", required=false)
	@XmlElement(name="PathName", required=false)
	private List<String> pathNames = new ArrayList<String>();
	
	@XmlElementWrapper(name="ServiceNames", required=false)
	@XmlElement(name="ServiceName", required=false)
	private List<String> serviceNames = new ArrayList<String>();
	
	@Override
	public List<String> getComparableAttributes()
	{
		return new ArrayList<String>(Arrays.asList("type", "address", "email", "nameDetail", "phoneBiz", "phoneHome", "phoneMobile", "discoveredName"));
	}
	
	public CustomerEntity()
	{
		super(EntityType.CUSTOMER);
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getNameDetail() {
		return nameDetail;
	}

	public void setNameDetail(String nameDetail) {
		this.nameDetail = nameDetail;
	}

	public String getPhoneBiz() {
		return phoneBiz;
	}

	public void setPhoneBiz(String phoneBiz) {
		this.phoneBiz = phoneBiz;
	}

	public String getPhoneHome() {
		return phoneHome;
	}

	public void setPhoneHome(String phoneHome) {
		this.phoneHome = phoneHome;
	}

	public String getPhoneMobile() {
		return phoneMobile;
	}

	public void setPhoneMobile(String phoneMobile) {
		this.phoneMobile = phoneMobile;
	}

	public List<String> getPathNames() {
		return pathNames;
	}

	public void setPathNames(List<String> pathNames) {
		this.pathNames = pathNames;
	}

	public List<String> getServiceNames() {
		return serviceNames;
	}

	public void setServiceNames(List<String> serviceNames) {
		this.serviceNames = serviceNames;
	}
	
	@Override
    public boolean equals(Object obj)
	{
		if (this == obj) return true;
        if ( !(obj instanceof CustomerEntity) ) return false;

        final CustomerEntity castObj =(CustomerEntity) obj;

        if ( castObj.getName() != null){
        	if ( castObj.getName().equals(getName())) return true;
        }
	        
        return false;

	}
	
	
	@Override
	public CustomerEntity clone()
	{
		CustomerEntity clone = new CustomerEntity();
		clone.setId(id);
		clone.setName(name);
		clone.setType(type);
		clone.setTemplate(template);
		clone.setState(state);
		clone.setStatus(status);
		clone.setFeatureEntities(featureEntities);
		clone.setDiscoveredName(discoveredName);
		clone.setNeName(neName);
		clone.setSequence(sequence);
		clone.setReconciliationGroup(reconciliationGroup);
		clone.setReconParents(reconParents);
		clone.setRoots(roots);
		
		clone.setAddress(address);
		clone.setEmail(email);
		clone.setNameDetail(nameDetail);
		clone.setPhoneBiz(phoneBiz);
		clone.setPhoneHome(phoneHome);
		clone.setPhoneMobile(phoneMobile);
		clone.setPathNames(pathNames);
		clone.setServiceNames(serviceNames);
		
		return clone;
	}
	
	@Override
	public CustomerEntity cloneWithoutParents()
	{
		return this.clone();
	}
	
	@Override
	public List<Entity> getParents() 
	{
		List<Entity> parents = new ArrayList<Entity>();
		parents.addAll(this.getParents(EntityType.PATH));
		parents.addAll(this.getParents(EntityType.SERVICE));
		parents.addAll(this.getParents(EntityType.STATE));
		parents.addAll(this.getParents(EntityType.STATUS));
		return parents;
	}
	
	
	@Override
	public List<Entity> getParents(EntityType parentEntityType) 
	{
		List<Entity> parents = new ArrayList<Entity>();
		
		if(parentEntityType == EntityType.PATH)
		if(getPathNames() != null && !getPathNames().isEmpty())
		{
			for(String parentPath:getPathNames())
				try {
					parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.PATH,parentPath));
				} catch (Exception e) {
					e.printStackTrace();
				}
		}
		
		if(parentEntityType == EntityType.SERVICE)
		if(getServiceNames() != null && !getServiceNames().isEmpty())
		{
			for(String parentService:getServiceNames())
				try {
					parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.SERVICE,parentService));
				} catch (Exception e) {
					e.printStackTrace();
				}
		}
		
		if(parentEntityType == EntityType.STATE)
		if(getState() != null && !getState().isEmpty())
		{
			try {
				parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.STATE,getState()));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if(parentEntityType == EntityType.STATUS)
		if(getStatus() != null && !getStatus().isEmpty())
		{
			try {
				parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.STATUS,getStatus()));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return parents;
	}
}
