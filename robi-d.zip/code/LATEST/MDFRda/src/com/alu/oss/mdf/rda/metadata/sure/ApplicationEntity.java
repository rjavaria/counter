package com.alu.oss.mdf.rda.metadata.sure;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

import com.alu.oss.mdf.rda.metadata.sure.nm.NMEntityFactory;


@XmlAccessorType(XmlAccessType.FIELD)
public class ApplicationEntity extends Entity {
	
	private static final long serialVersionUID = -1256744137079544792L;

	@XmlElement(name="SoftwareName", required=false)
	private String softwareName;
	
	@XmlElement(name="ParentApplicationName", required=false)
	private String parentApplicationName;
	
	@XmlElementWrapper(name="EquipmentNames", required=false)
	@XmlElement(name="EquipmentName", required=false)
	private List<String> equipmentNames = new ArrayList<String>();
	
	@Override
	public List<String> getComparableAttributes()
	{
		return new ArrayList<String>(Arrays.asList("type", "softwareName", "discoveredName"));
	}
	
	public ApplicationEntity()
	{
		super(EntityType.APPLICATION);
	}

	public String getSoftwareName() {
		return softwareName;
	}

	public void setSoftwareName(String softwareName) {
		this.softwareName = softwareName;
	}

	public String getParentApplicationName() {
		return parentApplicationName;
	}

	public void setParentApplicationName(String parentApplicationName) {
		this.parentApplicationName = parentApplicationName;
	}

	public List<String> getEquipmentNames() {
		return equipmentNames;
	}

	public void setEquipmentNames(List<String> equipmentNames) {
		this.equipmentNames = equipmentNames;
	}
	
	@Override
    public boolean equals(Object obj)
	{
		if (this == obj) return true;
        if ( !(obj instanceof ApplicationEntity) ) return false;

        final ApplicationEntity castObj =(ApplicationEntity) obj;

        if ( castObj.getName() != null){
        	if ( castObj.getName().equals(getName())) return true;
        }
	        
        return false;

	}
	
	@Override
	public List<Entity> getParents() 
	{
		List<Entity> parents = new ArrayList<Entity>();
		parents.addAll(this.getParents(EntityType.APPLICATION));
		parents.addAll(this.getParents(EntityType.EQUIPMENT));
		return parents;
	}

	public List<Entity> getParents(EntityType parentEntityType)
	{
		List<Entity> parents = new ArrayList<Entity>();
		
		if(parentEntityType == EntityType.APPLICATION)
		if(getParentApplicationName() != null && !getParentApplicationName().isEmpty() )
			try {
				parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.APPLICATION,getParentApplicationName()));
			} catch (Exception e) {
				e.printStackTrace();
			}

		if(parentEntityType == EntityType.EQUIPMENT)
		if(getEquipmentNames() != null && ! getEquipmentNames().isEmpty())
		{
			for(String eqpName:getEquipmentNames())
				try {
					parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.EQUIPMENT,eqpName));
				} catch (Exception e) {
					e.printStackTrace();
				}
		}
		return parents;
	}
	
	
	@Override
	public ApplicationEntity clone()
	{
		ApplicationEntity clone = new ApplicationEntity();
		clone.setId(id);
		clone.setName(name);
		clone.setType(type);
		clone.setTemplate(template);
		clone.setState(state);
		clone.setStatus(status);
		clone.setFeatureEntities(featureEntities);
		clone.setDiscoveredName(discoveredName);
		clone.setNeName(neName);
		clone.setSequence(sequence);
		clone.setReconciliationGroup(reconciliationGroup);
		clone.setReconParents(reconParents);
		clone.setRoots(roots);
		
		clone.setSoftwareName(softwareName);
		clone.setParentApplicationName(parentApplicationName);
		clone.getEquipmentNames().addAll(equipmentNames);
		
		return clone;
	}
	
	@Override
	public ApplicationEntity cloneWithoutParents()
	{
		ApplicationEntity clone = this.clone();
		clone.setParentApplicationName(null);

		return clone;
		
	}

}
