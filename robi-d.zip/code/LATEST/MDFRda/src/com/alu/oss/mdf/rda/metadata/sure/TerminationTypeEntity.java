package com.alu.oss.mdf.rda.metadata.sure;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)
public class TerminationTypeEntity extends Entity{
	
	private static final long serialVersionUID = -2400526685530814507L;

	private Long terminationTypeId;

	private String physicalOrLogical;

	private String terminationType;

	
//	private Set<TerminationEntity> termination;

	@Override
	public List<String> getComparableAttributes()
	{
		return new ArrayList<String>(Arrays.asList("terminationType", "physicalOrLogical"));
	}
	
	public TerminationTypeEntity() 
	{
		super(EntityType.TERMINATION_TYPE);
	}

	@XmlElement
	public Long getTerminationTypeId() {
		return this.terminationTypeId;
	}

	public void setTerminationTypeId(Long terminationTypeId) {
		this.terminationTypeId = terminationTypeId;
	}

	@XmlElement
	public String getPhysicalOrLogical() {
		return this.physicalOrLogical;
	}

	public void setPhysicalOrLogical(String physicalOrLogical) {
		this.physicalOrLogical = physicalOrLogical;
	}

	@XmlElement
	public String getTerminationType() {
		return this.terminationType;
	}

	public void setTerminationType(String terminationType) {
		this.terminationType = terminationType;
	}

//	@XmlElement(name = "termination")
//	public Set<Termination> getTerminations() {
//		return this.termination;
//	}
//
//	public void setTerminations(Set<Termination> terminations) {
//		this.termination = terminations;
//	}
//
//	public Termination addTermination(Termination termination) {
//		getTerminations().add(termination);
//		termination.setTerminationType(this);
//
//		return termination;
//	}
//
//	public Termination removeTermination(Termination termination) {
//		getTerminations().remove(termination);
//		termination.setTerminationType(null);
//
//		return termination;
//	}

	@Override
    public boolean equals(Object obj)
	{
		if (this == obj) return true;
        if ( !(obj instanceof TerminationTypeEntity) ) return false;

        final TerminationTypeEntity castObj =(TerminationTypeEntity) obj;

        if ( castObj.getName() != null){
        	if ( castObj.getName().equals(getName())) return true;
        }
	        
        return false;

	}
	
	@Override
	public TerminationTypeEntity clone()
	{
		TerminationTypeEntity clone = new TerminationTypeEntity();
		clone.setId(id);
		clone.setName(name);
		clone.setType(type);
		clone.setTemplate(template);
		clone.setState(state);
		clone.setStatus(status);
		clone.setFeatureEntities(featureEntities);
		clone.setDiscoveredName(discoveredName);
		clone.setNeName(neName);
		clone.setSequence(sequence);
		clone.setReconciliationGroup(reconciliationGroup);
		clone.setReconParents(reconParents);
		clone.setRoots(roots);
		
		clone.setTerminationTypeId(terminationTypeId);
		clone.setPhysicalOrLogical(physicalOrLogical);
		clone.setTerminationType(terminationType);
		
		return clone;
	}
	
	@Override
	public TerminationTypeEntity cloneWithoutParents()
	{
		return this.clone();
	}
	
}
