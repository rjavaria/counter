package com.alu.oss.mdf.rda.metadata.delta;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlType;

import com.alu.oss.mdf.rda.metadata.sure.Entity;
import com.alu.oss.mdf.rda.metadata.sure.EntityType;
import com.alu.oss.mdf.rda.metadata.sure.FeatureEntity;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "entityName",
        "entityType",
        "type",
        "featureEntities",
        "sequence",
        "reconciliationGroup",
	    "reconParents",
	    "roots"
    })
public class DeltaEntityFeature extends Delta{
	
	private static final long serialVersionUID = 3288850033194955806L;

	@XmlElement(name="EntityType")
	private EntityType entityType;
	
	@XmlElement(name="EntityName")
	private String entityName;
	
	@XmlElement(name="Type")
	private String type;

	@XmlElementWrapper(name="Features")
	@XmlElement(name="Feature")	
	private List<FeatureEntity> featureEntities = new ArrayList<FeatureEntity>();

	public DeltaEntityFeature()
	{
	}
	
	public DeltaEntityFeature(Entity entity, List<FeatureEntity> featureEntities, String sequence)
	{
		this();
		this.entityType = entity.getEntityType();
		this.entityName = entity.getName();
		this.type = entity.getType();
		this.featureEntities = featureEntities;
		this.sequence = sequence;
		this.reconciliationGroup = entity.getReconciliationGroup();
		for(Entity reconParent:entity.getReconParents())
			this.getReconParentEntityName().add(reconParent.getName());
		this.roots = entity.getRoots();
	}
	
	public EntityType getEntityType() {
		return entityType;
	}

	public void setEntityType(EntityType entityType) {
		this.entityType = entityType;
	}

	@Override
	public String getEntityName() {
		return entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public List<FeatureEntity> getFeatureEntities() {
		return featureEntities;
	}

	public void setFeatureEntities(List<FeatureEntity> featureEntities) {
		this.featureEntities = featureEntities;
	}
	
    public List<String> getParentEntityName(){
		return getReconParentEntityName();
	}	
	
    public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String toString()
	{
		return getEntityName();
	}
}
