package com.alu.oss.mdf.rda.metadata.delta;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlEnum(String.class)
public enum DiscoveryLevel {
	Level1, 
	Level2, 
	Level3, 
	Level4,
	MASSLOADER;
}