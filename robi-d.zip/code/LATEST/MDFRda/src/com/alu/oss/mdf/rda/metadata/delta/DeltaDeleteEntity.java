package com.alu.oss.mdf.rda.metadata.delta;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.alu.oss.mdf.rda.metadata.sure.Entity;
import com.alu.oss.mdf.rda.metadata.sure.EntityType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "entityType",
        "entityName",
        "type",
        "sequence",
        "reconciliationGroup",
	    "reconParents",
	    "roots"
    })
public class DeltaDeleteEntity extends Delta{

	private static final long serialVersionUID = 5605122183311211825L;

	@XmlElement(name="EntityType")
	private EntityType entityType;
	
	@XmlElement(name="EntityName")
	private String entityName;
	
	@XmlElement(name="Type")
	private String type;
	
	public DeltaDeleteEntity()
	{
	}

	public DeltaDeleteEntity(Entity entity, String sequence)
	{
		this();
		this.entityType = entity.getEntityType();
		this.entityName = entity.getName();
		this.type = entity.getType();
		this.sequence = sequence;
		this.reconciliationGroup = entity.getReconciliationGroup();
		for(Entity reconParent:entity.getReconParents())
			this.getReconParentEntityName().add(reconParent.getName());
		this.roots = entity.getRoots();
	}
	
	public EntityType getEntityType() {
		return entityType;
	}

	public void setEntityType(EntityType entityType) {
		this.entityType = entityType;
	}

	@Override
	public String getEntityName() {
		return entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}
	
    public List<String> getParentEntityName() 
	{
		return getReconParentEntityName();
	}	
    
    @Override
    public void setSequence(String sequence) {
		this.sequence = "-"+sequence;
	}
    
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String toString()
	{
		return getEntityName();
	}
	
	@Override
    public boolean equals(Object obj)
	{
		if (this == obj) return true;
        if ( !(obj instanceof DeltaDeleteEntity) ) return false;

        final DeltaDeleteEntity castObj =(DeltaDeleteEntity) obj;

        if ( castObj.getEntityName() != null){
        	if ( castObj.getEntityName().equals(getEntityName())) return true;
        }
	        
        return false;

	}
	
	@Override
	public int hashCode()
	{
		if( getEntityName() != null)
		{
			return getEntityName().hashCode();
		}
		else 
		{
			return super.hashCode();
		}
	}
}
