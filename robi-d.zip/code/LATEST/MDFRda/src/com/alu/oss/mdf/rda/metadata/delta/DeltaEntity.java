package com.alu.oss.mdf.rda.metadata.delta;

import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="Updates")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
		"deltaRemoveAssociations",
        "deltaInsertEntities",
        "deltaAddAssociations",
        "deltaUpdateEntities",
        "deltaDeleteEntities",
        "deltaDeleteEntityFeatures",
        "deltaInsertEntityFeatures",
        "deltaUpdateEntityFeatures",
        "sequence",
        "reconciliationGroup",
	    "reconParents",
	    "roots"
    })
public class DeltaEntity extends Delta 
{

	private static final long serialVersionUID = 258675941279517492L;

	@XmlElement(name="RemoveAssociation", required=false)
	private List<DeltaAssociation> deltaRemoveAssociations = new ArrayList<DeltaAssociation>();
	
	@XmlElement(name="Insert", required=false)
	private List<DeltaInsertEntity> deltaInsertEntities = new ArrayList<DeltaInsertEntity>();
	
	@XmlElement(name="AddAssociation", required=false)
	private List<DeltaAssociation> deltaAddAssociations = new ArrayList<DeltaAssociation>();
	
	@XmlElement(name="Update", required=false)
	private List<DeltaUpdateEntity> deltaUpdateEntities = new ArrayList<DeltaUpdateEntity>();

	@XmlElement(name="Delete", required=false)
	private List<DeltaDeleteEntity> deltaDeleteEntities = new ArrayList<DeltaDeleteEntity>();

	@XmlElement(name="DeleteFeature", required=false)
	private List<DeltaEntityFeature> deltaDeleteEntityFeatures = new ArrayList<DeltaEntityFeature>();

	@XmlElement(name="InsertFeature", required=false)
	private List<DeltaEntityFeature> deltaInsertEntityFeatures = new ArrayList<DeltaEntityFeature>();
	
	@XmlElement(name="UpdateFeature", required=false)
	private List<DeltaEntityFeature> deltaUpdateEntityFeatures = new ArrayList<DeltaEntityFeature>();

	@XmlTransient
	private String xmlDelta;
	
	public String getXMLDelta()
	{
		return xmlDelta;
	}
	
	public void setXMLDelta(String xmlDelta)
	{
		this.xmlDelta = xmlDelta;
	}
	
	public byte[] getBytes()
	{
		try
		{
			ByteArrayOutputStream b = new ByteArrayOutputStream();
            ObjectOutputStream o = new ObjectOutputStream(b);
            o.writeObject(this);
            return b.toByteArray();
        }catch(Exception e){
        	return null;
        }
	}
	
	@Override
	public String getEntityName() {
		return getDelta().getEntityName();
	}
	
	@XmlTransient
	private int discoveryLevel;
	
	public int getDiscoveryLevel()
	{
		return discoveryLevel;
	}
	public void setDiscoveryLevel(int aDiscoveryLevel)
	{
		discoveryLevel = aDiscoveryLevel;
	}
	
	public List<DeltaAssociation> getDeltaRemoveAssociations() 
	{
		deltaRemoveAssociations = new ArrayList<DeltaAssociation>(new LinkedHashSet<DeltaAssociation>(deltaRemoveAssociations));
		return deltaRemoveAssociations;
	}

	public void setDeltaRemoveAssociations(List<DeltaAssociation> deltaRemoveAssociations) {
		this.deltaRemoveAssociations = deltaRemoveAssociations;
	}
	
	public void addDeltaRemoveAssociation(DeltaAssociation deltaRemoveAssociation) {
		this.deltaRemoveAssociations.add(deltaRemoveAssociation);
	}

	public List<DeltaInsertEntity> getDeltaInsertEntities() 
	{
		deltaInsertEntities = new ArrayList<DeltaInsertEntity>(new LinkedHashSet<DeltaInsertEntity>(deltaInsertEntities));
		return deltaInsertEntities;
	}

	public void setDeltaInsertEntities(List<DeltaInsertEntity> deltaInsertEntities) {
		this.deltaInsertEntities = deltaInsertEntities;
	}
	
	public void addDeltaInsertEntity(DeltaInsertEntity deltaInsertEntity) {
		this.deltaInsertEntities.add(deltaInsertEntity);
	}

	public List<DeltaAssociation> getDeltaAddAssociations() 
	{
		deltaAddAssociations = new ArrayList<DeltaAssociation>(new LinkedHashSet<DeltaAssociation>(deltaAddAssociations));
		return deltaAddAssociations;
	}

	public void setDeltaAddAssociations(List<DeltaAssociation> deltaAddAssociations) {
		this.deltaAddAssociations= deltaAddAssociations;
	}
	
	public void addDeltaAddAssociation(DeltaAssociation deltaAddAssociation) {
		this.deltaAddAssociations.add(deltaAddAssociation);
	}

	public List<DeltaUpdateEntity> getDeltaUpdateEntities() {
		return deltaUpdateEntities;
	}

	public void setDeltaUpdateEntities(List<DeltaUpdateEntity> deltaUpdateEntities) {
		this.deltaUpdateEntities = deltaUpdateEntities;
	}
	
	public void addDeltaUpdateEntity(DeltaUpdateEntity deltaUpdateEntity) {
		this.deltaUpdateEntities.add(deltaUpdateEntity);
	}

	public List<DeltaDeleteEntity> getDeltaDeleteEntities() 
	{
		this.deltaDeleteEntities = new ArrayList<DeltaDeleteEntity>(new LinkedHashSet<DeltaDeleteEntity>(deltaDeleteEntities));
		return this.deltaDeleteEntities;
	}

	public void setDeltaDeleteEntities(List<DeltaDeleteEntity> deltaDeleteEntities) 
	{
		this.deltaDeleteEntities = deltaDeleteEntities;
	}
	
	public void addDeltaDeleteEntity(DeltaDeleteEntity deltaDeleteEntity) {
		this.deltaDeleteEntities.add(deltaDeleteEntity);
	}

	public List<DeltaEntityFeature> getDeltaDeleteEntityFeatures() {
		return deltaDeleteEntityFeatures;
	}

	public void setDeltaDeleteEntityFeatures(List<DeltaEntityFeature> deltaDeleteEntityFeatures) {
		this.deltaDeleteEntityFeatures = deltaDeleteEntityFeatures;
	}
	
	public void addDeltaDeleteEntityFeature(DeltaEntityFeature deltaDeleteEntityFeature) {
		this.deltaDeleteEntityFeatures.add(deltaDeleteEntityFeature);
	}

	public List<DeltaEntityFeature> getDeltaInsertEntityFeatures() {
		return deltaInsertEntityFeatures;
	}

	public void setDeltaInsertEntityFeatures(List<DeltaEntityFeature> deltaInsertEntityFeatures) {
		this.deltaInsertEntityFeatures = deltaInsertEntityFeatures;
	}
	
	public void addDeltaInsertEntityFeature(DeltaEntityFeature deltaInsertEntityFeature) {
		this.deltaInsertEntityFeatures.add(deltaInsertEntityFeature);
	}

	public List<DeltaEntityFeature> getDeltaUpdateEntityFeatures() {
		return deltaUpdateEntityFeatures;
	}

	public void setDeltaUpdateEntityFeatures(List<DeltaEntityFeature> deltaUpdateEntityFeatures) {
		this.deltaUpdateEntityFeatures = deltaUpdateEntityFeatures;
	}
	
	public void addDeltaUpdateEntityFeature(DeltaEntityFeature deltaUpdateEntityFeature) {
		this.deltaUpdateEntityFeatures.add(deltaUpdateEntityFeature);
	}
	
	public int totalNumberOfDiscrepancies()
	{
		return deltaRemoveAssociations.size() + deltaInsertEntities.size() + deltaAddAssociations.size() + deltaUpdateEntities.size() 
				+ deltaDeleteEntities.size() + deltaDeleteEntityFeatures.size() + deltaInsertEntityFeatures.size() + deltaUpdateEntityFeatures.size();
	}
	
/////DeltaEntity will contain only one Delta after they are split at CompareNetworkSure. Hence the following APIS are using get(0)
	
	public String getResourceFqname()
	{
		if(deltaRemoveAssociations.size() != 0)
		{
			return ((DeltaAssociation)deltaRemoveAssociations.get(0)).toString();
		}
		else if(deltaInsertEntities.size() != 0)
		{
			return ((DeltaInsertEntity)deltaInsertEntities.get(0)).toString();
		}
		else if(deltaAddAssociations.size() != 0)
		{
			return ((DeltaAssociation)deltaAddAssociations.get(0)).toString();
		}
		else if(deltaUpdateEntities.size() != 0)
		{
			return ((DeltaUpdateEntity)deltaUpdateEntities.get(0)).toString();
		}
		else if(deltaDeleteEntities.size() != 0)
		{
			return ((DeltaDeleteEntity)deltaDeleteEntities.get(0)).toString();
		}
		else if(deltaDeleteEntityFeatures.size() != 0)
		{
			return ((DeltaEntityFeature)deltaDeleteEntityFeatures.get(0)).toString();
		}
		else if(deltaInsertEntityFeatures.size() != 0)
		{
			return ((DeltaEntityFeature)deltaInsertEntityFeatures.get(0)).toString();
		}
		else if(deltaUpdateEntityFeatures.size() != 0)
		{
			return ((DeltaEntityFeature)deltaUpdateEntityFeatures.get(0)).toString();
		}
		else
			return "";
	}
	
	public String getDeltaResourceFqname()
	{
		if(deltaRemoveAssociations.size() != 0)
		{
			return ((DeltaAssociation)deltaRemoveAssociations.get(0)).toString();
		}
		else if(deltaInsertEntities.size() != 0)
		{
			return ((DeltaInsertEntity)deltaInsertEntities.get(0)).toString();
		}
		else if(deltaAddAssociations.size() != 0)
		{
			return ((DeltaAssociation)deltaAddAssociations.get(0)).toString();
		}
		else if(deltaUpdateEntities.size() != 0)
		{
			return ((DeltaUpdateEntity)deltaUpdateEntities.get(0)).getAttributeEntities().toString();
		}
		else if(deltaDeleteEntities.size() != 0)
		{
			return ((DeltaDeleteEntity)deltaDeleteEntities.get(0)).toString();
		}
		else if(deltaDeleteEntityFeatures.size() != 0)
		{
			return ((DeltaEntityFeature)deltaDeleteEntityFeatures.get(0)).getFeatureEntities().toString();
		}
		else if(deltaInsertEntityFeatures.size() != 0)
		{
			return ((DeltaEntityFeature)deltaInsertEntityFeatures.get(0)).getFeatureEntities().toString();
		}
		else if(deltaUpdateEntityFeatures.size() != 0)
		{
			return ((DeltaEntityFeature)deltaUpdateEntityFeatures.get(0)).getFeatureEntities().toString();
		}
		else
			return "";
	}
	
	@Override
	public String getSequence()
	{
		if(deltaRemoveAssociations.size() != 0)
		{
			return ((DeltaAssociation)deltaRemoveAssociations.get(0)).getSequence();
		}
		else if(deltaInsertEntities.size() != 0)
		{
			return ((DeltaInsertEntity)deltaInsertEntities.get(0)).getSequence();
		}
		else if(deltaAddAssociations.size() != 0)
		{
			return ((DeltaAssociation)deltaAddAssociations.get(0)).getSequence();
		}
		else if(deltaUpdateEntities.size() != 0)
		{
			return ((DeltaUpdateEntity)deltaUpdateEntities.get(0)).getSequence();
		}
		else if(deltaDeleteEntities.size() != 0)
		{
			return ((DeltaDeleteEntity)deltaDeleteEntities.get(0)).getSequence();
		}
		else if(deltaDeleteEntityFeatures.size() != 0)
		{
			return ((DeltaEntityFeature)deltaDeleteEntityFeatures.get(0)).getSequence();
		}
		else if(deltaInsertEntityFeatures.size() != 0)
		{
			return ((DeltaEntityFeature)deltaInsertEntityFeatures.get(0)).getSequence();
		}
		else if(deltaUpdateEntityFeatures.size() != 0)
		{
			return ((DeltaEntityFeature)deltaUpdateEntityFeatures.get(0)).getSequence();
		}
		else
			return "";
	}
	
	public List<String> getParentResourceFqname()
	{
		List<String> parentEntityNames = new ArrayList<String>();
		
		if(deltaRemoveAssociations.size() != 0)
		{
			parentEntityNames.add(((DeltaAssociation)deltaRemoveAssociations.get(0)).getParentEntityName());
			parentEntityNames.add(((DeltaAssociation)deltaRemoveAssociations.get(0)).getChildEntityName());
		}
		else if(deltaAddAssociations.size() != 0)
		{
			parentEntityNames.add(((DeltaAssociation)deltaAddAssociations.get(0)).getParentEntityName());
			parentEntityNames.add(((DeltaAssociation)deltaAddAssociations.get(0)).getChildEntityName());
		}
		else if(deltaUpdateEntities.size() != 0)
		{
			parentEntityNames.addAll(((DeltaUpdateEntity)deltaUpdateEntities.get(0)).getParentEntityName());
		}
		else if(deltaDeleteEntities.size() != 0)
		{
			parentEntityNames.addAll(((DeltaDeleteEntity)deltaDeleteEntities.get(0)).getParentEntityName());
		}
		else if(deltaInsertEntities.size() != 0)
		{
			parentEntityNames.addAll(((DeltaInsertEntity)deltaInsertEntities.get(0)).getParentEntityName());
		}
		else if(deltaDeleteEntityFeatures.size() != 0)
		{
			parentEntityNames.addAll(((DeltaEntityFeature)deltaDeleteEntityFeatures.get(0)).getParentEntityName());
		}
		else if(deltaInsertEntityFeatures.size() != 0)
		{
			parentEntityNames.addAll(((DeltaEntityFeature)deltaInsertEntityFeatures.get(0)).getParentEntityName());
		}
		else if(deltaUpdateEntityFeatures.size() != 0)
		{
			parentEntityNames.addAll(((DeltaEntityFeature)deltaUpdateEntityFeatures.get(0)).getParentEntityName());
		}
		
		return parentEntityNames;
	}
	
	public String getRootResourceFqname()
	{
		
		List<String> rootEntityNames = new ArrayList<String>();
		
		if(deltaRemoveAssociations.size() != 0)
		{
			rootEntityNames.addAll(((DeltaAssociation)deltaRemoveAssociations.get(0)).getRootEntityName());
		}
		else if(deltaAddAssociations.size() != 0)
		{
			rootEntityNames.addAll(((DeltaAssociation)deltaAddAssociations.get(0)).getRootEntityName());
		}
		else if(deltaUpdateEntities.size() != 0)
		{
			rootEntityNames.addAll(((DeltaUpdateEntity)deltaUpdateEntities.get(0)).getRootEntityName());
		}
		else if(deltaDeleteEntities.size() != 0)
		{
			rootEntityNames.addAll(((DeltaDeleteEntity)deltaDeleteEntities.get(0)).getRootEntityName());
		}
		else if(deltaInsertEntities.size() != 0)
		{
			rootEntityNames.addAll(((DeltaInsertEntity)deltaInsertEntities.get(0)).getRootEntityName());
		}
		else if(deltaDeleteEntityFeatures.size() != 0)
		{
			rootEntityNames.addAll(((DeltaEntityFeature)deltaDeleteEntityFeatures.get(0)).getRootEntityName());
		}
		else if(deltaInsertEntityFeatures.size() != 0)
		{
			rootEntityNames.addAll(((DeltaEntityFeature)deltaInsertEntityFeatures.get(0)).getRootEntityName());
		}
		else if(deltaUpdateEntityFeatures.size() != 0)
		{
			rootEntityNames.addAll(((DeltaEntityFeature)deltaUpdateEntityFeatures.get(0)).getRootEntityName());
		}
		
		String concatRootEntityNames = "";
		for(int i=0; i<rootEntityNames.size(); i++)
		{
			concatRootEntityNames += rootEntityNames.get(i);
			if(i < rootEntityNames.size()-1)
				concatRootEntityNames += ",";
		}
		
		return concatRootEntityNames;
	}
	
	
	public Delta getDelta()
	{
		if(deltaRemoveAssociations.size() != 0)
		{
			return ((DeltaAssociation)deltaRemoveAssociations.get(0));
		}
		else if(deltaInsertEntities.size() != 0)
		{
			return ((DeltaInsertEntity)deltaInsertEntities.get(0));
		}
		else if(deltaAddAssociations.size() != 0)
		{
			return ((DeltaAssociation)deltaAddAssociations.get(0));
		}
		else if(deltaUpdateEntities.size() != 0)
		{
			return ((DeltaUpdateEntity)deltaUpdateEntities.get(0));
		}
		else if(deltaDeleteEntities.size() != 0)
		{
			return ((DeltaDeleteEntity)deltaDeleteEntities.get(0));
		}
		else if(deltaDeleteEntityFeatures.size() != 0)
		{
			return ((DeltaEntityFeature)deltaDeleteEntityFeatures.get(0));
		}
		else if(deltaInsertEntityFeatures.size() != 0)
		{
			return ((DeltaEntityFeature)deltaInsertEntityFeatures.get(0));
		}
		else if(deltaUpdateEntityFeatures.size() != 0)
		{
			return ((DeltaEntityFeature)deltaUpdateEntityFeatures.get(0));
		}
		else
			return null;
	}
	
	public DeltaType getDeltaType()
	{
		if(deltaRemoveAssociations.size() != 0)
		{
			return DeltaType.REMOVE_ASSOCIATION;
		}
		else if(deltaInsertEntities.size() != 0)
		{
			return DeltaType.INSERT_ENTITY;
		}
		else if(deltaAddAssociations.size() != 0)
		{
			return DeltaType.ADD_ASSOCIATION;
		}
		else if(deltaUpdateEntities.size() != 0)
		{
			return DeltaType.UPDATE_ENTITY;
		}
		else if(deltaDeleteEntities.size() != 0)
		{
			return DeltaType.DELETE_ENTITY;
		}
		else if(deltaDeleteEntityFeatures.size() != 0)
		{
			return DeltaType.DELETE_FEATURE;
		}
		else if(deltaInsertEntityFeatures.size() != 0)
		{
			return DeltaType.INSERT_FEATURE;
		}
		else if(deltaUpdateEntityFeatures.size() != 0)
		{
			return DeltaType.UPDATE_FEATURE;
		}
		else
			return DeltaType.UNKNOWN_OPERATION;
	}
	
	
	@Override
	public String toString()
	{
		return getDeltaType() + ":"+ getSequence() + ":" + getResourceFqname();
	}
	
}
