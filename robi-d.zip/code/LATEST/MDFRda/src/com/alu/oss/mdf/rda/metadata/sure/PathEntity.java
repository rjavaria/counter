package com.alu.oss.mdf.rda.metadata.sure;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

import com.alu.oss.mdf.rda.metadata.sure.nm.NMEntityFactory;

@XmlAccessorType(XmlAccessType.FIELD)
public class PathEntity extends Entity{
	
	private static final long serialVersionUID = -4257970715005222728L;

	@XmlElement(name="NetworkName", required=false)
	String networkName;
	
	@XmlElementWrapper(name="ParentPathNames", required=false)
	@XmlElement(name="ParentPathName", required=false)
	private List<String> parentPathNames = new ArrayList<String>();
	
	private List<String> subPathNames = new ArrayList<String>();
	
	@XmlElementWrapper(name="TerminationNames", required=false)
	@XmlElement(name="TerminationName", required=false)
	private List<String> terminationNames = new ArrayList<String>();

	private Set<CapacityEntity> capacities;
	
    private Set<CapacityDemandEntity> capacityDemands;
	
	@XmlElementWrapper(name="LinkNames", required=false)
	@XmlElement(name="LinkName")
	private List<String> linkNames = new ArrayList<String>();
	
	private List<String> subLinkNames = new ArrayList<String>();
	
	@Override
	public List<String> getComparableAttributes()
	{
		return new ArrayList<String>(Arrays.asList("type", "discoveredName"));
	}
	
	public PathEntity()
	{
		super(EntityType.PATH);
	}

	public List<String> getParentPathNames() {
		return parentPathNames == null ? new ArrayList<String>() : parentPathNames;
	}


	public void setParentPathNames(List<String> parentPathNames) {
		this.parentPathNames = parentPathNames;
	}

	public List<String> getSubPathNames() {
		return subPathNames==null ? new ArrayList<String>() : subPathNames;
	}

	public void setSubPathNames(List<String> subPathNames) {
		this.subPathNames = subPathNames;
	}
	
	public List<String> getTerminationNames() {
		return terminationNames == null ? new ArrayList<String>() : terminationNames;
	}

	public void setTerminationNames(List<String> terminationNames) {
		this.terminationNames = terminationNames;
	}

	public String getNetworkName() {
		return networkName;
	}

	public void setNetworkName(String networkName) {
		this.networkName = networkName;
	}

	public Set<CapacityEntity> getCapacities() {
		return capacities;
	}


	public void setCapacities(Set<CapacityEntity> capacities) {
		this.capacities = capacities;
	}


	public Set<CapacityDemandEntity> getCapacityDemands() {
		return capacityDemands;
	}


	public void setCapacityDemands(Set<CapacityDemandEntity> capacityDemands) {
		this.capacityDemands = capacityDemands;
	}
	
	public List<String> getLinkNames() {
		return linkNames==null ? new ArrayList<String>() : linkNames;
	}


	public void setLinkNames(List<String> linkNames) {
		this.linkNames = linkNames;
	}
	
	public List<String> getSubLinkNames() {
		return subLinkNames==null ? new ArrayList<String>() : subLinkNames;
	}

	public void setSubLinkNames(List<String> subLinkNames) {
		this.subLinkNames = subLinkNames;
	}

	@Override
    public boolean equals(Object obj)
	{
		if (this == obj) return true;
        if ( !(obj instanceof PathEntity) ) return false;

        final PathEntity castObj =(PathEntity) obj;

        if ( castObj.getName() != null){
        	if ( castObj.getName().equals(getName())) return true;
        }
	        
        return false;

	}
	
	@Override
	public List<Entity> getParents() 
	{
		List<Entity> parents = new ArrayList<Entity>();
		parents.addAll(this.getParents(EntityType.PATH));
		parents.addAll(this.getParents(EntityType.TERMINATION));
		parents.addAll(this.getParents(EntityType.NETWORK));
		parents.addAll(this.getParents(EntityType.STATE));
		parents.addAll(this.getParents(EntityType.STATUS));
		parents.addAll(this.getParents(EntityType.LINK));
		return parents;
	}
	
	
	@Override
	public List<Entity> getParents(EntityType parentEntityType) 
	{
		List<Entity> parents = new ArrayList<Entity>();
		
		if(parentEntityType == EntityType.PATH)
		if(getParentPathNames() != null && !getParentPathNames().isEmpty())
		{
			for(String parentPath:getParentPathNames())
				try {
					parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.PATH,parentPath));
				} catch (Exception e) {
					e.printStackTrace();
				}
		}
		
		if(parentEntityType == EntityType.TERMINATION)
		if(getTerminationNames() != null && !getTerminationNames().isEmpty())
		{
			for(String parentTerm:getTerminationNames())
				try {
					parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.TERMINATION,parentTerm));
				} catch (Exception e) {
					e.printStackTrace();
				}
		}
		
		if(parentEntityType == EntityType.NETWORK)
		if(getNetworkName() != null && !getNetworkName().isEmpty())
		{
			try {
				parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.NETWORK,getNetworkName()));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if(parentEntityType == EntityType.STATE)
		if(getState() != null && !getState().isEmpty())
		{
			try {
				parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.STATE,getState()));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if(parentEntityType == EntityType.STATUS)
		if(getStatus() != null && !getStatus().isEmpty())
		{
			try {
				parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.STATUS,getStatus()));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if(parentEntityType == EntityType.LINK)
		if(getLinkNames() != null && !getLinkNames().isEmpty())
		{
			for(String linkName:getLinkNames())
				try {
					parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.LINK,linkName));
				} catch (Exception e) {
					e.printStackTrace();
				}
		}
		
		return parents;
	}
	
	@Override
	public PathEntity clone()
	{
		PathEntity clone = new PathEntity();
		clone.setId(id);
		clone.setName(name);
		clone.setType(type);
		clone.setTemplate(template);
		clone.setState(state);
		clone.setStatus(status);
		clone.setFeatureEntities(featureEntities);		
		clone.setDiscoveredName(discoveredName);
		clone.setNeName(neName);
		clone.setSequence(sequence);
		clone.setReconciliationGroup(reconciliationGroup);
		clone.setReconParents(reconParents);
		clone.setRoots(roots);
		
		clone.setNetworkName(networkName);
		clone.getParentPathNames().addAll(this.getParentPathNames());
		clone.getSubPathNames().addAll(this.getSubPathNames());
		clone.getTerminationNames().addAll(this.getTerminationNames());
		clone.setCapacities(capacities);
		clone.setCapacityDemands(capacityDemands);
		clone.getLinkNames().addAll(this.getLinkNames());
		clone.getSubLinkNames().addAll(this.getSubLinkNames());
		
		return clone;
	}

	@Override
	public PathEntity cloneWithoutParents()
	{
		PathEntity clone = this.clone();
		clone.setParentPathNames(null);
		clone.setSubPathNames(null);
		clone.setTerminationNames(null);
		clone.setLinkNames(null);
		clone.setSubLinkNames(null);
		clone.setCapacities(null);
		clone.setCapacityDemands(null);
		return clone;
	}

	@Override
	public PathEntity cloneWithoutParent(Entity parentEntity)
	{
		PathEntity clone = this.clone();
		
		if(parentEntity.getEntityType() == EntityType.TERMINATION)
		{
			clone.getTerminationNames().remove(parentEntity.getName());
		}
		else if(parentEntity.getEntityType() == EntityType.PATH)
		{
			clone.getParentPathNames().remove(parentEntity.getName());
		}
		else if(parentEntity.getEntityType() == EntityType.LINK)
		{
			clone.getLinkNames().remove(parentEntity.getName());
		}
		
		return clone;
	}
	
	@Override
	public void removeBrokenAssociations(NetworkEntity networkEntity) 
	{
		List<String> toRemove = new ArrayList<String>(); 
		for(String termName : this.getTerminationNames())
		{
			TerminationEntity term = new TerminationEntity();
			term.setName(termName);
			if(!networkEntity.getTerminationEntities().contains(term))
			{
				toRemove.add(termName);
			}
		}
		this.getTerminationNames().removeAll(toRemove);
		toRemove.clear(); 
		
		for(String parentPathName : this.getParentPathNames())
		{
			PathEntity parentPath = new PathEntity();
			parentPath.setName(parentPathName);
			if(!networkEntity.getPathEntities().contains(parentPath))
			{
				toRemove.add(parentPathName);
			}
		}
		this.getParentPathNames().removeAll(toRemove);
		toRemove.clear(); 
		
		for(String linkName : this.getLinkNames())
		{
			LinkEntity link = new LinkEntity();
			link.setName(linkName);
			if(!networkEntity.getLinkEntities().contains(link))
			{
				toRemove.add(linkName);
			}
		}
		this.getLinkNames().removeAll(toRemove);
		toRemove.clear();
		
		
	}

		
}
