package com.alu.oss.mdf.rda.metadata.sure;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

import com.alu.oss.mdf.rda.metadata.sure.nm.NMEntityFactory;

@XmlAccessorType(XmlAccessType.FIELD)
public class CapacityDemandEntity extends Entity {
	private static final long serialVersionUID = 1L;

	@XmlElement(name = "Amount")
	private String amount;

	@XmlElement(name = "UnitType")
	private String unitType;
	
	@XmlElementWrapper(name="CollectionNames", required=false)
	@XmlElement(name="CollectionName")
	private List<String> collectionNames;

	@XmlElementWrapper(name="LinkNames", required=false)
	@XmlElement(name="LinkName")
	private List<String> linkNames;

	@XmlElementWrapper(name="PathNames", required=false)
	@XmlElement(name="PathName")
	private List<String> pathNames;

	@XmlElementWrapper(name="TerminationNames", required=false)
	@XmlElement(name="TerminationName")
	private List<String> terminationNames;
	
	@Override
	public List<String> getComparableAttributes()
	{
		return new ArrayList<String>(Arrays.asList("type", "amount", "unitType", "discoveredName"));
	}
	
	public CapacityDemandEntity() {
		super( EntityType.CAPACITYDEMAND);
	}

	public String getAmount() {
		return this.amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getUnitType() {
		return this.unitType;
	}

	public void setUnitType(String unitType) {
		this.unitType = unitType;
	}

	public List<String> getCollectionNames() {
		return this.collectionNames == null ? new ArrayList<String>() : this.collectionNames;
	}

	public void setCollectionNames(List<String> collectionNames) {
		this.collectionNames = collectionNames;
	}

	public List<String> getLinkNames() {
		return this.linkNames == null ? new ArrayList<String>() : this.linkNames;
	}

	public void setLinkNames(List<String> linkNames) {
		this.linkNames = linkNames;
	}

	public List<String> getPathNames() {
		return this.pathNames == null ? new ArrayList<String>() : this.pathNames;
	}

	public void setPathNames(List<String> pathNames) {
		this.pathNames = pathNames;
	}

	public List<String> getTerminationNames() {
		return this.terminationNames == null ? new ArrayList<String>() : this.terminationNames;
	}

	public void setTerminationNames(List<String> terminationNames) {
		this.terminationNames = terminationNames;
	}
	
	@Override
    public boolean equals(Object obj)
	{
		if (this == obj) return true;
	    if ( !(obj instanceof CapacityDemandEntity) ) return false;
	
	    final CapacityDemandEntity castObj =(CapacityDemandEntity) obj;
	
	    if ( castObj.getName() != null){
	    	if ( castObj.getName().equals(getName())) return true;
	    }
	        
	    return false;
	
	}

	@Override
	public CapacityDemandEntity clone()
	{
		CapacityDemandEntity clone = new CapacityDemandEntity();
		clone.setId(id);
		clone.setName(name);
		clone.setType(type);
		clone.setTemplate(template);
		clone.setState(state);
		clone.setStatus(status);
		clone.setFeatureEntities(featureEntities);		
		clone.setDiscoveredName(discoveredName);
		clone.setNeName(neName);
		clone.setSequence(sequence);
		clone.setReconciliationGroup(reconciliationGroup);
		clone.setReconParents(reconParents);
		clone.setRoots(roots);
		
		clone.setAmount(amount);
		clone.setUnitType(unitType);
		clone.getCollectionNames().addAll(this.getCollectionNames());
		clone.getLinkNames().addAll(this.getLinkNames());
		clone.getPathNames().addAll(this.getPathNames());
		clone.getTerminationNames().addAll(this.getTerminationNames());
		
		return clone;
	}
	
	@Override
	public CapacityDemandEntity cloneWithoutParents()
	{
		CapacityDemandEntity clone =  this.clone();
		clone.setCollectionNames(null);
		clone.setLinkNames(null);
		clone.setPathNames(null);
		clone.setTerminationNames(null);
		
		return clone;
	}
	
	@Override
	public CapacityDemandEntity cloneWithoutParent(Entity parentEntity)
	{
		CapacityDemandEntity clone = this.clone();
		if(parentEntity.getEntityType() == EntityType.LINK)
			clone.getLinkNames().remove(parentEntity.getName());
		else if(parentEntity.getEntityType() == EntityType.TERMINATION)
			clone.getTerminationNames().remove(parentEntity.getName());
		else if(parentEntity.getEntityType() == EntityType.COLLECTION)
			clone.getCollectionNames().remove(parentEntity.getName());
		else if(parentEntity.getEntityType() == EntityType.PATH)
			clone.getPathNames().remove(parentEntity.getName());
		
		return clone;
	}
	
	@Override
	public List<Entity> getParents() 
	{
		List<Entity> parents = new ArrayList<Entity>();
		parents.addAll(this.getParents(EntityType.LINK));
		parents.addAll(this.getParents(EntityType.TERMINATION));
		parents.addAll(this.getParents(EntityType.COLLECTION));
		parents.addAll(this.getParents(EntityType.PATH));
		return parents;
	}
	
	@Override
	public List<Entity> getParents(EntityType parentEntityType) 
	{
		List<Entity> parents = new ArrayList<Entity>();
		
		if(parentEntityType == EntityType.LINK)
		if(getLinkNames() != null && !getLinkNames().isEmpty())
		{
			for(String linkName:getLinkNames())
			try {
				parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.LINK,linkName));
			} catch (Exception e3) {
				e3.printStackTrace();
			}
		}

		if(parentEntityType == EntityType.TERMINATION)
		if(getTerminationNames() != null && !getTerminationNames().isEmpty())
		{
			for(String termName:getTerminationNames())
			try {
				parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.TERMINATION,termName));
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		if(parentEntityType == EntityType.COLLECTION)
		if(getCollectionNames() != null && !getCollectionNames().isEmpty())
		{
			for(String collectionName:getCollectionNames())
			try {
				parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.COLLECTION,collectionName));
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
		
		if(parentEntityType == EntityType.PATH)
		if(getPathNames() != null && !getPathNames().isEmpty())
		{
			for(String pathName:getPathNames())
				try {
					parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.PATH, pathName));
				} catch (Exception e) {
					e.printStackTrace();
				}
		}
		
		return parents;
	}
}
