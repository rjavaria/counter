package com.alu.oss.mdf.rda.metadata.sure;

public enum ReconciliationGroup {
INFRASTRUCTURE,
SERVICE,
STANDALONE
}
