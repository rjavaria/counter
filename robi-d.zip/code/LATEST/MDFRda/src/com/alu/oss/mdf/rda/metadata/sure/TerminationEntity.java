package com.alu.oss.mdf.rda.metadata.sure;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

import com.alu.oss.mdf.rda.metadata.sure.nm.NMEntityFactory;

@XmlAccessorType(XmlAccessType.FIELD)
public class TerminationEntity extends Entity {

	private static final long serialVersionUID = -3989782310624087705L;

	@XmlElementWrapper(name="ParentTerminationNames", required=false)
	@XmlElement(name="ParentTerminationName", required=false)
	private List<String> parentTerminationName = new ArrayList<String>();
	
	@XmlElement(name="EquipmentName", required=true)
	private String equipmentName;
	
	@XmlElement(name="InUse", required=false)
	private String inUse;
	
	private Set<CapacityEntity> capacities;

	private Set<CapacityDemandEntity> capacityDemands;
	
	private String aOrZ;
	
	private String physicalOrLogical;

	public static final String A_TERMINATION = "ATerm";
	public static final String Z_TERMINATION = "ZTerm";
	
	@Override
	public List<String> getComparableAttributes()
	{
		return new ArrayList<String>(Arrays.asList("type", "inUse", "discoveredName"));
	}
	
	public String getPhysicalOrLogical() {
		return physicalOrLogical;
	}

	public void setPhysicalOrLogical(String physicalOrLogical) {
		this.physicalOrLogical = physicalOrLogical;
	}

	public TerminationEntity()
	{
		super(EntityType.TERMINATION);
	}
	
	public List<String> getParentTerminationName() {
		return parentTerminationName==null ? new ArrayList<String>() : parentTerminationName;
	}

	public void setParentTerminationName(List<String>parentTerminationName) {
		this.parentTerminationName = parentTerminationName;
	}

	public String getEquipmentName() {
		return equipmentName;
	}

	public void setEquipmentName(String equipmentName) {
		this.equipmentName = equipmentName;
	}

	public String getInUse() {
		return inUse;
	}

	public void setInUse(String inUse) {
		this.inUse = inUse;
	}

	public Set<CapacityEntity> getCapacities() {
		return capacities;
	}

	public void setCapacities(Set<CapacityEntity> capacityTypes) {
		this.capacities = capacityTypes;
	}

	public Set<CapacityDemandEntity> getCapacityDemands() {
		return capacityDemands;
	}

	public void setCapacityDemands(Set<CapacityDemandEntity> capacityDemands) {
		this.capacityDemands = capacityDemands;
	}
	
	public String getaOrZ() {
		return aOrZ;
	}

	public void setaOrZ(String aOrZ) {
		this.aOrZ = aOrZ;
	}

	@Override
    public boolean equals(Object obj)
	{
		if (this == obj) return true;
        if ( !(obj instanceof TerminationEntity) ) return false;

        final TerminationEntity castObj =(TerminationEntity) obj;

        if ( castObj.getName() != null){
        	if ( castObj.getName().equals(getName())) return true;
        }
	        
        return false;

	}
	
	@Override
	public List<Entity> getParents() 
	{
		List<Entity> parents = new ArrayList<Entity>();
		parents.addAll(this.getParents(EntityType.TERMINATION));
		parents.addAll(this.getParents(EntityType.EQUIPMENT));
		parents.addAll(this.getParents(EntityType.STATE));
		parents.addAll(this.getParents(EntityType.STATUS));
		return parents;
	}
	
	@Override
	public List<Entity> getParents(EntityType parentEntityType) 
	{
		List<Entity> parents = new ArrayList<Entity>();
		
		if(parentEntityType == EntityType.TERMINATION)
		if(getParentTerminationName() != null && !getParentTerminationName().isEmpty())
		{
			for(String parentTerm:getParentTerminationName())
			{
				try {
					parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.TERMINATION,parentTerm));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		if(parentEntityType == EntityType.EQUIPMENT)
		if(getEquipmentName() != null && !getEquipmentName().isEmpty())
		{
			try {
				parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.EQUIPMENT,getEquipmentName()));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if(parentEntityType == EntityType.STATE)
		if(getState() != null && !getState().isEmpty())
		{
			try {
				parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.STATE,getState()));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if(parentEntityType == EntityType.STATUS)
		if(getStatus() != null && !getStatus().isEmpty())
		{
			try {
				parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.STATUS,getStatus()));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		return parents;
	}
	
	@Override
	public TerminationEntity clone()
	{
		TerminationEntity clone = new TerminationEntity();
		clone.setId(id);
		clone.setName(name);
		clone.setType(type);
		clone.setTemplate(template);
		clone.setState(state);
		clone.setStatus(status);
		clone.setFeatureEntities(featureEntities);		
		clone.setDiscoveredName(discoveredName);
		clone.setNeName(neName);
		clone.setSequence(sequence);
		clone.setReconciliationGroup(reconciliationGroup);
		clone.setReconParents(reconParents);
		clone.setRoots(roots);
		
		clone.getParentTerminationName().addAll(this.getParentTerminationName());
		clone.setEquipmentName(equipmentName);
		clone.setInUse(inUse);
		clone.setCapacities(capacities);
		clone.setCapacityDemands(capacityDemands);
		clone.setPhysicalOrLogical(physicalOrLogical);
		
		return clone;
	}
	
	@Override
	public TerminationEntity cloneWithoutParents()
	{
		TerminationEntity clone = this.clone();
		clone.setParentTerminationName(null);
		clone.setEquipmentName(null);
		clone.setCapacities(null);
		clone.setCapacityDemands(null);
		return clone;
	}
	
	@Override
	public TerminationEntity cloneWithoutParent(Entity parentEntity)
	{
		TerminationEntity clone = this.clone();
		if(parentEntity.getEntityType() == EntityType.EQUIPMENT)
		{
			clone.setEquipmentName(null);
		}
		else if(parentEntity.getEntityType() == EntityType.TERMINATION)
		{
			clone.getParentTerminationName().remove(parentEntity.getName());
		}
		
		return clone;
	}
	
	@Override
	public void removeBrokenAssociations(NetworkEntity networkEntity) 
	{
		
		EquipmentEntity eqp = new EquipmentEntity();
		eqp.setName(this.getEquipmentName());
		if(!networkEntity.getEquipmentEntities().contains(eqp))
		{
			this.setEquipmentName(null);
		}
					
		List<String> toRemove = new ArrayList<String>(); 
		for(String parentTermName : this.getParentTerminationName())
		{
			TerminationEntity parentTerm = new TerminationEntity();
			parentTerm.setName(parentTermName);
			if(!networkEntity.getTerminationEntities().contains(parentTerm))
			{
				toRemove.add(parentTermName);
			}
		}
		this.getParentTerminationName().removeAll(toRemove);
		toRemove.clear(); 
	}

	
	
	
}
