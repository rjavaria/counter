package com.alu.oss.mdf.rda.metadata.delta;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlType;

import com.alu.oss.mdf.rda.metadata.sure.AttributeEntity;
import com.alu.oss.mdf.rda.metadata.sure.Entity;
import com.alu.oss.mdf.rda.metadata.sure.EntityType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "entityName",
        "entityType",
        "type",
        "attributeEntities",
        "sequence",
        "reconciliationGroup",
	    "reconParents",
	    "roots"
    })
public class DeltaUpdateEntity extends Delta{

	private static final long serialVersionUID = 763891885617014757L;
	
	@XmlElement(name="EntityType")
	private EntityType entityType;
	
	@XmlElement(name="EntityName")
	private String entityName;
	
	@XmlElement(name="Type")
	private String type;

	@XmlElementWrapper(name="Attributes")
	@XmlElement(name="Attribute")	
	private List<AttributeEntity> attributeEntities = new ArrayList<AttributeEntity>();
	
	public DeltaUpdateEntity()
	{}
	
	public DeltaUpdateEntity(Entity entity, List<AttributeEntity> attributeEntities, String sequence)
	{
		this();
		this.entityType = entity.getEntityType();
		this.entityName = entity.getName();
		this.type = entity.getType();
		this.attributeEntities = attributeEntities;
		this.sequence = sequence;
		this.reconciliationGroup = entity.getReconciliationGroup();
		for(Entity reconParent:entity.getReconParents())
			this.getReconParentEntityName().add(reconParent.getName());
		this.roots = entity.getRoots();
	}

	public EntityType getEntityType() {
		return entityType;
	}

	public void setEntityType(EntityType entityType) {
		this.entityType = entityType;
	}

	@Override
	public String getEntityName() {
		return entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public List<AttributeEntity> getAttributeEntities() {
		return attributeEntities;
	}

	public void setAttributeEntities(List<AttributeEntity> attributeEntities) {
		this.attributeEntities = attributeEntities;
	}
	
    public List<String> getParentEntityName() 
	{
		return getReconParentEntityName();
	}	
    
    public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String toString()
	{
		return getEntityName();
	}
}
