package com.alu.oss.mdf.rda.metadata.sure;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.xml.bind.annotation.*;

import com.alu.oss.mdf.rda.metadata.sure.ApplicationEntity;
import com.alu.oss.mdf.rda.metadata.sure.CapacityDemandEntity;
import com.alu.oss.mdf.rda.metadata.sure.CapacityEntity;
import com.alu.oss.mdf.rda.metadata.sure.CollectionEntity;
import com.alu.oss.mdf.rda.metadata.sure.CustomerEntity;
import com.alu.oss.mdf.rda.metadata.sure.Entity;
import com.alu.oss.mdf.rda.metadata.sure.EntityType;
import com.alu.oss.mdf.rda.metadata.sure.EquipmentEntity;
import com.alu.oss.mdf.rda.metadata.sure.LinkEntity;
import com.alu.oss.mdf.rda.metadata.sure.LocationEntity;
import com.alu.oss.mdf.rda.metadata.sure.NetwEntity;
import com.alu.oss.mdf.rda.metadata.sure.PathEntity;
import com.alu.oss.mdf.rda.metadata.sure.PolicyEntity;
import com.alu.oss.mdf.rda.metadata.sure.ServiceEntity;
import com.alu.oss.mdf.rda.metadata.sure.SoftwareEntity;
import com.alu.oss.mdf.rda.metadata.sure.TerminationEntity;
import com.alu.oss.mdf.rda.metadata.sure.nm.NMEntityFactory;

@XmlRootElement(name="NetworkEntity")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
		"netwEntities",
		"softwareEntities",
		"locationEntities",
        "collectionEntities",
        "equipmentEntities",
        "capacityEntities",
        "capacityDemandEntities",
        "applicationEntities",
        "terminationEntities",
        "linkEntities",
        "pathEntities",
        "serviceEntities",
        "customerEntities",
        "policyEntities"
        
    })
public class NetworkEntity implements Serializable{
	
	private static final long serialVersionUID = 8030435649855917L;

	@XmlElement(name="Network", required=false)
	private Set<NetwEntity> netwEntities = new HashSet<NetwEntity>();
	
	@XmlElement(name="Software", required=false)
	private Set<SoftwareEntity> softwareEntities = new HashSet<SoftwareEntity>();
	
	@XmlElement(name="Location", required=false)
	private Set<LocationEntity> locationEntities = new HashSet<LocationEntity>();
	
	@XmlElement(name="Collection", required=false)
	private Set<CollectionEntity> collectionEntities = new HashSet<CollectionEntity>();
		
	@XmlElement(name="Equipment", required=false)
	private Set<EquipmentEntity> equipmentEntities = new HashSet<EquipmentEntity>();
	
	@XmlElement(name="Application", required=false)
	private Set<ApplicationEntity> applicationEntities = new HashSet<ApplicationEntity>();
	
	@XmlElement(name="Termination", required=false)
	private Set<TerminationEntity> terminationEntities = new HashSet<TerminationEntity>();
	
	//Logical Term that is external to the current Eqp but connected to some Logical Term in the current Eqp by a Path/Service
	//Introduced to support Partial L3 discovery of IP MPLS
	@XmlTransient
	private Set<TerminationEntity> externalLogicalTerminationEntities = new HashSet<TerminationEntity>();
	
	
	@XmlElement(name="Link", required=false)
	private Set<LinkEntity> linkEntities = new HashSet<LinkEntity>();
	
	@XmlElement(name="Path", required=false)
	private Set<PathEntity> pathEntities = new HashSet<PathEntity>();
	
	@XmlElement(name="Service", required=false)
	private Set<ServiceEntity> serviceEntities = new HashSet<ServiceEntity>();
	
	@XmlElement(name="Customer", required=false)
	private Set<CustomerEntity> customerEntities = new HashSet<CustomerEntity>();
	
	
	@XmlElement(name="Policy", required=false)
	private Set<PolicyEntity> policyEntities = new HashSet<PolicyEntity>();
	

	@XmlElement(name="Capacity", required=false)
	private Set<CapacityEntity> capacityEntities = new HashSet<CapacityEntity>();

	
	@XmlElement(name="CapacityDemand", required=false)
	private Set<CapacityDemandEntity> capacityDemandEntities = new HashSet<CapacityDemandEntity>();
	
	public Set<CapacityDemandEntity> getCapacityDemandEntities() {
		return capacityDemandEntities;
	}

	public void setCapacityDemandEntities(
			Set<CapacityDemandEntity> capacityDemandEntities) {
		this.capacityDemandEntities = capacityDemandEntities;
	}

	public Set<CapacityEntity> getCapacityEntities() {
		return capacityEntities;
	}

	public void setCapacityEntities(Set<CapacityEntity> capacityEntities) {
		this.capacityEntities = capacityEntities;
	}
	

	public Set<NetwEntity> getNetwEntities() {
		return netwEntities;
	}

	public void setNetwEntities(Set<NetwEntity> netwEntities) {
		this.netwEntities = netwEntities;
	}
	
	public Set<SoftwareEntity> getSoftwareEntities() {
		return softwareEntities;
	}

	public void setSoftwareEntities(Set<SoftwareEntity> softwareEntities) {
		this.softwareEntities = softwareEntities;
	}

	public Set<LocationEntity> getLocationEntities() {
		return locationEntities;
	}

	public void setLocationEntities(Set<LocationEntity> locationEntities) {
		this.locationEntities = locationEntities;
	}
	
	public Set<CollectionEntity> getCollectionEntities() {
		return collectionEntities;
	}

	public void setCollectionEntities(Set<CollectionEntity> collectionEntities) {
		this.collectionEntities = collectionEntities;
	}

	public Set<EquipmentEntity> getEquipmentEntities() {
		return equipmentEntities;
	}

	public void setEquipmentEntities(Set<EquipmentEntity> equipmentEntities) {
		this.equipmentEntities = equipmentEntities;
	}

	public Set<ApplicationEntity> getApplicationEntities() {
		return applicationEntities;
	}

	public void setApplicationEntities(Set<ApplicationEntity> applicationEntities) {
		this.applicationEntities = applicationEntities;
	}
	
	public Set<TerminationEntity> getTerminationEntities() {
		return terminationEntities;
	}

	public void setTerminationEntities(Set<TerminationEntity> terminationEntities) {
		this.terminationEntities = terminationEntities;
	}

	public Set<TerminationEntity> getExternalLogicalTerminationEntities() {
		return externalLogicalTerminationEntities;
	}

	public void setExternalLogicalTerminationEntities(Set<TerminationEntity> externalLogicalTerminationEntities) {
		this.externalLogicalTerminationEntities = externalLogicalTerminationEntities;
	}
	
	public Set<LinkEntity> getLinkEntities() {
		return linkEntities;
	}

	public void setLinkEntities(Set<LinkEntity> linkEntities) {
		this.linkEntities = linkEntities;
	}

	public Set<PathEntity> getPathEntities() {
		return pathEntities;
	}

	public void setPathEntities(Set<PathEntity> pathEntities) {
		this.pathEntities = pathEntities;
	}

	public Set<ServiceEntity> getServiceEntities() {
		return serviceEntities;
	}

	public void setServiceEntities(Set<ServiceEntity> serviceEntities) {
		this.serviceEntities = serviceEntities;
	}

	public Set<CustomerEntity> getCustomerEntities() {
		return customerEntities;
	}

	public void setCustomerEntities(Set<CustomerEntity> customerEntities) {
		this.customerEntities = customerEntities;
	}
	
	public Set<PolicyEntity> getPolicyEntities() {
		return policyEntities;
	}

	public void setPolicyEntities(Set<PolicyEntity> policyEntities) {
		this.policyEntities = policyEntities;
	}
	
	public Set<Entity> getAllEntities()
	{
		Set<Entity> entities = new HashSet<Entity>();
		entities.addAll(getNetwEntities());
		entities.addAll(getSoftwareEntities());
		entities.addAll(getLocationEntities());
		entities.addAll(getCollectionEntities());
		entities.addAll(getEquipmentEntities());
		entities.addAll(getApplicationEntities());
		entities.addAll(getTerminationEntities());
		entities.addAll(getLinkEntities());
		entities.addAll(getPathEntities());
		entities.addAll(getServiceEntities());
		entities.addAll(getCustomerEntities());
		entities.addAll(getPolicyEntities());
		entities.addAll(getCapacityEntities());
		entities.addAll(getCapacityDemandEntities());
		entities.addAll(getExternalLogicalTerminationEntities());
		
		return entities;
	}
	  
	public Entity getEntity(EntityType entityType, String name) 
	{
		Entity searchedEntity = null;
		try
		{
			searchedEntity = NMEntityFactory.getRdaMetaEntity(entityType, name);
			Set<Entity> allEntities = getAllEntities();
			for(Entity entity:allEntities)
			{
				if(searchedEntity.equals(entity))
				{
					searchedEntity = entity;
					break;
				}
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}

		return searchedEntity;
	}
	
	public void addEntity(Entity entity)
	{
		EntityType entityType = entity.getEntityType();
		if(entityType.equals(EntityType.CUSTOMER))
		{
			getCustomerEntities().add((CustomerEntity)entity);
		}
		else if(entityType.equals(EntityType.SERVICE))
		{
			getServiceEntities().add((ServiceEntity)entity);
		}
		else if(entityType.equals(EntityType.PATH))
		{
			getPathEntities().add((PathEntity)entity);
		}
		else if(entityType.equals(EntityType.LINK))
		{
			getLinkEntities().add((LinkEntity)entity);
		}
		else if(entityType.equals(EntityType.TERMINATION))
		{
			getTerminationEntities().add((TerminationEntity)entity);
		}
		else if(entityType.equals(EntityType.APPLICATION))
		{
			getApplicationEntities().add((ApplicationEntity)entity);
		}
		else if(entityType.equals(EntityType.POLICY))
		{
			getPolicyEntities().add((PolicyEntity)entity);
		}
		else if(entityType.equals(EntityType.EQUIPMENT))
		{
			getEquipmentEntities().add((EquipmentEntity)entity);
		}
		else if(entityType.equals(EntityType.COLLECTION))
		{
			getCollectionEntities().add((CollectionEntity)entity);
		}
		else if(entityType.equals(EntityType.LOCATION))
		{
			getLocationEntities().add((LocationEntity)entity);
		}
		else if(entityType.equals(EntityType.SOFTWARE))
		{
			getSoftwareEntities().add((SoftwareEntity)entity);
		}
		else if(entityType.equals(EntityType.NETWORK))
		{
			getNetwEntities().add((NetwEntity)entity);
		}
		else if(entityType.equals(EntityType.CAPACITY))
		{
			getCapacityEntities().add((CapacityEntity)entity);
		}
		else if(entityType.equals(EntityType.CAPACITYDEMAND))
		{
			getCapacityDemandEntities().add((CapacityDemandEntity)entity);
		}
	}
	
	public void merge(NetworkEntity networkEntity)
	{
		getNetwEntities().addAll(networkEntity.getNetwEntities());
		getSoftwareEntities().addAll(networkEntity.getSoftwareEntities());
		getLocationEntities().addAll(networkEntity.getLocationEntities());
		getCollectionEntities().addAll(networkEntity.getCollectionEntities());
		getEquipmentEntities().addAll(networkEntity.getEquipmentEntities());
		getApplicationEntities().addAll(networkEntity.getApplicationEntities());
		getTerminationEntities().addAll(networkEntity.getTerminationEntities());
		getLinkEntities().addAll(networkEntity.getLinkEntities());
		getPathEntities().addAll(networkEntity.getPathEntities());
		getServiceEntities().addAll(networkEntity.getServiceEntities());
		getCustomerEntities().addAll(networkEntity.getCustomerEntities());
		getPolicyEntities().addAll(networkEntity.getPolicyEntities());
		getCapacityEntities().addAll(networkEntity.getCapacityEntities());
		getCapacityDemandEntities().addAll(networkEntity.getCapacityDemandEntities());
		
	}
	
	public NetworkEntity clone()
	{
		NetworkEntity clone = new NetworkEntity();
		
		Set<Entity> allEntities = this.getAllEntities();
		for(Entity entity:allEntities)
		{
			Entity cloneEntity = entity.clone();
			clone.addEntity(cloneEntity);
		}
		
		return clone;
	}
}
