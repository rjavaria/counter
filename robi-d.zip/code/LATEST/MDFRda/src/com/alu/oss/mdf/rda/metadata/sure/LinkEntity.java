package com.alu.oss.mdf.rda.metadata.sure;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

import com.alu.oss.mdf.rda.metadata.sure.nm.NMEntityFactory;

@XmlAccessorType(XmlAccessType.FIELD)
public class LinkEntity extends Entity {

	private static final long serialVersionUID = -8589500350810439265L;

	private Set<CapacityEntity> capacities;
	
    private Set<CapacityDemandEntity> capacityDemands;
	
	@XmlElement(name="NetworkName", required=false)
	private String networkName;
	
	@XmlElement(name="ATerminationName", required=true)
	private String aTermName;
	
	@XmlElement(name="ZTerminationName", required=true)
	private String zTermName;

	@XmlElementWrapper(name="ParentLinkNames", required=false)
	@XmlElement(name="ParentLinkName", required=false)
	private List<String> parentLinkNames = new ArrayList<String>();
	
	@XmlElementWrapper(name="PathNames", required=false)
	@XmlElement(name="PathName")
	private List<String> pathNames = new ArrayList<String>();
	
	private List<String> subPathNames = new ArrayList<String>();
	
	private List<String> subLinkNames = new ArrayList<String>();
	
	@Override
	public List<String> getComparableAttributes()
	{
		return new ArrayList<String>(Arrays.asList("type", "discoveredName"));
	}
	
	public LinkEntity()
	{
		super(EntityType.LINK);
	}

	public String getaTermName() {
		return aTermName;
	}

	public void setaTermName(String aTermName) {
		this.aTermName = aTermName;
	}

	public String getzTermName() {
		return zTermName;
	}
	
	public void setzTermName(String zTermName) {
		this.zTermName = zTermName;
	}

	public List<String> getParentLinkNames() {
		return parentLinkNames== null ? new ArrayList<String>() : parentLinkNames;
	}

	public void setParentLinkNames(List<String> parentLinkNames) {
		this.parentLinkNames = parentLinkNames;
	}

	public List<String> getPathNames() {
		return pathNames==null ? new ArrayList<String>() : pathNames;
	}

	public void setPathNames(List<String> pathNames) {
		this.pathNames = pathNames;
	}

	public Set<CapacityEntity> getCapacities() {
		return capacities;
	}

	public void setCapacities(Set<CapacityEntity> capacities) {
		this.capacities = capacities;
	}

	public Set<CapacityDemandEntity> getCapacityDemands() {
		return capacityDemands;
	}

	public void setCapacityDemands(Set<CapacityDemandEntity> capacityDemands) {
		this.capacityDemands = capacityDemands;
	}

	public String getNetworkName() {
		return networkName;
	}

	public void setNetworkName(String networkName) {
		this.networkName = networkName;
	}

	public List<String> getSubPathNames() {
		return subPathNames==null ? new ArrayList<String>() : subPathNames;
	}

	public void setSubPathNames(List<String> subPathNames) {
		this.subPathNames = subPathNames;
	}

	public List<String> getSubLinkNames() {
		return subLinkNames==null ? new ArrayList<String>() : subLinkNames;
	}

	public void setSubLinkNames(List<String> subLinkNames) {
		this.subLinkNames = subLinkNames;
	}
	
	@Override
    public boolean equals(Object obj)
	{
		if (this == obj) return true;
        if ( !(obj instanceof LinkEntity) ) return false;

        final LinkEntity castObj =(LinkEntity) obj;

        if ( castObj.getName() != null){
        	if ( castObj.getName().equals(getName())) return true;
        }
	        
        return false;

	}
	
	@Override
	public List<Entity> getParents() 
	{
		List<Entity> parents = new ArrayList<Entity>();
		parents.addAll(this.getParents(EntityType.TERMINATION));
		parents.addAll(this.getParents(EntityType.LINK));
		parents.addAll(this.getParents(EntityType.PATH));
		parents.addAll(this.getParents(EntityType.NETWORK));
		parents.addAll(this.getParents(EntityType.STATE));
		parents.addAll(this.getParents(EntityType.STATUS));
		return parents;
	}

	@Override
	public List<Entity> getParents(EntityType parentEntityType) 
	{
		List<Entity> parents = new ArrayList<Entity>();
		
		if(parentEntityType == EntityType.TERMINATION)
		if(getaTermName() != null && !getaTermName().isEmpty())
		{
			try {
				TerminationEntity parentTerm = (TerminationEntity)NMEntityFactory.getRdaMetaEntity(EntityType.TERMINATION,getaTermName());
				parentTerm.setaOrZ(TerminationEntity.A_TERMINATION);
				parents.add(parentTerm);
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		if(parentEntityType == EntityType.TERMINATION)
		if(getzTermName() != null && !getzTermName().isEmpty())
		{
			try {
				TerminationEntity parentTerm = (TerminationEntity)NMEntityFactory.getRdaMetaEntity(EntityType.TERMINATION,getzTermName());
				parentTerm.setaOrZ(TerminationEntity.Z_TERMINATION);
				parents.add(parentTerm);

			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
		
		if(parentEntityType == EntityType.LINK)
		if(getParentLinkNames() != null && !getParentLinkNames().isEmpty())
		{
			for(String linkName:getParentLinkNames())
			{
				try {
					parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.LINK,linkName));
				} catch (Exception e3) {
					e3.printStackTrace();
				}
			}
		}
		
		if(parentEntityType == EntityType.PATH)
		if(getPathNames() != null && !getPathNames().isEmpty())
		{
			for(String pathName:getPathNames())
				try {
					parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.PATH, pathName));
				} catch (Exception e) {
					e.printStackTrace();
				}
		}
		
		if(parentEntityType == EntityType.NETWORK)
		if(getNetworkName() != null && !getNetworkName().isEmpty())
		{
			try {
				parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.NETWORK,getNetworkName()));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if(parentEntityType == EntityType.STATE)
		if(getState() != null && !getState().isEmpty())
		{
			try {
				parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.STATE,getState()));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if(parentEntityType == EntityType.STATUS)
		if(getStatus() != null && !getStatus().isEmpty())
		{
			try {
				parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.STATUS,getStatus()));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		return parents;
	}
	
	@Override
	public LinkEntity clone()
	{
		LinkEntity clone = new LinkEntity();
		clone.setId(id);
		clone.setName(name);
		clone.setType(type);
		clone.setTemplate(template);
		clone.setState(state);
		clone.setStatus(status);
		clone.setFeatureEntities(featureEntities);		
		clone.setDiscoveredName(discoveredName);
		clone.setNeName(neName);
		clone.setSequence(sequence);
		clone.setReconciliationGroup(reconciliationGroup);
		clone.setReconParents(reconParents);
		clone.setRoots(roots);
		
		clone.setCapacities(capacities);
		clone.setCapacityDemands(capacityDemands);
		clone.setNetworkName(networkName);
		clone.setaTermName(aTermName);
		clone.setzTermName(zTermName);
		clone.getPathNames().addAll(this.getPathNames());
		clone.getSubPathNames().addAll(this.getSubPathNames());
		clone.getParentLinkNames().addAll(this.getParentLinkNames());
		clone.getSubLinkNames().addAll(this.getSubLinkNames());
			
		return clone;
	}
	
	//do not clone the term and path associations
	@Override
	public LinkEntity cloneWithoutParents()
	{
		LinkEntity clone = this.clone();
		clone.setaTermName(null);
		clone.setzTermName(null);
		clone.setParentLinkNames(null);
		clone.setSubLinkNames(null);
		clone.setPathNames(null);
		clone.setSubPathNames(null);
		clone.setCapacities(null);
		clone.setCapacityDemands(null);
		
		return clone;
		
	}
	
	@Override
	public LinkEntity cloneWithoutParent(Entity parentEntity)
	{
		LinkEntity clone = this.clone();
		
		if(parentEntity.getEntityType() == EntityType.TERMINATION)
		{
			if(parentEntity.getName().equals(this.getaTermName()))
			{
				clone.setaTermName(null);
				((TerminationEntity)parentEntity).setaOrZ(TerminationEntity.A_TERMINATION);
			}
			else if(parentEntity.getName().equals(this.getzTermName()))
			{
				clone.setzTermName(null);
				((TerminationEntity)parentEntity).setaOrZ(TerminationEntity.Z_TERMINATION);
			}
		}
		else if(parentEntity.getEntityType() == EntityType.LINK)
		{
			clone.setParentLinkNames(null);
		}
		else if(parentEntity.getEntityType() == EntityType.PATH)
		{
			clone.getPathNames().remove(parentEntity.getName());
		}
		
		return clone;
	}

	
	@Override
	public void removeBrokenAssociations(NetworkEntity networkEntity) 
	{
		List<String> toRemove = new ArrayList<String>(); 
		for(String pathName : this.getPathNames())
		{
			PathEntity path = new PathEntity();
			path.setName(pathName);
			if(!networkEntity.getPathEntities().contains(path))
			{
				toRemove.add(pathName);
			}
		}
		this.getPathNames().removeAll(toRemove);
		toRemove.clear(); 
		
		TerminationEntity aTerm = new TerminationEntity();
		aTerm.setName(this.getaTermName());
		TerminationEntity zTerm = new TerminationEntity();
		zTerm.setName(this.getzTermName());
		
		if(!networkEntity.getTerminationEntities().contains(aTerm))
		{
			this.setaTermName(null);//donot want to see OrphanTermination delta
		}
		
		if(!networkEntity.getTerminationEntities().contains(zTerm))
		{
			this.setzTermName(null);
		}
		
	}

	
}
