package com.alu.oss.mdf.rda.metadata.sure.sm;

import com.alu.oss.mdf.rda.metadata.sure.ApplicationEntity;
import com.alu.oss.mdf.rda.metadata.sure.CapacityDemandEntity;
import com.alu.oss.mdf.rda.metadata.sure.CapacityEntity;
import com.alu.oss.mdf.rda.metadata.sure.CollectionEntity;
import com.alu.oss.mdf.rda.metadata.sure.CustomerEntity;
import com.alu.oss.mdf.rda.metadata.sure.Entity;
import com.alu.oss.mdf.rda.metadata.sure.EntityType;
import com.alu.oss.mdf.rda.metadata.sure.EquipmentEntity;
import com.alu.oss.mdf.rda.metadata.sure.LinkEntity;
import com.alu.oss.mdf.rda.metadata.sure.LocationEntity;
import com.alu.oss.mdf.rda.metadata.sure.NetwEntity;
import com.alu.oss.mdf.rda.metadata.sure.PathEntity;
import com.alu.oss.mdf.rda.metadata.sure.PolicyEntity;
import com.alu.oss.mdf.rda.metadata.sure.ServiceEntity;
import com.alu.oss.mdf.rda.metadata.sure.SoftwareEntity;
import com.alu.oss.mdf.rda.metadata.sure.StateEntity;
import com.alu.oss.mdf.rda.metadata.sure.StatusEntity;
import com.alu.oss.mdf.rda.metadata.sure.TerminationEntity;
import com.alu.oss.mdf.rda.metadata.sure.TerminationTypeEntity;

public class SMEntityFactory {
	
	public static Entity getRdaMetaEntity(EntityType entityType) throws Exception{
		
		if(entityType.equals(EntityType.CUSTOMER))
		{
			return new CustomerEntity();
		}
		else if(entityType.equals(EntityType.SERVICE))
		{
			return new ServiceEntity();
		}
		else if(entityType.equals(EntityType.PATH))
		{
			return new PathEntity();
		}
		else if(entityType.equals(EntityType.LINK))
		{
			return new LinkEntity();
		}
		else if(entityType.equals(EntityType.TERMINATION))
		{
			return new TerminationEntity();
		}
		else if(entityType.equals(EntityType.APPLICATION))
		{
			return new ApplicationEntity();
		}
		else if(entityType.equals(EntityType.POLICY))
		{
			return new PolicyEntity();
		}
		else if(entityType.equals(EntityType.EQUIPMENT))
		{
			return new EquipmentEntity();
		}
		else if(entityType.equals(EntityType.COLLECTION))
		{
			return new CollectionEntity();
		}
		else if(entityType.equals(EntityType.LOCATION))
		{
			return new LocationEntity();
		}
		else if(entityType.equals(EntityType.SOFTWARE))
		{
			return new SoftwareEntity();
		}
		else if(entityType.equals(EntityType.NETWORK))
		{
			return new NetwEntity();
		}
		else if(entityType.equals(EntityType.TERMINATION_TYPE))
		{
			return new TerminationTypeEntity();
		}
		else if(entityType.equals(EntityType.CAPACITY))
		{
			return new CapacityEntity();
		}
		else if(entityType.equals(EntityType.CAPACITYDEMAND))
		{
			return new CapacityDemandEntity();
		}
		else if(entityType.equals(EntityType.STATE))
		{
			return new StateEntity();
		}
		else if(entityType.equals(EntityType.STATUS))
		{
			return new StatusEntity();
		}
		else
		{
			throw new Exception("Unknown EntityType.");
		}
		
	}

}
