package com.alu.oss.mdf.rda.metadata.sure;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;






import com.alu.oss.mdf.rda.metadata.sure.nm.NMEntityFactory;

@XmlAccessorType(XmlAccessType.FIELD)
public class NetwEntity extends Entity {
	
	private static final long serialVersionUID = 2014543301039376040L;

	@XmlElement(name="Layer")
	private long layer;
	
	
	@XmlElementWrapper(name="ParentNetworkNames", required=false)
	@XmlElement(name="ParentNetworkName", required=false)
	private List<String> parentNetworkName=new ArrayList<String>();;
	
	
	@XmlElement(name = "Equipments", required=false)
	private Set<EquipmentEntity> equipments;

	@Override
	public List<String> getComparableAttributes()
	{
		return new ArrayList<String>(Arrays.asList("type", "fullName", "discoveredName"));
	}
	
	public NetwEntity() 
	{
		super(EntityType.NETWORK);
	}

	
	public long getLayer() {
		return layer;
	}

	public void setLayer(long layer) {
		this.layer = layer;
	}

	public List<String> getParentNetworkName() {
		return parentNetworkName;
	}

	public void setParentNetworkName(List<String> parentNetworkName) {
		this.parentNetworkName = parentNetworkName;
	}
	
	public Set<EquipmentEntity> getEquipments() {
		return equipments;
	}

	public void setEquipments(Set<EquipmentEntity> equipments) {
		this.equipments = equipments;
	}

	@Override
    public boolean equals(Object obj)
	{
		if (this == obj) return true;
        if ( !(obj instanceof NetwEntity) ) return false;

        final NetwEntity castObj =(NetwEntity) obj;

        if ( castObj.getName() != null){
        	if ( castObj.getName().equals(getName())) return true;
        }
	        
        return false;

	}
	
	@Override
	public List<Entity> getParents() 
	{
		List<Entity> parents = new ArrayList<Entity>();
		parents.addAll(this.getParents(EntityType.NETWORK));
		return parents;
	}
	
	@Override
	public List<Entity> getParents(EntityType parentEntityType) 
	{
		List<Entity> parents = new ArrayList<Entity>();
		
		if(parentEntityType == EntityType.NETWORK)
		if(getParentNetworkName() != null && !getParentNetworkName().isEmpty())
		{
			for(String parentNetwork:getParentNetworkName())
			{	
				try {
					parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.NETWORK,parentNetwork));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return parents;
	}
	
	@Override
	public NetwEntity clone()
	{
		NetwEntity clone = new NetwEntity();
		clone.setId(id);
		clone.setName(name);
		clone.setType(type);
		clone.setTemplate(template);
		clone.setState(state);
		clone.setStatus(status);
		clone.setFeatureEntities(featureEntities);
		clone.setDiscoveredName(discoveredName);
		clone.setNeName(neName);
		clone.setSequence(sequence);
		clone.setReconciliationGroup(reconciliationGroup);
		clone.setReconParents(reconParents);
		clone.setRoots(roots);
		
		clone.setLayer(layer);	
		clone.setParentNetworkName(parentNetworkName);
		clone.setEquipments(equipments);
		
		return clone;
	}
	
	@Override
	public NetwEntity cloneWithoutParents()
	{
		NetwEntity clone = this.clone();
		clone.setParentNetworkName(null);
		return clone;
	}
	
	@Override
	public NetwEntity cloneWithoutParent(Entity parentEntity)
	{
		NetwEntity clone = this.clone();
		if(parentEntity.getEntityType() == EntityType.NETWORK)
			clone.getParentNetworkName().remove(parentEntity.getName());
		
		return clone;
	}
}
