package com.alu.oss.mdf.rda.metadata.delta;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.alu.oss.mdf.rda.metadata.sure.ApplicationEntity;
import com.alu.oss.mdf.rda.metadata.sure.CapacityDemandEntity;
import com.alu.oss.mdf.rda.metadata.sure.CapacityEntity;
import com.alu.oss.mdf.rda.metadata.sure.CollectionEntity;
import com.alu.oss.mdf.rda.metadata.sure.CustomerEntity;
import com.alu.oss.mdf.rda.metadata.sure.Entity;
import com.alu.oss.mdf.rda.metadata.sure.EntityType;
import com.alu.oss.mdf.rda.metadata.sure.EquipmentEntity;
import com.alu.oss.mdf.rda.metadata.sure.LinkEntity;
import com.alu.oss.mdf.rda.metadata.sure.LocationEntity;
import com.alu.oss.mdf.rda.metadata.sure.NetwEntity;
import com.alu.oss.mdf.rda.metadata.sure.PathEntity;
import com.alu.oss.mdf.rda.metadata.sure.PolicyEntity;
import com.alu.oss.mdf.rda.metadata.sure.ServiceEntity;
import com.alu.oss.mdf.rda.metadata.sure.SoftwareEntity;
import com.alu.oss.mdf.rda.metadata.sure.TerminationEntity;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
		"softwareEntity",
        "locationEntity",
        "collectionEntity",
        "netwEntity",
        "equipmentEntity",
        "applicationEntity",
        "terminationEntity",
        "policyEntity",        
        "linkEntity",
        "pathEntity",
        "serviceEntity",
        "customerEntity",
        "capacityEntity",
        "capacityDemandEntity",
        "sequence",
	    "reconciliationGroup",
	    "reconParents",
	    "roots"
})

public class DeltaInsertEntity extends Delta{
	
	private static final long serialVersionUID = -1922517061580711589L;

	@XmlElement(name="Software", required=false)
	private SoftwareEntity softwareEntity;
	
	@XmlElement(name="Location", required=false)
	private LocationEntity locationEntity;
	
	@XmlElement(name="Collection", required=false)
	private CollectionEntity collectionEntity;
	
	@XmlElement(name="Network", required=false)
	private NetwEntity netwEntity;
	
	@XmlElement(name="Equipment", required=false)
	private EquipmentEntity equipmentEntity;
	
	@XmlElement(name="Application", required=false)
	private ApplicationEntity applicationEntity;
	
	@XmlElement(name="Termination", required=false)
	private TerminationEntity terminationEntity;
	
	@XmlElement(name="Policy", required=false)
	private PolicyEntity policyEntity;
	
	@XmlElement(name="Link", required=false)
	private LinkEntity linkEntity;
	
	@XmlElement(name="Path", required=false)
	private PathEntity pathEntity;
	
	@XmlElement(name="Service", required=false)
	private ServiceEntity serviceEntity;
	
	@XmlElement(name="Customer", required=false)
	private CustomerEntity customerEntity;
	
	@XmlElement(name="Capacity", required=false)
	private CapacityEntity capacityEntity;
	
	@XmlElement(name="CapacityDemand", required=false)
	private CapacityDemandEntity capacityDemandEntity;
	
	
	public DeltaInsertEntity()
	{
	}
    
	public DeltaInsertEntity(Entity entity)
	{
		this();
		if(entity instanceof SoftwareEntity) { softwareEntity = (SoftwareEntity) entity;	}
		else if(entity instanceof LocationEntity) { locationEntity = (LocationEntity) entity;	}
		else if(entity instanceof CollectionEntity) { collectionEntity = (CollectionEntity) entity;	}
		else if(entity instanceof NetwEntity) { netwEntity = (NetwEntity) entity;	}
		else if(entity instanceof EquipmentEntity) { equipmentEntity = (EquipmentEntity) entity;	}
		else if(entity instanceof ApplicationEntity) { applicationEntity = (ApplicationEntity) entity;	}
		else if(entity instanceof TerminationEntity) { terminationEntity = (TerminationEntity) entity;	}
		else if(entity instanceof LinkEntity) { linkEntity = (LinkEntity) entity;	}
		else if(entity instanceof PathEntity) { pathEntity = (PathEntity) entity;	}
		else if(entity instanceof ServiceEntity) { serviceEntity = (ServiceEntity) entity;	}
		else if(entity instanceof CustomerEntity) { customerEntity = (CustomerEntity) entity;	}
		else if(entity instanceof PolicyEntity) { policyEntity = (PolicyEntity) entity;	}
		else if(entity instanceof CapacityEntity) {capacityEntity = (CapacityEntity) entity;	}
		else if(entity instanceof CapacityDemandEntity) {capacityDemandEntity = (CapacityDemandEntity) entity;	}
	}
	
	public DeltaInsertEntity(Entity entity,String sequence)
	{
		this(entity);
		this.sequence = sequence;
		this.reconciliationGroup = entity.getReconciliationGroup();
		for(Entity reconParent:entity.getReconParents())
			this.getReconParentEntityName().add(reconParent.getName());
		this.roots = entity.getRoots();
	}

	public SoftwareEntity getSoftwareEntity() {
		return softwareEntity;
	}

	public void setSoftwareEntity(SoftwareEntity softwareEntity) {
		this.softwareEntity = softwareEntity;
	}

	public LocationEntity getLocationEntity() {
		return locationEntity;
	}

	public void setLocationEntity(LocationEntity locationEntity) {
		this.locationEntity = locationEntity;
	}
	
	public CapacityDemandEntity getCapacityDemandEntity() {
		return capacityDemandEntity;
	}

	public void setCapacityDemandEntity(
		CapacityDemandEntity capacityDemandEntity) {
		this.capacityDemandEntity = capacityDemandEntity;
	}


	public CollectionEntity getCollectionEntity() {
		return collectionEntity;
	}

	public void setCollectionEntity(CollectionEntity collectionEntity) {
		this.collectionEntity = collectionEntity;
	}

	public NetwEntity getNetwEntity() {
		return netwEntity;
	}

	public void setNetwEntity(NetwEntity netwEntity) {
		this.netwEntity = netwEntity;
	}
	
	public EquipmentEntity getEquipmentEntity() {
		return equipmentEntity;
	}

	public void setEquipmentEntity(EquipmentEntity equipmentEntity) {
		this.equipmentEntity = equipmentEntity;
	}

	public ApplicationEntity getApplicationEntity() {
		return applicationEntity;
	}

	public void setApplicationEntity(ApplicationEntity applicationEntity) {
		this.applicationEntity = applicationEntity;
	}

	public TerminationEntity getTerminationEntity() {
		return terminationEntity;
	}

	public void setTerminationEntity(TerminationEntity terminationEntity) {
		this.terminationEntity = terminationEntity;
	}

	public LinkEntity getLinkEntity() {
		return linkEntity;
	}

	public void setLinkEntity(LinkEntity linkEntity) {
		this.linkEntity = linkEntity;
	}

	public PathEntity getPathEntity() {
		return pathEntity;
	}

	public void setPathEntity(PathEntity pathEntity) {
		this.pathEntity = pathEntity;
	}

	public ServiceEntity getServiceEntity() {
		return serviceEntity;
	}

	public void setServiceEntity(ServiceEntity serviceEntity) {
		this.serviceEntity = serviceEntity;
	}

	public CustomerEntity getCustomerEntity() {
		return customerEntity;
	}

	public void setCustomerEntity(CustomerEntity customerEntity) {
		this.customerEntity = customerEntity;
	}
	
	public void setPolicyEntity(PolicyEntity policyEntity) {
		this.policyEntity = policyEntity;
	}
	
	public PolicyEntity getPolicyEntity() {
		return policyEntity;
	}
	public void setCapacityEntity(CapacityEntity capacityEntity) {
		this.capacityEntity = capacityEntity;
	}
	
	public CapacityEntity getCapacityEntity() {
		return capacityEntity;
	}
	
	public EntityType getEntityType()
	{
		Entity entity = getEntity();
		if(entity!=null){
			return entity.getEntityType();
		}
		else return EntityType.UNKNOWN;
	}
	
	@Override
	public String getEntityName()
	{
		Entity entity = getEntity();
		if(entity!=null){
			return entity.getName();
		}
		else return "";
	}
	
	public Entity getEntity()
	{
		if(this.equipmentEntity != null ) { return equipmentEntity;	}
		else if(this.terminationEntity != null ) { return terminationEntity;	}
		else if(this.pathEntity != null ) { return pathEntity;	}
		else if(this.linkEntity != null ) { return linkEntity;	}
		else if(this.netwEntity != null ) { return netwEntity;	}
		else if(this.serviceEntity != null ) { return serviceEntity;	}
		else if(this.softwareEntity != null ) { return 	softwareEntity;}
		else if(this.locationEntity != null ) { return locationEntity;	}
		else if(this.collectionEntity != null ) { return collectionEntity;	}
		else if(this.applicationEntity != null ) { return applicationEntity;	}
		else if(this.customerEntity != null ) { return customerEntity;	}
		else if(this.policyEntity != null ) { return policyEntity;	}
		else if(this.capacityEntity != null ) { return capacityEntity;	}
		else if(this.capacityDemandEntity != null ) { return capacityDemandEntity;	}
		else return null;
	}
	
    public List<String> getParentEntityName()
	{
		return getReconParentEntityName();
	}	
	@Override
	public String toString()
	{
		return getEntityName();
	}
	
	@Override
    public boolean equals(Object obj)
	{
		if (this == obj) return true;
        if ( !(obj instanceof DeltaInsertEntity) ) return false;

        final DeltaInsertEntity castObj =(DeltaInsertEntity) obj;

        if ( castObj.getEntityName() != null){
        	if ( castObj.getEntityName().equals(getEntityName())) return true;
        }
	        
        return false;

	}
	
	@Override
	public int hashCode()
	{
		if( getEntityName() != null)
		{
			return getEntityName().hashCode();
		}
		else 
		{
			return super.hashCode();
		}
	}
}
