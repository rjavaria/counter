package com.alu.oss.mdf.rda.metadata.sure;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import com.alu.oss.mdf.rda.metadata.sure.nm.NMEntityFactory;

@XmlAccessorType(XmlAccessType.FIELD)
public class CollectionEntity extends Entity {
	
	private static final long serialVersionUID = 4279054155964204180L;
	
	private Set<CapacityEntity> capacities;
	
    private Set<CapacityDemandEntity> capacityDemands;
	
    
	@XmlElement(name="LocationName", required=false)
	private String locationName;
	
	@XmlElement(name="ParentCollectionName", required=false)
	private String parentCollectionName;
	
	@Override
	public List<String> getComparableAttributes()
	{
		return new ArrayList<String>(Arrays.asList("type", "discoveredName"));
	}
	
	public CollectionEntity()
	{
		super(EntityType.COLLECTION);
	}

	public Set<CapacityEntity> getCapacities() {
		return capacities;
	}

	public void setCapacities(Set<CapacityEntity> capacities) {
		this.capacities = capacities;
	}

	public Set<CapacityDemandEntity> getCapacityDemands() {
		return capacityDemands;
	}

	public void setCapacityDemands(Set<CapacityDemandEntity> capacityDemands) {
		this.capacityDemands = capacityDemands;
	}
	
	public String getLocationName() {
		return locationName;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	public String getParentCollectionName() {
		return parentCollectionName;
	}

	public void setParentCollectionName(String parentCollectionName) {
		this.parentCollectionName = parentCollectionName;
	}

	@Override
    public boolean equals(Object obj)
	{
		if (this == obj) return true;
        if ( !(obj instanceof CollectionEntity) ) return false;

        final CollectionEntity castObj =(CollectionEntity) obj;

        if ( castObj.getName() != null){
        	if ( castObj.getName().equals(getName())) return true;
        }
	        
        return false;

	}
	
	@Override
	public List<Entity> getParents() 
	{
		List<Entity> parents = new ArrayList<Entity>();
		parents.addAll(this.getParents(EntityType.COLLECTION));
		parents.addAll(this.getParents(EntityType.LOCATION));
		return parents;
	}
	
	@Override
	public List<Entity> getParents(EntityType parentEntityType) 
	{
		List<Entity> parents = new ArrayList<Entity>();
		
		if(parentEntityType == EntityType.COLLECTION)
		if(getParentCollectionName() != null && !getParentCollectionName().isEmpty())
		{
			try {
				parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.COLLECTION,getParentCollectionName()));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if(parentEntityType == EntityType.LOCATION)
		if(getLocationName() != null && !getLocationName().isEmpty())
		{
			try {
				parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.LOCATION,getLocationName()));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return parents;
	}
	
	@Override
	public CollectionEntity clone()
	{
		CollectionEntity clone = new CollectionEntity();
		clone.setId(id);
		clone.setName(name);
		clone.setType(type);
		clone.setTemplate(template);
		clone.setState(state);
		clone.setStatus(status);
		clone.setFeatureEntities(featureEntities);		
		clone.setDiscoveredName(discoveredName);
		clone.setNeName(neName);
		clone.setSequence(sequence);
		clone.setReconciliationGroup(reconciliationGroup);
		clone.setReconParents(reconParents);
		clone.setRoots(roots);
		
		clone.setCapacities(capacities);
		clone.setCapacityDemands(capacityDemands);
		clone.setLocationName(locationName);
		clone.setParentCollectionName(parentCollectionName);
		
		return clone;
	}
	
	@Override
	public CollectionEntity cloneWithoutParents()
	{
		CollectionEntity clone = this.clone();
		clone.setParentCollectionName(null);
		clone.setCapacities(null);
		clone.setCapacityDemands(null);
		
		return clone;
	}
}
