package com.alu.oss.mdf.rda.metadata.sure;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)
public class AttributeEntity implements Serializable{
	
	private static final long serialVersionUID = 5702088070258563643L;

	@XmlElement(name="Name")
	private String name;
	
	@XmlElement(name="Value")
	private String value;

	@XmlElement(name="OldValue", required=false)
	private String oldValue;
	
	public AttributeEntity() {
		
	}

	public AttributeEntity(String name, String value) {
		this();
		this.name = name;
		this.value = value;
	}
	
	public AttributeEntity(String name, String value, String oldValue) {
		this();
		this.name = name;
		this.value = value;
		this.oldValue = oldValue;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
	public String getOldValue() {
		return oldValue;
	}

	public void setOldValue(String oldValue) {
		this.oldValue = oldValue;
	}
	
	//Attributes in different entities may have the same name. Hence they should never be compared.   
	@Override
    public boolean equals(Object obj)
	{
		if (this == obj) return true;
        if ( !(obj instanceof AttributeEntity) ) return false;

        final AttributeEntity castObj =(AttributeEntity) obj;

        if ( castObj.getName() != null){
        	if ( castObj.getName().equals(getName())) return true;
        }
	        
        return false;

	}
	
	@Override
	public int hashCode()
	{
		if( getName() != null)
		{
			return (getName()).hashCode();
		}
		else 
		{
			return super.hashCode();
		}
	}
	
	@Override
	public String toString() 
	{
		return getName();
	}
	
	@Override
	public AttributeEntity clone()
	{
		AttributeEntity clone = new AttributeEntity();
		clone.setName(name);
		clone.setValue(value);
		clone.setOldValue(oldValue);
		
		return clone;
	}
}
