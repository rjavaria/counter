package com.alu.oss.mdf.rda.metadata.delta;

public class DeltaSequence {
	public static final String REMOVE_ZTERM_ASSOCIATION_SEQUENCE = "-100000";
	public static final String REMOVE_ASSOCIATION_SEQUENCE = "-99999";
	public static final String DELETE_FEATURE_SEQUENCE = "-99990";
	
	public static final int INSERTL1_ROOT_SEQUENCE = 100;
	public static final int INSERTL2_ROOT_SEQUENCE = 1000;
	public static final int INSERTL3_ROOT_SEQUENCE = 10000;
	public static final int INSERTL4_ROOT_SEQUENCE = 50000;
	public static final int INSERT_INCREMENT = 10;

	public static final String UPDATE_ENTITY_SEQUENCE = "99970";
	public static final String INSERT_FEATURE_SEQUENCE = "99980";
	public static final String UPDATE_FEATURE_SEQUENCE = "99990";
	public static final String ADD_ASSOCIATION_SEQUENCE = "99999";
	public static final String ADD_ZTERM_ASSOCIATION_SEQUENCE = "100000";
	
	
}
