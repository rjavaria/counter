package com.alu.oss.mdf.rda.metadata;

import java.io.Serializable;

public interface RDAMetadata extends Serializable{

}
