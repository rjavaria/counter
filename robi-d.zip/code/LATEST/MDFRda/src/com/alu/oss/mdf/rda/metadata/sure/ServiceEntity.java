package com.alu.oss.mdf.rda.metadata.sure;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

import com.alu.oss.mdf.rda.metadata.sure.nm.NMEntityFactory;

@XmlAccessorType(XmlAccessType.FIELD)
public class ServiceEntity extends Entity {
	
	private static final long serialVersionUID = -6246648316445906737L;

	@XmlElementWrapper(name="TerminationNames", required=false)
	@XmlElement(name="TerminationName", required=false)
	private List<String> terminationNames = new ArrayList<String>();
	
	@XmlElementWrapper(name="PathNames", required=false)
	@XmlElement(name="PathName", required=false)
	private List<String> pathNames = new ArrayList<String>();

	@XmlElement(name="serviceLabel", required=false)
	private String serviceLabel;

	@XmlElementWrapper(name="ParentServiceNames", required=false)
	@XmlElement(name="ParentServiceName", required=false)
	private List<String> parentServiceNames = new ArrayList<String>();
	
	private List<String> subServiceNames = new ArrayList<String>();
	
	@Override
	public List<String> getComparableAttributes()
	{
		return new ArrayList<String>(Arrays.asList("type","serviceLabel", "discoveredName"));
	}
	
	public ServiceEntity()
	{
		super(EntityType.SERVICE);
	}
	
	public List<String> getTerminationNames() {
		return terminationNames == null ? new ArrayList<String>() : terminationNames;
	}

	public void setTerminationNames(List<String> terminationNames) {
		this.terminationNames = terminationNames;
	}

	public List<String> getPathNames() {
		return pathNames == null ? new ArrayList<String>() : pathNames;
	}

	public void setPathNames(List<String> pathNames) {
		this.pathNames = pathNames;
	}

	public String getServiceLabel() {
		return serviceLabel;
	}

	public void setServiceLabel(String serviceLabel) {
		this.serviceLabel = serviceLabel;
	}

	public List<String> getParentServiceNames() {
		return parentServiceNames == null ? new ArrayList<String>() : parentServiceNames;
	}


	public void setParentServiceNames(List<String> parentServiceNames) {
		this.parentServiceNames = parentServiceNames;
	}
	
	public List<String> getSubServiceNames() {
		return subServiceNames;
	}

	public void setSubServiceNames(List<String> subServiceNames) {
		this.subServiceNames = subServiceNames;
	}
	
	@Override
    public ReconciliationGroup getReconciliationGroup() {
		return ReconciliationGroup.SERVICE;
	}
	
	@Override
    public boolean equals(Object obj)
	{
		if (this == obj) return true;
        if ( !(obj instanceof ServiceEntity) ) return false;

        final ServiceEntity castObj =(ServiceEntity) obj;

        if ( castObj.getName() != null){
        	if ( castObj.getName().equals(getName())) return true;
        }
	        
        return false;

	}
	
	@Override
	public List<Entity> getParents() 
	{
		List<Entity> parents = new ArrayList<Entity>();
		parents.addAll(this.getParents(EntityType.SERVICE));
		parents.addAll(this.getParents(EntityType.TERMINATION));
		parents.addAll(this.getParents(EntityType.PATH));
		parents.addAll(this.getParents(EntityType.STATE));
		parents.addAll(this.getParents(EntityType.STATUS));
		return parents;
	}
	
	@Override
	public List<Entity> getParents(EntityType parentEntityType) 
	{
		List<Entity> parents = new ArrayList<Entity>();
		
		if(parentEntityType == EntityType.SERVICE)
		if(getParentServiceNames() != null && !getParentServiceNames().isEmpty())
		{
			for(String parentService:getParentServiceNames())
			{
				try {
					parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.SERVICE,parentService));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		if(parentEntityType == EntityType.TERMINATION)
		if(getTerminationNames() != null && !getTerminationNames().isEmpty())
		{
			for(String parentTerm:getTerminationNames())
			{
				try {
					parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.TERMINATION,parentTerm));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		
		if(parentEntityType == EntityType.PATH)
		if(getPathNames() != null && !getPathNames().isEmpty())
		{
			for(String parentPath:getPathNames())
			{
				try {
					parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.PATH,parentPath));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		
		if(parentEntityType == EntityType.STATE)
		if(getState() != null && !getState().isEmpty())
		{
			try {
				parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.STATE,getState()));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if(parentEntityType == EntityType.STATUS)
		if(getStatus() != null && !getStatus().isEmpty())
		{
			try {
				parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.STATUS,getStatus()));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return parents;
	}
	
	@Override
	public ServiceEntity clone()
	{
		ServiceEntity clone = new ServiceEntity();
		clone.setId(id);
		clone.setName(name);
		clone.setType(type);
		clone.setTemplate(template);
		clone.setState(state);
		clone.setStatus(status);
		clone.setFeatureEntities(featureEntities);
		clone.setDiscoveredName(discoveredName);
		clone.setNeName(neName);
		clone.setSequence(sequence);
		clone.setReconciliationGroup(reconciliationGroup);
		clone.setReconParents(reconParents);
		clone.setRoots(roots);
		
		clone.getTerminationNames().addAll(this.getTerminationNames());
		clone.getPathNames().addAll(this.getPathNames());
		clone.setServiceLabel(serviceLabel);
		clone.getParentServiceNames().addAll(this.getParentServiceNames());
		
		return clone;
	}
	
	@Override
	public ServiceEntity cloneWithoutParents()
	{
		ServiceEntity clone = this.clone();
		
		clone.setTerminationNames(null);
		clone.setPathNames(null);
		clone.setParentServiceNames(null);
		
		return clone;
		
	}
	
	@Override
	public ServiceEntity cloneWithoutParent(Entity parentEntity)
	{
		ServiceEntity clone = this.clone();
		
		if(parentEntity.getEntityType() == EntityType.TERMINATION)
		{
			clone.getTerminationNames().remove(parentEntity.getName());
		}
		else if(parentEntity.getEntityType() == EntityType.PATH)
		{
			clone.getPathNames().remove(parentEntity.getName());
		}
		else if(parentEntity.getEntityType() == EntityType.SERVICE)
		{
			clone.getParentServiceNames().remove(parentEntity.getName());
		}
		
		return clone;
	}
	
	@Override
	public void removeBrokenAssociations(NetworkEntity networkEntity) 
	{
		List<String> toRemove = new ArrayList<String>(); 
		for(String pathName : this.getPathNames())
		{
			PathEntity path = new PathEntity();
			path.setName(pathName);
			if(!networkEntity.getPathEntities().contains(path))
			{
				toRemove.add(pathName);
			}
		}
		this.getPathNames().removeAll(toRemove);
		toRemove.clear(); 
		
		for(String termName : this.getTerminationNames())
		{
			TerminationEntity term = new TerminationEntity();
			term.setName(termName);
			if(!networkEntity.getTerminationEntities().contains(term))
			{
				toRemove.add(termName);
			}
		}
		this.getTerminationNames().removeAll(toRemove);
		toRemove.clear(); 
		
	}

	
	
}
