package com.alu.oss.mdf.rda.metadata.sure;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import com.alu.oss.mdf.rda.metadata.sure.nm.NMEntityFactory;

@XmlAccessorType(XmlAccessType.FIELD)
public class LocationEntity extends Entity {
	
	private static final long serialVersionUID = -7099721325093844741L;

	@XmlElement(name="Address1", required=false)
	private String address1;
	
	@XmlElement(name="Address2", required=false)
	private String address2;

	@XmlElement(name="Country", required=false)
	private String country;
	
	@XmlElement(name="Latitude", required=false)
	private String latitude;
	
	@XmlElement(name="Longitude", required=false)
	private String longitude;
	
	@XmlElement(name="Postcode", required=false)
	private String postcode;
	
	@XmlElement(name="Town", required=false)
	private String town;
	
	@XmlElement(name="ParentLocationName", required=false)
	private String parentLocationName;
	
	@Override
	public List<String> getComparableAttributes()
	{
		return new ArrayList<String>(Arrays.asList("type", "address1", "address2", "country", "latitude", "longitude", "postcode", "town", "discoveredName"));
	}
	
	public LocationEntity()
	{
		super(EntityType.LOCATION);
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	public String getTown() {
		return town;
	}

	public void setTown(String town) {
		this.town = town;
	}

	public String getParentLocationName() {
		return parentLocationName;
	}

	public void setParentLocationName(String parentLocationName) {
		this.parentLocationName = parentLocationName;
	}
		
	@Override
    public boolean equals(Object obj)
	{
		if (this == obj) return true;
        if ( !(obj instanceof LocationEntity) ) return false;

        final LocationEntity castObj =(LocationEntity) obj;

        if ( castObj.getName() != null){
        	if ( castObj.getName().equals(getName())) return true;
        }
	        
        return false;

	}
	
	@Override
	public List<Entity> getParents() 
	{
		List<Entity> parents = new ArrayList<Entity>();
		parents.addAll(this.getParents(EntityType.LOCATION));
		return parents;
	}
	
	@Override
	public List<Entity> getParents(EntityType parentEntityType) 
	{
		List<Entity> parents = new ArrayList<Entity>();
		
		if(parentEntityType == EntityType.LOCATION)
		if(getParentLocationName() != null && !getParentLocationName().isEmpty())
		{
			try {
				parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.LOCATION,getParentLocationName()));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return parents;
	}
	
	
	@Override
	public LocationEntity clone()
	{
		LocationEntity clone = new LocationEntity();
		clone.setId(id);
		clone.setName(name);
		clone.setType(type);
		clone.setTemplate(template);
		clone.setState(state);
		clone.setStatus(status);
		clone.setFeatureEntities(featureEntities);
		clone.setDiscoveredName(discoveredName);
		clone.setNeName(neName);
		clone.setSequence(sequence);
		clone.setReconciliationGroup(reconciliationGroup);
		clone.setReconParents(reconParents);
		clone.setRoots(roots);
		
		clone.setAddress1(address1);	
		clone.setAddress2(address2);
		clone.setCountry(country);
		clone.setLatitude(latitude);
		clone.setLongitude(longitude);
		clone.setPostcode(postcode);
		clone.setTown(town);
		clone.setParentLocationName(parentLocationName);
		
		return clone;
	}
	
	@Override
	public LocationEntity cloneWithoutParents()
	{
		LocationEntity clone = this.clone();
		clone.setParentLocationName(null);
		
		return clone;
	}
	
}
