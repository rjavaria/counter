package com.alu.oss.mdf.rda.metadata.sure;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import java.io.Serializable;

@XmlAccessorType(XmlAccessType.FIELD)
public class FeatureEntity implements Serializable {

	private static final long serialVersionUID = 5826023267927605467L;

	private Object id;
	
	@XmlElement(name="Name")
	private String name;

	@XmlElement(name="Value")
	private String value;
	
	@XmlElement(name="OldValue", required=false)
	private String oldValue;

	@XmlElement(name="DisplayName", required=false)
	private String displayName;
	
	@XmlElement(name="Mandatory", required=false)
	private boolean mandatory;

	@XmlElement(name="ReadOnly", required=false)
	private boolean readOnly;
	
	@XmlElement(name="Discovered", required=false)
	private boolean discovered;
		

	public FeatureEntity() {
	}
	
	public FeatureEntity(String name, String value) {
		this();
		this.name = name;
		this.value = value;
		this.displayName = name;
		this.discovered = true;
		this.mandatory = false;
		this.readOnly = false;
	}
	
	public FeatureEntity(String name, String value, String displayName, boolean discovered) {
		this();
		this.name = name;
		this.value = value;
		this.displayName = displayName;
		this.discovered = discovered;
		this.mandatory = (!discovered)?true:false;
		this.readOnly = false;
	}
	
	public FeatureEntity(String name, String value, String displayName, boolean discovered, boolean mandatory, boolean readOnly) {
		this();
		this.name = name;
		this.value = value;
		this.displayName = displayName;
		this.discovered = discovered;
		this.mandatory = mandatory;
		this.readOnly = readOnly;
	}

	public Object getId(){
		return id;
	}
	
	public void setId(Object id){
		this.id = id;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
	public String getOldValue() {
		return oldValue;
	}

	public void setOldValue(String oldValue) {
		this.oldValue = oldValue;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public boolean isMandatory() {
		return mandatory;
	}

	public void setMandatory(boolean mandatory) {
		this.mandatory = mandatory;
	}

	public boolean isReadOnly() {
		return readOnly;
	}

	public void setReadOnly(boolean readOnly) {
		this.readOnly = readOnly;
	}

	public boolean isDiscovered() {
		return discovered;
	}

	public void setDiscovered(boolean discovered) {
		this.discovered = discovered;
	}
	
	//Features in different entities may have the same name. Hence they should never be compared.   
	@Override
    public boolean equals(Object obj)
	{
		if (this == obj) return true;
        if ( !(obj instanceof FeatureEntity) ) return false;

        final FeatureEntity castObj =(FeatureEntity) obj;

        if ( castObj.getName() != null){
        	if ( castObj.getName().equals(getName())) return true;
        }
	        
        return false;

	}
	
	@Override
	public int hashCode()
	{
		if( getName() != null)
		{
			return (getName()).hashCode();
		}
		else 
		{
			return super.hashCode();
		}
	}
	
	@Override
	public String toString() 
	{
		return getName();
	}
	
	@Override
	public FeatureEntity clone()
	{
		FeatureEntity clone = new FeatureEntity();
		clone.setId(id);
		clone.setName(name);
		clone.setValue(value);
		clone.setOldValue(oldValue);
		clone.setDisplayName(displayName);
		clone.setMandatory(mandatory);
		clone.setReadOnly(readOnly);
		clone.setDiscovered(discovered);
		
		return clone;
	}
}
