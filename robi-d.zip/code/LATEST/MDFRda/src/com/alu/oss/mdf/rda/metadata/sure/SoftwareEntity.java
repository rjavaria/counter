package com.alu.oss.mdf.rda.metadata.sure;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)
public class SoftwareEntity extends Entity {
	
	private static final long serialVersionUID = -3325889404098689972L;

	@XmlElement(name="Vendor", required=false)
	private String vendor;
	
	@XmlElement(name="Version", required=false)
	private String version;
	
	@Override
	public List<String> getComparableAttributes()
	{
		return new ArrayList<String>(Arrays.asList("type", "discoveredName", "vendor", "version"));
	}
	
	public SoftwareEntity()
	{
		super(EntityType.SOFTWARE);
	}


	public String getVendor() {
		return vendor;
	}


	public void setVendor(String vendor) {
		this.vendor = vendor;
	}


	public String getVersion() {
		return version;
	}


	public void setVersion(String version) {
		this.version = version;
	}

	
	@Override
    public boolean equals(Object obj)
	{
		if (this == obj) return true;
        if ( !(obj instanceof SoftwareEntity) ) return false;

        final SoftwareEntity castObj =(SoftwareEntity) obj;

        if ( castObj.getName() != null){
        	if ( castObj.getName().equals(getName())) return true;
        }
	        
        return false;

	}
	
	@Override
	public SoftwareEntity clone()
	{
		SoftwareEntity clone = new SoftwareEntity();
		clone.setId(id);
		clone.setName(name);
		clone.setType(type);
		clone.setTemplate(template);
		clone.setState(state);
		clone.setStatus(status);
		clone.setFeatureEntities(featureEntities);
		clone.setDiscoveredName(discoveredName);
		clone.setNeName(neName);
		clone.setSequence(sequence);
		clone.setReconciliationGroup(reconciliationGroup);
		clone.setReconParents(reconParents);
		clone.setRoots(roots);
		
		clone.setVendor(vendor);	
		clone.setVersion(version);
		
		return clone;
	}
	
	@Override
	public SoftwareEntity cloneWithoutParents()
	{
		return this.clone();
	}
}
