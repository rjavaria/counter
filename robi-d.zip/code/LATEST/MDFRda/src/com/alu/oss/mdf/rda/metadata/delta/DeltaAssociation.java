package com.alu.oss.mdf.rda.metadata.delta;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.alu.oss.mdf.rda.metadata.sure.Entity;
import com.alu.oss.mdf.rda.metadata.sure.EntityType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "parentEntityType",
        "parentEntityName",
        "parentType",
        "childEntityType",
        "childEntityName",
        "childType",
        "sequence", 
        "reconciliationGroup",
        "reconParents",
	    "roots",
	    "additionalArgs"
    })
public class DeltaAssociation extends Delta{
	
	private static final long serialVersionUID = -7330557821656243759L;


	@XmlElement(name="ParentEntityType")
	private EntityType parentEntityType;
	
	@XmlElement(name="ParentEntityName")
	private String parentEntityName;
	
	@XmlElement(name="ParentType")
	private String parentType;
	
	@XmlElement(name="ChildEntityType")
	private EntityType childEntityType;
	
	@XmlElement(name="ChildEntityName")
	private String childEntityName;
	
	@XmlElement(name="ChildType")
	private String childType;
	
	@XmlElement(name="AdditionalArgs" , required=false)
	private String[] additionalArgs;
	
	
	public DeltaAssociation()
	{
	}

	public DeltaAssociation(EntityType parentEntityType, String parentEntityName, EntityType childEntityType, String childEntityName) {
		this();
		this.parentEntityType = parentEntityType;
		this.parentEntityName = parentEntityName;
		this.childEntityType = childEntityType;
		this.childEntityName = childEntityName;
	}
	
	public DeltaAssociation(EntityType parentEntityType, String parentEntityName, EntityType childEntityType, String childEntityName,String sequence) {
		this(parentEntityType, parentEntityName, childEntityType, childEntityName);
		this.sequence = sequence;
	}
	
	public DeltaAssociation(EntityType parentEntityType, String parentEntityName, EntityType childEntityType, String childEntityName,String sequence, String...additionalArgs) {
		this(parentEntityType, parentEntityName, childEntityType, childEntityName, sequence);
		this.setAdditionalArgs(additionalArgs);
	}

	public DeltaAssociation(Entity parentEntity, Entity childEntity, String sequence, String...additionalArgs) {
		this(parentEntity.getEntityType(), parentEntity.getName(), childEntity.getEntityType(), childEntity.getName(), sequence, additionalArgs);
		this.getReconParentEntityName().add(parentEntity.getName());
		this.getReconParentEntityName().add(childEntity.getName());
		this.getRootEntityName().addAll(parentEntity.getRoots());
		this.parentType = parentEntity.getType();
		this.childType = childEntity.getType();
		List<String> childRoots = childEntity.getRoots();
		for(String childRoot:childRoots)
		{
			if(!this.getRootEntityName().contains(childRoot))
				this.getRootEntityName().add(childRoot);
		}
	}
	
	public EntityType getParentEntityType() {
		return parentEntityType;
	}

	public void setParentEntityType(EntityType parentEntityType) {
		this.parentEntityType = parentEntityType;
	}

	public String getParentEntityName() {
		return parentEntityName;	
	}

	public void setParentEntityName(String parentEntityName) {
		this.parentEntityName = parentEntityName;
	}

	public EntityType getChildEntityType() {
		return childEntityType;
	}

	public void setChildEntityType(EntityType childEntityType) {
		this.childEntityType = childEntityType;
	}

	public String getChildEntityName() {
		return childEntityName;
	}

	public void setChildEntityName(String childEntityName) {
		this.childEntityName = childEntityName;
	}
	
	public String[] getAdditionalArgs() {
		return additionalArgs;
	}

	public void setAdditionalArgs(String[] additionalArgs) {
		this.additionalArgs = additionalArgs;	
		
	}
	
	@Override
	public String getEntityName() {
		return getParentEntityName()+"->"+getChildEntityName();
	}
	
	@Override
	public String toString()
	{
		return getParentEntityName()+"->"+getChildEntityName();
	}
	
	public String getParentType() {
		return parentType;
	}

	public void setParentType(String parentType) {
		this.parentType = parentType;
	}

	public String getChildType() {
		return childType;
	}

	public void setChildType(String childType) {
		this.childType = childType;
	}

	@Override
	public int hashCode()
	{
		if(getParentEntityName() != null && getChildEntityName()!=null)
		{
			return (getParentEntityName()+"->"+getChildEntityName()).hashCode();
		}
		else 
		{
			return super.hashCode();
		}
	}
	
	@Override
    public boolean equals(Object obj)
	{
		if (this == obj) return true;
        if ( !(obj instanceof DeltaAssociation) ) return false;

        final DeltaAssociation castObj =(DeltaAssociation) obj;

        if (castObj.getParentEntityName() != null && castObj.getChildEntityName()!=null)
        {
        	if (castObj.getParentEntityName().equals(getParentEntityName()) &&
        			castObj.getChildEntityName().equals(getChildEntityName())) 
        		return true;
        }
	        
        return false;

	}
}
