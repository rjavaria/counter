package com.alu.oss.mdf.rda.metadata.sure;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlEnum(String.class)
public enum EntityType {
	NETWORK, 
	EQUIPMENT, 
	TERMINATION, 
	LINK, 
	PATH,
	SERVICE,
	CUSTOMER,
	APPLICATION,
	COLLECTION,
	LOCATION,
	SOFTWARE,
	TERMINATION_TYPE,
	UNKNOWN,
	POLICY,
	POLICY_ASSOCIATION,
	CAPACITY,
	CAPACITYDEMAND,
	STATUS,
	STATE
}