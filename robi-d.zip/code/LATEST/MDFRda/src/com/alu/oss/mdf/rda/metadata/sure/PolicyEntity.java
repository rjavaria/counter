package com.alu.oss.mdf.rda.metadata.sure;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

import com.alu.oss.mdf.rda.metadata.sure.nm.NMEntityFactory;

@XmlAccessorType(XmlAccessType.FIELD)
public class PolicyEntity extends Entity {
	
	private static final long serialVersionUID = -9124735181281452180L;

	
	@XmlElementWrapper(name="PolicyAssociationEntities", required=false)
	@XmlElement(name="PolicyAssociationEntity", required=false)
	private List<PolicyAssociationEntity> policyAssociationEntity;
	
	@XmlElementWrapper(name="ParentPolicyNames", required=false)
	@XmlElement(name="ParentPolicyName", required=false)
	private List<String> parentPolicyNames = new ArrayList<String>();

	@Override
	public List<String> getComparableAttributes()
	{
		return new ArrayList<String>(Arrays.asList("type", "discoveredName"));
	}
	
	public PolicyEntity() {
		super( EntityType.POLICY);
	}
	
	
	public List<PolicyAssociationEntity> getPolicyAssociationEntity() {
		return policyAssociationEntity;
	}


	public void setPolicyAssociationEntity(List<PolicyAssociationEntity> policyAssociation) {
		this.policyAssociationEntity = policyAssociation;
	}

	public List<String> getParentPolicyNames() {
		return parentPolicyNames;
	}



	public void setParentPolicyNames(List<String> parentPolicyNames) {
		this.parentPolicyNames = parentPolicyNames;
	}

	
	@Override
    public boolean equals(Object obj)
	{
		if (this == obj) return true;
        if ( !(obj instanceof PolicyEntity) ) return false;

        final PolicyEntity castObj =(PolicyEntity) obj;

        if ( castObj.getName() != null){
        	if ( castObj.getName().equals(getName())) return true;
        }
	        
        return false;

	}
	
	@Override
	public List<Entity> getParents() 
	{
		List<Entity> parents = new ArrayList<Entity>();
		parents.addAll(this.getParents(EntityType.POLICY));
		return parents;
	}
	
	@Override
	public List<Entity> getParents(EntityType parentEntityType) 
	{
		List<Entity> parents = new ArrayList<Entity>();
		
		if(parentEntityType == EntityType.POLICY)
		if(getParentPolicyNames() != null && !getParentPolicyNames().isEmpty())
		{
			for(String parentPolicy:getParentPolicyNames())
			{
				try {
					parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.POLICY,parentPolicy));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return parents;
	}
	
	@Override
	public PolicyEntity clone()
	{
		PolicyEntity clone = new PolicyEntity();
		clone.setId(id);
		clone.setName(name);
		clone.setType(type);
		clone.setTemplate(template);
		clone.setState(state);
		clone.setStatus(status);
		clone.setFeatureEntities(featureEntities);
		clone.setDiscoveredName(discoveredName);
		clone.setNeName(neName);
		clone.setSequence(sequence);
		clone.setReconciliationGroup(reconciliationGroup);
		clone.setReconParents(reconParents);
		clone.setRoots(roots);
		
		clone.setPolicyAssociationEntity(policyAssociationEntity);
		clone.setParentPolicyNames(parentPolicyNames);
		
		return clone;
	}
	
	@Override
	public PolicyEntity cloneWithoutParents()
	{
		PolicyEntity clone = this.clone();
		clone.setParentPolicyNames(null);
		return clone;
	}
}
