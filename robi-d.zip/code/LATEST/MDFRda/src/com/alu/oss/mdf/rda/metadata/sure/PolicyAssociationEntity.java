package com.alu.oss.mdf.rda.metadata.sure;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;

public class PolicyAssociationEntity extends Entity {
	
	private static final long serialVersionUID = -9124735181281452180L;

	
	@XmlElement(name="ParentEntityType", required=false)
	
	private String parentEntityType;
	
	
	@XmlElement(name="ParentEntityName", required=false)
	private String parentEntityName;

	@Override
	public List<String> getComparableAttributes()
	{
		return new ArrayList<String>(Arrays.asList("type", "discoveredName"));
	}
	
	public PolicyAssociationEntity() {
		super(EntityType.POLICY_ASSOCIATION);
	}
	
	public String getParentEntityType() {
		return parentEntityType;
	}
	
	public void setParentEntityType(String parentEntityType) {
		this.parentEntityType = parentEntityType;
	}

	public String getParentEntityName() {
		return parentEntityName;
	}

	public void setParentEntityName(String parentEntityName) {
		this.parentEntityName = parentEntityName;
	}
	
	@Override
    public boolean equals(Object obj)
	{
		if (this == obj) return true;
        if ( !(obj instanceof PolicyAssociationEntity) ) return false;

        final PolicyAssociationEntity castObj =(PolicyAssociationEntity) obj;

        if ( castObj.getName() != null){
        	if ( castObj.getName().equals(getName())) return true;
        }
	        
        return false;

	}
	
	@Override
	public PolicyAssociationEntity clone()
	{
		PolicyAssociationEntity clone = new PolicyAssociationEntity();
		clone.setId(id);
		clone.setName(name);
		clone.setType(type);
		clone.setTemplate(template);
		clone.setState(state);
		clone.setStatus(status);
		clone.setFeatureEntities(featureEntities);
		clone.setDiscoveredName(discoveredName);
		clone.setNeName(neName);
		clone.setSequence(sequence);
		clone.setReconciliationGroup(reconciliationGroup);
		clone.setReconParents(reconParents);
		clone.setRoots(roots);
		
		clone.setParentEntityType(parentEntityType);
		clone.setParentEntityName(parentEntityName);	
		
		return clone;
	}
	
	@Override
	public PolicyAssociationEntity cloneWithoutParents()
	{
		return this.clone();
	}

}
