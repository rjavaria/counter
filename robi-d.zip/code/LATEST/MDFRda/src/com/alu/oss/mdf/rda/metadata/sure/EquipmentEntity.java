package com.alu.oss.mdf.rda.metadata.sure;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

import com.alu.oss.mdf.rda.metadata.sure.nm.NMEntityFactory;


@XmlAccessorType(XmlAccessType.FIELD)
public class EquipmentEntity extends Entity {


	private static final long serialVersionUID = -9124735181281452180L;


	@XmlElementWrapper(name="NetworkNames", required=false)
	@XmlElement(name="NetworkName", required=false)
	private List<String> networkName = new ArrayList<String>();

	@XmlElement(name="PositionNumber", required=false)
	private String positionNumber;

	@XmlElement(name="CollectionName", required=false)
	private String collectionName;

	@XmlElement(name="LocationName", required=false)
	private String locationName;

	@XmlElement(name="ParentEquipmentName", required=false)
	private String parentEquipmentName;

	@Override
	public List<String> getComparableAttributes()
	{
		return new ArrayList<String>(Arrays.asList("type", "discoveredName", "positionNumber"));
	}

	public EquipmentEntity()
	{
		super(EntityType.EQUIPMENT);
	}

	public String getParentEquipmentName() {
		return parentEquipmentName;
	}

	public void setParentEquipmentName(String parentEquipmentName) {
		this.parentEquipmentName = parentEquipmentName;
	}


	public List<String> getNetworkName() {
		return networkName;
	}

	public void setNetworkName(List<String> networkName) {
		this.networkName = networkName;
	}

	//Append Network Name  added through Rule file in the  Network Name List
	public void addNetworkName(List<String> pNetworks)
	{
		
		this.networkName.addAll(pNetworks);
				
	}
	
	public String getPositionNumber() {
		return positionNumber;
	}


	public void setPositionNumber(String positionNumber) {
		this.positionNumber = positionNumber;
	}


	public String getCollectionName() {
		return collectionName;
	}

	public void setCollectionName(String collectionName) {
		this.collectionName = collectionName;
	}

	public String getLocationName() {
		return locationName;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj) return true;
		if ( !(obj instanceof EquipmentEntity) ) return false;

		final EquipmentEntity castObj =(EquipmentEntity) obj;

		if ( castObj.getName() != null){
			if ( castObj.getName().equals(getName())) return true;
		}

		return false;

	}

	@Override
	public List<Entity> getParents() 
	{
		List<Entity> parents = new ArrayList<Entity>();
		parents.addAll(this.getParents(EntityType.EQUIPMENT));
		parents.addAll(this.getParents(EntityType.LOCATION));
		parents.addAll(this.getParents(EntityType.COLLECTION));
		parents.addAll(this.getParents(EntityType.NETWORK));
		parents.addAll(this.getParents(EntityType.STATE));
		parents.addAll(this.getParents(EntityType.STATUS));
		return parents;
	}

	@Override
	public List<Entity> getParents(EntityType parentEntityType) 
	{
		List<Entity> parents = new ArrayList<Entity>();
		
		if(parentEntityType == EntityType.EQUIPMENT)
		if(getParentEquipmentName() != null && !getParentEquipmentName().isEmpty())
		{
			try {
				parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.EQUIPMENT,getParentEquipmentName()));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if(parentEntityType == EntityType.LOCATION)
		if(getLocationName() != null && !getLocationName().isEmpty())
		{
			try {
				parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.LOCATION,getLocationName()));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if(parentEntityType == EntityType.COLLECTION)
		if(getCollectionName() != null && !getCollectionName().isEmpty())
		{
			try {
				parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.COLLECTION,getCollectionName()));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if(parentEntityType == EntityType.NETWORK)
		if(getNetworkName() != null && !getNetworkName().isEmpty())
		{
			try {
				List<String> neList = getNetworkName();
				for (int i = 0; i < neList.size(); i++) {
					parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.NETWORK,neList.get(i)));
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if(parentEntityType == EntityType.STATE)
		if(getState() != null && !getState().isEmpty())
		{
			try {
				parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.STATE,getState()));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if(parentEntityType == EntityType.STATUS)
		if(getStatus() != null && !getStatus().isEmpty())
		{
			try {
				parents.add(NMEntityFactory.getRdaMetaEntity(EntityType.STATUS,getStatus()));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return parents;
	}
	
	@Override
	public ReconciliationGroup getReconciliationGroup() {
		return ReconciliationGroup.INFRASTRUCTURE;
	}

	@Override
	public EquipmentEntity clone()
	{
		EquipmentEntity clone = new EquipmentEntity();
		clone.setId(id);
		clone.setName(name);
		clone.setNeName(neName);
		clone.setType(type);
		clone.setTemplate(template);
		clone.setState(state);
		clone.setStatus(status);
		clone.setFeatureEntities(featureEntities);
		clone.setDiscoveredName(discoveredName);
		clone.setSequence(sequence);
		clone.setReconciliationGroup(reconciliationGroup);
		clone.setReconParents(reconParents);
		clone.setRoots(roots);

		clone.setNetworkName(networkName);
		clone.setPositionNumber(positionNumber);
		clone.setCollectionName(collectionName);
		clone.setLocationName(locationName);
		clone.setParentEquipmentName(parentEquipmentName);

		return clone;
	}

	@Override
	public EquipmentEntity cloneWithoutParents()
	{
		EquipmentEntity clone = this.clone();
		clone.setParentEquipmentName(null);
		clone.setCollectionName(null);
		clone.setLocationName(null);
		clone.setNetworkName(null);

		return clone;
	}

	@Override
	public EquipmentEntity cloneWithoutParent(Entity parentEntity)
	{
		EquipmentEntity clone = this.clone();
		if(parentEntity.getEntityType() == EntityType.EQUIPMENT)
			clone.setParentEquipmentName(null);
		
		return clone;
	}
}
