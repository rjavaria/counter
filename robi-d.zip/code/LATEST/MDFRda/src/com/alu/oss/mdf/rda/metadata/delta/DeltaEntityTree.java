package com.alu.oss.mdf.rda.metadata.delta;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

public class DeltaEntityTree {

	SortedMap<Integer,List<DeltaEntity>> deltaEntityTree = null;
	Iterator<Integer> sequences;

	public DeltaEntityTree()
	{
		deltaEntityTree = Collections.synchronizedSortedMap(new TreeMap<Integer,List<DeltaEntity>>());
	}

	public DeltaEntityTree(List<DeltaEntity> deltaEntities)
	{
		deltaEntityTree = Collections.synchronizedSortedMap(new TreeMap<Integer,List<DeltaEntity>>());
		for(DeltaEntity deltaEntity:deltaEntities)
			addDeltaEntity(deltaEntity);
	}

	public void addDeltaEntity(DeltaEntity deltaEntity){
		try{
			String seqNo = deltaEntity.getSequence();
			if(seqNo == null)
				seqNo = "999999";
			List<DeltaEntity> llstDeltaEntity = deltaEntityTree.get(Integer.parseInt(seqNo));
			if(llstDeltaEntity==null){
				llstDeltaEntity = new ArrayList<DeltaEntity>();
				llstDeltaEntity.add(deltaEntity);
				deltaEntityTree.put(Integer.parseInt(seqNo),llstDeltaEntity);
			}
			else{
				llstDeltaEntity.add(deltaEntity);
				deltaEntityTree.put(Integer.parseInt(seqNo),llstDeltaEntity);
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

	public Map<Integer,List<DeltaEntity>> getTree(){
		return deltaEntityTree;
	}

	public boolean hasBuckets(){
		boolean hasNext = false;
		try{
			if(sequences==null){
				if(!deltaEntityTree.isEmpty()){
					sequences = deltaEntityTree.keySet().iterator();
					hasNext = true;
				}
			}
			else{
				hasNext = sequences.hasNext();
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return hasNext;
	}

	public List<DeltaEntity> nextBucket() {
		return deltaEntityTree.get(sequences.next());
	}
}
