package nokia.rtorkel.robi.eric_iptnms;

import java.io.File;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import rasmus_torkel.text.write.IndentingLineSink;
import rasmus_torkel.xml_basic.read.TagNode;
import rasmus_torkel.xml_basic.read.XmlReadOptions;
import rasmus_torkel.xml_basic.read.impl.XmlReader;

public abstract class CrossConnection
{
    private static final Logger _logger = LogManager.getLogger(CrossConnection.class);
    
    public final String      _id;
    public final String      _type;
    public final String      _signalType;
    public final String      _directionality;
    
    @Override
    public String
    toString()
    {
        return _id + " " + _type + " " + _signalType + " " + _directionality;
    }
    
    public String
    toSlightlyShorterString()
    {
        return _id + " " + _type + " " + _signalType + " " + _directionality;
    }
    
    public
    CrossConnection(TagNode node)
    {
        _type = node._id._relativeName;
        TagNode ccNode = node.nextChildE("CrossConnection");
        _id = ccNode.attributeValueE("Id");
        ccNode.nextChildE("CrossConnection.subNetworkId");
        ccNode.nextChildE("CrossConnection.ccId");
        _signalType =
                EricssonXmlUtil.nextEnumFieldE(
                        ccNode, "CrossConnection.signalType", "DTCCSignalType");
        _directionality =
                EricssonXmlUtil.nextEnumFieldE(
                        ccNode, "CrossConnection.directionality", "DTCCDirectionality");
        ccNode.verifyNoMoreChildren();
    }
    
    protected AccessPoint
    lookUpAp(String                 apId,
             EricssonIptnmsEntities entities) throws EntityNotCreatedException
    {
        AccessPoint ap = entities.lookUpAp(apId);
        if (ap == null)
        {
            throw new EntityNotCreatedException(_id, "CrossConnect", apId, "AccessPoint", entities);
        }
        return ap;
    }
    
    public abstract void
    toIndentingLineSink(IndentingLineSink sink);
    
    public static void
    load(InputFileDirectory     dir,
         EricssonIptnmsEntities entities)
    {
        File neFile = dir.getInputFile("CrossConnection");
        TagNode rootNode = XmlReader.xmlFileToRoot(neFile, XmlReadOptions.DEFAULT, "NetworkManager");
        rootNode.nextChildE("Version");
        boolean haveSummary = false;
        int processedQty = 0;
        do
        {
            TagNode level1Node = rootNode.nextChildE();
            if (level1Node._id._relativeName.equals("SimpleCC"))
            {
                try
                {
                    new SimpleCC(level1Node, entities);
                }
                catch (EntityNotCreatedException e)
                {
                }
            }
            else if (level1Node._id._relativeName.equals("ProtectionCC"))
            {
                try
                {
                    new ProtectionCC(level1Node, entities);
                }
                catch (EntityNotCreatedException e)
                {
                }
            }
            else if (level1Node._id._relativeName.equals("Summary"))
            {
                rootNode.verifyNoMoreChildren();
                haveSummary = true;
            }
            else
            {
                throw new RuntimeException("Node with unexpected name: " + level1Node);
            }
            processedQty++;
            if (   processedQty == 1
                || processedQty == 10
                || processedQty == 100
                || processedQty == 1000
                || processedQty % 10000 == 0)
            {
                _logger.info("Processed " + processedQty);
            }
        } while (!haveSummary);
        _logger.info("Processed " + processedQty + ", finished CrossConnect entities");
    }
}
