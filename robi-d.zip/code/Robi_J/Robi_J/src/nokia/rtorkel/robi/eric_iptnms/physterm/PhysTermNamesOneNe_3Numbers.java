package nokia.rtorkel.robi.eric_iptnms.physterm;

import java.util.HashMap;
import java.util.Iterator;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import rasmus_torkel.xml_basic.rw.TagNodeId;
import rasmus_torkel.xml_basic.rw.XmlNameSpace;
import rasmus_torkel.xml_basic.write.XmlSink;
import rasmus_torkel.xml_basic.write.XmlSinkWritable;

public class PhysTermNamesOneNe_3Numbers implements XmlSinkWritable
{
    private static final Logger _logger = LogManager.getLogger(PhysTermNamesOneNe_3Numbers.class);
    private HashMap<String,String> _internalNameToDbName = new HashMap<String, String>();
    private final String _neName;
    
    public
    PhysTermNamesOneNe_3Numbers(TermNamesOnNeFinder      termNamesFinder,
                                String                   neName,
                                ShelfCardPortExtractor[] extractors)
    {
        _logger.debug("Initialising for " + neName);
        int acceptedQty = 0;
        int rejectedQty = 0;
        _neName = neName;
        String[] dbNames;
        try
        {
            dbNames = termNamesFinder.termNames(neName);
        }
        catch (Exception e)
        {
            String message = "Could not look up termination names for " + neName;
            _logger.error(message, e);
            throw new RuntimeException("Could not look up termination names for " + neName, e);
        }
        for (String dbName : dbNames)
        {
            String internalName = toInternalName(dbName, extractors);
            if (internalName != null)
            {
                _internalNameToDbName.put(internalName, dbName);
                if (acceptedQty == 0)
                {
                    _logger.debug(
                            "First name accepted after " + rejectedQty + " rejected: " +
                            dbName + " for " + internalName);
                }
                acceptedQty++;
            }
            else
            {
                if (rejectedQty == 0)
                {
                    _logger.debug(
                            "First name rejected after " + acceptedQty + " accepted: " +
                            dbName);
                }
                rejectedQty++;
            }
        }
        _logger.debug(
                "Finished initialising for " + neName +
                ", accepted " + acceptedQty + ", rejected " + rejectedQty);
    }
    
    private String
    toInternalName(String                   portNameFromDb,
                   ShelfCardPortExtractor[] extractors)
    {
        for (ShelfCardPortExtractor extractor : extractors)
        {
            String internalName = extractor.nameForInternalUse(_neName, portNameFromDb);
            if (internalName != null)
            {
                return internalName;
            }
        }
        return null;
    }
    
    public String
    dbName(int    shelf,
           int    card,
           int    port)
    {
        String internalName = _neName + "/" + shelf + "/" + card + "/" + port;
        return _internalNameToDbName.get(internalName);
    }
    
    TagNodeId NATURAL_TAG_NODE_ID = new TagNodeId("oneNe");

    @Override
    public TagNodeId naturalTagNodeId()
    {
        return NATURAL_TAG_NODE_ID;
    }

    @Override
    public void
    mostToXml(XmlSink      xmlSink,
              String       relativeName,
              XmlNameSpace nameSpace)
    {
        xmlSink.sinkSimpleNode("ne", _neName);
        xmlSink.startNode("mappings");
        Iterator<String> it = _internalNameToDbName.keySet().iterator();
        while (it.hasNext())
        {
            String internalName = it.next();
            String dbName = _internalNameToDbName.get(internalName);
            xmlSink.startNode("mapping");
            xmlSink.sinkSimpleNode("internalName", internalName);
            xmlSink.sinkSimpleNode("dbName", dbName);
            xmlSink.closeNode();
        }
        xmlSink.closeNode();
    }
}
