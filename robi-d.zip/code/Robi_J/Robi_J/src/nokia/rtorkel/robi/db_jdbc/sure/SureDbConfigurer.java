/*---------------------------------------------------------------------
 * (C) COPYRIGHT 2014 ALCATEL AUSTRALIA LIMITED
 * 
 * This program contains proprietary information which is a trade secret
 * of ALCATEL AUSTRALIA LIMITED and also is protected under the applicable
 * copyright law. Recipient is to retain this program in confidence and is
 * not permitted to use or make any copy thereof other than as permitted
 * under a written agreement with ALCATEL AUSTRALIA LIMITED.
 *-------------------------------------------------------------------*/
package nokia.rtorkel.robi.db_jdbc.sure;

import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.sql.Connection;
import java.sql.SQLException;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import nokia.rtorkel.robi.db_jdbc.DbHandle;
import nokia.rtorkel.robi.db_jdbc.DbHandleImpl;
import nokia.rtorkel.robi.db_jdbc.JdbcManager2;
import nokia.rtorkel.robi.db_jdbc.TransactionMode;
import rasmus_torkel.config.ConfigFileReader;
import rasmus_torkel.config.PropertiesView;

public class SureDbConfigurer
{
    private static final Logger _logger = LogManager.getLogger(SureDbConfigurer.class);
    
    public static final String XDM_DB_PARAM_NAME_PREFIX = "connection.";
    
    /**
     * Configures database access. This function is best used in situations where only one
     * connection is required per database instance.
     * @param contextLabel    For logging purposes. Keep this short like XDM DB
     * @param transactionMode For things like auto-commit
     * @param config          For configuration info
     * @param paramPrefix     For attaching relative names to to generate actual configuration
     *                        parameter names.
     * @return The database access handle
     * @throws InmException
     * @throws IxdbException 
     */
    public static DbHandleImpl
    configureHandle(String                contextLabel,
                    TransactionMode       transactionMode,
                    PropertiesView        config,
                    String                paramPrefix)
    {
        JdbcManager2 jdbcManager;
        try
        {
            jdbcManager = configureJdbcManager(config, paramPrefix);
        }
        catch (Exception e)
        {
            String message = "Could not configure JDBC manager: " + e;
            _logger.error(message, e);
            throw new RuntimeException(message, e);
        }
        try
        {
            Connection connection = jdbcManager.getConnection();
            Log4jDbContext context = new Log4jDbContext(contextLabel);
            DbHandleImpl db = new DbHandleImpl(connection, context, transactionMode);
            return db;
        }
        catch (SQLException e)
        {
            String message = "Could not connect to database: " + e;
            _logger.error(message, e);
            throw new RuntimeException(message, e);
        }
    }
    
    public static JdbcManager2
    configureJdbcManager(PropertiesView config,
                         String         paramPrefix) throws Exception
    {
        String url = config.stringE(paramPrefix + "url.SM");
        String userName = config.stringE(paramPrefix + "userName.SM");
        String password = config.stringE(paramPrefix + "password.SM");
        String driver = config.stringE("hibernate.connection.driver.class");
        JdbcManager2 jm = new JdbcManager2(url, userName, password, driver);
        _logger.debug("configureJdbcManager, url = " + jm.m_jdbcUrl);
        return jm;
    }
    
    public static PropertiesView
    getConfigurationFromResourceFile()
    {
        String resourceName = "MDLSureConfig.properties";
        return getConfigurationFromResourceFile(resourceName);
    }
    
    public static PropertiesView
    getConfigurationFromResourceFile(String resourceName)
    {
        ClassLoader loader = SureDbConfigurer.class.getClassLoader();
        _logger.debug("resourceName for DB params = " + resourceName);
        URL resourceUrl = loader.getResource(resourceName);
        _logger.debug("resourceUrl = " + resourceUrl);
        URI resourceUri;
        try
        {
            resourceUri = resourceUrl.toURI();
        }
        catch (URISyntaxException e)
        {
            String message = "Failed to convert URL " + resourceUrl + " to URI: " + e;
            _logger.error(message, e);
            throw new RuntimeException(message, e);
        }
        _logger.debug("resourceUri " + resourceUri);
        File file = new File(resourceUri);
        _logger.debug("file = " + file);
        PropertiesView config = ConfigFileReader.propertiesViewFromFile(file);
        return config;
    }
    
    public static void
    main(String[] args)
    {
        try
        {
            PropertiesView config = getConfigurationFromResourceFile();
            DbHandle db =
                    configureHandle("IXDB", TransactionMode.READ_ONLY, config, XDM_DB_PARAM_NAME_PREFIX);
            System.out.println("Loaded " + db.getClass().getName());
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}
