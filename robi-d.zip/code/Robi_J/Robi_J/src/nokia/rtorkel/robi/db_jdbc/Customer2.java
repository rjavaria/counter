/*---------------------------------------------------------------------
 * (C) COPYRIGHT 2015 ALCATEL-LUCENT AUSTRALIA LIMITED
 * 
 * This program contains proprietary information which is a trade secret
 * of ALCATEL AUSTRALIA LIMITED and also is protected under the applicable
 * copyright law. Recipient is to retain this program in confidence and is
 * not permitted to use or make any copy thereof other than as permitted
 * under a written agreement with ALCATEL AUSTRALIA LIMITED.
 *-------------------------------------------------------------------*/
package nokia.rtorkel.robi.db_jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * This class has been imported from the Australia XDM project and has not yet been adjusted.
 * Do not use in its current state.
 * 
 * @author rtorkel
 *
 */
public class Customer2 extends PrimaryEntity
{
    public final String m_status;
    public final String m_address;
    public final String m_phoneBiz;
    public final String m_phoneHome;
    public final String m_phoneMobile;
    public final String m_email;
    public final String m_rating;
    public final String m_nameDetail;

    protected
    Customer2(long   id,
              String name,
              String status,
              String address,
              String phoneBiz,
              String phoneHome,
              String phoneMobile,
              String email,
              String rating,
              String nameDetail,
              DbHandle db)
    {
        super(EntityType.Customer, id, name, null, null, db);
        m_status = status;
        m_address = address;
        m_phoneBiz = phoneBiz;
        m_phoneHome = phoneHome;
        m_phoneMobile = phoneMobile;
        m_email = email;
        m_rating = rating;
        m_nameDetail = nameDetail;
    }
    
    public Service2[]
    services() throws SQLException, DbException
    {
        return m_db.servicesByCustomer(this);
    }
    
    public static class CustomerTable extends PrimaryEntityTable
    {
        //public final EntityColumn m_idColumn;
        //public final EntityColumn m_nameColumn;
        //public final EntityColumn m_statusColumn;
        public final EntityColumn m_addressColumn;
        public final EntityColumn m_phoneBizColumn;
        public final EntityColumn m_phoneHomeColumn;
        public final EntityColumn m_phoneMobileColumn;
        public final EntityColumn m_emailColumn;
        public final EntityColumn m_ratingColumn;
        public final EntityColumn m_nameDetailColumn;
        
        protected CustomerTable()
        {
            // putting status as type is a fudge as customer does not have type
            // but the fudge should not be of any consequence.
            super("t_customer", "customer_id", "customer_name", "status", null);
            //m_idColumn = new EntityColumn(m_tableName, "customer_id");
            //m_nameColumn = new EntityColumn(m_tableName, "customer_name");
            //m_statusColumn = new EntityColumn(m_tableName, "status");
            m_addressColumn = new EntityColumn(m_tableName, "address");
            m_phoneBizColumn = new EntityColumn(m_tableName, "phone_biz");
            m_phoneHomeColumn = new EntityColumn(m_tableName, "phone_home");
            m_phoneMobileColumn = new EntityColumn(m_tableName, "phone_mobile");
            m_emailColumn = new EntityColumn(m_tableName, "email");
            m_ratingColumn = new EntityColumn(m_tableName, "rating");
            m_nameDetailColumn = new EntityColumn(m_tableName, "name_detail");
        }
        
        protected void
        doExtraColumns(StringBuilder buf,
                       String        tableLabel)
        {
            columnToSelectClause(buf, m_addressColumn, tableLabel);
            columnToSelectClause(buf, m_phoneBizColumn, tableLabel);
            columnToSelectClause(buf, m_phoneHomeColumn, tableLabel);
            columnToSelectClause(buf, m_phoneMobileColumn, tableLabel);
            columnToSelectClause(buf, m_emailColumn, tableLabel);
            columnToSelectClause(buf, m_ratingColumn, tableLabel);
            columnToSelectClause(buf, m_nameDetailColumn, tableLabel);
        }
    }
    
    public static final CustomerTable ENTITY_TABLE = new CustomerTable();
    
    public static Customer2
    fromResultSet(DbHandleImpl db,
                  ResultSet      rs) throws SQLException, DbException
    {
        long id = rs.getLong(1);
        String name = rs.getString(2);
        String status = rs.getString(3);
        String address = rs.getString(4);
        String phoneBiz = rs.getString(5);
        String phoneHome = rs.getString(6);
        String phoneMobile = rs.getString(7);
        String email = rs.getString(8);
        String rating = rs.getString(9);
        String nameDetail = rs.getString(10);
        return new Customer2(
                id, name,
                status,
                address, phoneBiz, phoneHome, phoneMobile, email, rating, nameDetail,
                db);
    }
    
    @Override
    public String
    toString()
    {
        return m_entityType.m_lCase + "|" + m_id + "|" + m_name + "|" +
               m_status + "|" +
               m_address + "|" +
               m_phoneBiz + "|" +
               m_phoneHome + "|" +
               m_phoneMobile + "|" +
               m_email + "|" +
               m_rating + "|" +
               m_nameDetail;
    }

    @Override
    public void
    format(ObjectFormatter formatter,
           String          title)
    {
        formatter.appendTitle(title);
        formatter.incrementLevel();
        formatter.appendField("id", m_id);
        formatter.appendField("name", m_name);
        formatter.appendField("status", m_status);
        formatter.appendField("address", m_address);
        formatter.appendField("phoneBiz", m_phoneBiz);
        formatter.appendField("phonehome", m_phoneHome);
        formatter.appendField("phoneMobile", m_phoneMobile);
        formatter.appendField("email", m_email);
        formatter.appendField("rating", m_rating);
        formatter.appendField("nameDetail", m_nameDetail);
        formatter.decrementLevel();
    }

    @Override
    public PrimaryEntityTable entityTable()
    {
        return ENTITY_TABLE;
    }

    @Override
    public FeatureTable featureTable()
    {
        return null;
    }

    @Override
    public Feature2[] lookUpFeatures() throws SQLException
    {
        return new Feature2[]{};
    }

}
