package nokia.rtorkel.robi.eric_iptnms;

import java.io.File;
import java.util.ArrayList;

import rasmus_torkel.text.write.IndentingLineSink;
import rasmus_torkel.xml_basic.read.TagNode;
import rasmus_torkel.xml_basic.read.XmlReadOptions;
import rasmus_torkel.xml_basic.read.impl.XmlReader;

public class HOLink extends Link implements ReportingEntity
{
    public final int      _capacity;
    public final String   _protectionType;
    public final PhLink[] _phLinks;
    
    public String
    toShortString()
    {
        return super.toShortString() + " " + _capacity + " " + _protectionType;
    }
    
    public
    HOLink(TagNode                node,
           EricssonIptnmsEntities entities) throws EntityNotCreatedException
    {
        super(node.nextChildE("Link"), entities);
        ArrayList<PhLink> phLinkAl = new ArrayList<PhLink>();
        boolean finishedPhLinks = false;
        while (!finishedPhLinks)
        {
            String phLinkId = EricssonXmlUtil.nextIdFieldN(node, "HOLink.phLink", "Link");
            if (phLinkId != null)
            {
                PhLink phLink = entities.lookUpPhLk(phLinkId);
                if (phLink == null)
                {
                    throw new EntityNotCreatedException(_id, "HOLink", phLinkId, "PhLink", entities);
                }
                phLinkAl.add(phLink);
            }
            else
            {
                finishedPhLinks = true;
            }
        }
        _phLinks = new PhLink[phLinkAl.size()];
        phLinkAl.toArray(_phLinks);
        _capacity = EricssonXmlUtil.nextIntFieldE(node, "HOLink.capacity");
        _protectionType = EricssonXmlUtil.nextEnumFieldE(node, "HOLink.protectionType", "DTProtectionType");
        node.verifyNoMoreChildren();
        entities.putHoLk(this);
    }
    
    public static void
    load(InputFileDirectory     dir,
         EricssonIptnmsEntities entities)
    {
        File neFile = dir.getInputFile("HOLink");
        TagNode rootNode = XmlReader.xmlFileToRoot(neFile, XmlReadOptions.DEFAULT, "NetworkManager");
        rootNode.nextChildE("Version");
        boolean haveSummary = false;
        do
        {
            TagNode level1Node = rootNode.nextChildE();
            if (level1Node._id._relativeName.equals("HOLink"))
            {
                try
                {
                    new HOLink(level1Node, entities);
                }
                catch (EntityNotCreatedException e)
                {
                }
            }
            else if (level1Node._id._relativeName.equals("Summary"))
            {
                rootNode.verifyNoMoreChildren();
                haveSummary = true;
            }
            else
            {
                throw new RuntimeException("Node with unexpected name: " + level1Node);
            }
        } while (!haveSummary);
    }
    
    @Override
    public void
    makeReport(IndentingLineSink sink)
    {
        toIndentingLineSink(sink);
    }
    
    public void
    toIndentingLineSink(IndentingLineSink sink)
    {
        sink.writeLine(toShortString());
        sink.incrementLevel();
        sink.writeLine(_fromTp.toString());
        sink.writeLine(_toTp.toString());
        for (PhLink phLink : _phLinks)
        {
            phLink.toIndentingLineSink(sink);
        }
        sink.decrementLevel();
    }
}
