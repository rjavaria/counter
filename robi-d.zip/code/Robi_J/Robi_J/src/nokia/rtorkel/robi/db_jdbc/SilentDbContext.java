/*---------------------------------------------------------------------
 * (C) COPYRIGHT 2015 ALCATEL-LUCENT AUSTRALIA LIMITED
 * 
 * This program contains proprietary information which is a trade secret
 * of ALCATEL-LUCENT AUSTRALIA LIMITED and also is protected under the applicable
 * copyright law. Recipient is to retain this program in confidence and is
 * not permitted to use or make any copy thereof other than as permitted
 * under a written agreement with ALCATEL-LUCENT AUSTRALIA LIMITED.
 *-------------------------------------------------------------------*/
package nokia.rtorkel.robi.db_jdbc;

public class SilentDbContext extends DbContext
{
    public static final SilentDbContext INSTANCE = new SilentDbContext();
    
    public SilentDbContext()
    {
        super("no_context_label");
    }
    
    public SilentDbContext(String contextName)
    {
        super(contextName);
    }

    @Override
    protected void outputMessage(String message)
    {
        // Do nothing
    }
}
