package nokia.rtorkel.robi.eric_iptnms;

import java.io.File;

import rasmus_torkel.xml_basic.read.TagNode;
import rasmus_torkel.xml_basic.read.XmlReadOptions;
import rasmus_torkel.xml_basic.read.impl.XmlReader;

public class Subnetwork
{
    public final String         _id;
    public final String         _name;
    public final int            _subnetNr;
    public final String         _nestedName;
    public final Subnetwork     _parent;
    public final NetworkElement _ne;
    public final String         _neName;
    
    @Override
    public String
    toString()
    {
        return _id + " " + _name + " " + _nestedName + " " + (_ne == null ? "supports no NE" : "supports " + _ne._name);
    }
    
    public
    Subnetwork(TagNode                node,
               EricssonIptnmsEntities entities)
    {
        TagNode subnetNode = node.nextChildE("SubNetwork");
        _id = subnetNode.attributeValueE("Id");
        TagNode parentIdNode = subnetNode.nextChildN("SubNetwork.subNetworkFather");
        if (parentIdNode != null)
        {
            String parentId = parentIdNode.attributeValueE("SubNetwork");
            _parent = entities.lookUpSubnet(parentId);
            if (_parent == null)
            {
                throw new RuntimeException(
                        "Subnetwork " + _id + " references non-existent parent " + parentId);
            }
        }
        else
        {
            _parent = null;
        }
        _subnetNr = EricssonXmlUtil.nextIntFieldE(subnetNode, "SubNetwork.subNetworkId");
        _name = EricssonXmlUtil.nextTextFieldE(subnetNode, "SubNetwork.longName");
        subnetNode.nextChildE("SubNetwork.shortName");
        subnetNode.nextChildE("SubNetwork.suffix");
        subnetNode.nextChildE("SubNetwork.nestingLevel");
        subnetNode.nextChildE("SubNetwork.xCoord");
        subnetNode.nextChildE("SubNetwork.yCoord");
        subnetNode.verifyNoMoreChildren();
        TagNode neNode = node.nextChildN("RealSubNetwork.theNetworkElement");
        if (neNode != null)
        {
            String neId = neNode.attributeValueE("NetworkElement");
            _ne = entities.lookUpNe(neId);
            if (_ne == null)
            {
                //throw new RuntimeException(
                //        "Subnetwork " + _id + " references non-existent NetworkElement " + neId);
            }
            else
            {
                if (_ne._subnet != null)
                {
                    throw new RuntimeException(
                            "Network element " + _ne._id +
                            " is in subnetworks " + _ne._subnet._id +
                            " and " + _id);
                }
                _ne._subnet = this;
                if (_ne._subnet._parent == null)
                {
                    throw new RuntimeException(
                            "Network element " + _ne._id +
                            " is in subnetworks " + _ne._subnet._id +
                            " which has no parent");
                }
            }
            neNode.verifyNoMoreChildren();
        }
        else
        {
            _ne = null;
        }
        String neNameThroughVirtual = null;
        if (node._id._relativeName.equals("VirtualSubNetwork"))
        {
            /*int neIdOnEm = */EricssonXmlUtil.nextIntFieldE(node, "VirtualSubNetwork.NEIdOnEM");
            /*String emName = */EricssonXmlUtil.nextTextFieldE(node, "VirtualSubNetwork.EMName");
            neNameThroughVirtual = "virtualSubnet_" + _subnetNr;
        }
        node.verifyNoMoreChildren();
        entities.putSubnet(this);
        if (_parent == null)
        {
            _nestedName = _name;
        }
        else
        {
            _nestedName = _parent._name + "/" + _name;
        }
        if (_ne != null)
        {
            _neName = _ne._name;
        }
        else if (neNameThroughVirtual != null)
        {
            _neName = neNameThroughVirtual;
        }
        else
        {
            _neName = null;
        }
    }
    
    public static void
    load(InputFileDirectory     dir,
         EricssonIptnmsEntities entities)
    {
        File neFile = dir.getInputFile("Subnetwork");
        TagNode rootNode = XmlReader.xmlFileToRoot(neFile, XmlReadOptions.DEFAULT, "NetworkManager");
        rootNode.nextChildE("Version");
        boolean haveSummary = false;
        do
        {
            TagNode level1Node = rootNode.nextChildE();
            if (   level1Node._id._relativeName.equals("RealSubNetwork")
                || level1Node._id._relativeName.equals("VirtualSubNetwork"))
            {
                new Subnetwork(level1Node, entities);
            }
            else if (level1Node._id._relativeName.equals("Summary"))
            {
                rootNode.verifyNoMoreChildren();
                haveSummary = true;
            }
            else
            {
                throw new RuntimeException("Node with unexpected name: " + level1Node);
            }
        } while (!haveSummary);
    }
}