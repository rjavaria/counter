package nokia.rtorkel.robi.db_jdbc._test;

import nokia.rtorkel.robi.db_jdbc.Capacity2;
import nokia.rtorkel.robi.db_jdbc.DbHandle;
import nokia.rtorkel.robi.db_jdbc.DbHandleImpl;
import nokia.rtorkel.robi.db_jdbc.Link2;
import nokia.rtorkel.robi.db_jdbc.ObjectFormatter;

public class LinkByNameFinder extends DbUnitTest
{
    public static void
    main(String[] args)
    {
        try
        {
            DbHandleImpl db = makeDbHandle(args, "linkName");
            testRead(db, args[3]);
        }
        catch (Exception e)
        {
            e.printStackTrace(System.out);
        }
    }
    
    public static void
    testRead(DbHandle db,
             String   name) throws Exception
    {
        Link2 link = db.linkByName(name);
        String linkDump = ObjectFormatter.toString("link", link);
        System.out.println(linkDump);
        Capacity2[] capacities = link.capacities();
        String capacityDump = null;
        if (capacities.length > 0)
        {
            capacityDump = ObjectFormatter.toString("firstCapacity", capacities[0]);
        }
        
        System.out.println(linkDump);
        if (capacityDump != null)
        {
            System.out.println(capacityDump);
        }
        else
        {
            System.out.println("No capacity");
        }
    }
}
