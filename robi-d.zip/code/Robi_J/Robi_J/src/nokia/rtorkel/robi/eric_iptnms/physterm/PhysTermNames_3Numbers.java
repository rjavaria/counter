package nokia.rtorkel.robi.eric_iptnms.physterm;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;

import nokia.rtorkel.robi.db_jdbc.DbHandle;
import rasmus_torkel.config.PropertiesView;
import rasmus_torkel.xml_basic.rw.TagNodeId;
import rasmus_torkel.xml_basic.rw.XmlNameSpace;
import rasmus_torkel.xml_basic.write.XmlSink;
import rasmus_torkel.xml_basic.write.XmlSinkWritable;

public class PhysTermNames_3Numbers implements PortNameFinder, XmlSinkWritable
{
    //private static final Logger _logger = LogManager.getLogger(PhysTermNames_3Numbers.class);
    
    public final boolean _makesFresh;
    
    private final TermNamesOnNeFinder      _termNamesFinder;
    private final ShelfCardPortExtractor[] _extractors;
    private final File                     _mappingFile;
    
    private HashMap<String, PhysTermNamesOneNe_3Numbers> _neNameToTermNames =
                new HashMap<String, PhysTermNamesOneNe_3Numbers>();
    
    public
    PhysTermNames_3Numbers(TermNamesOnNeFinder termNamesFinder,
                           ShelfCardPortExtractor[] extractors,
                           File                     mappingFile)
    {
        _termNamesFinder = termNamesFinder;
        _extractors = extractors;
        _mappingFile = mappingFile;
        _makesFresh = true;
    }

    @Override
    public String
    findPortName(String neName,
                 String portType,
                 int    shelf,
                 int    card,
                 int    port)
    {
        PhysTermNamesOneNe_3Numbers termNamesForNe = _neNameToTermNames.get(neName);
        if (termNamesForNe == null)
        {
            termNamesForNe = new PhysTermNamesOneNe_3Numbers(_termNamesFinder, neName, _extractors);
            _neNameToTermNames.put(neName, termNamesForNe);
        }
        String dbName = termNamesForNe.dbName(shelf, card, port);
        return dbName;
    }
    
    public static PhysTermNames_3Numbers
    make(DbHandle       db,
         PropertiesView propView,
         File           mappingFile)
    {
        JdbcTermNamesOnNeFinder termNamesFinder = new JdbcTermNamesOnNeFinder(db);
        ShelfCardPortExtractor[] extractors = ShelfCardPortExtractor.makeExtractors(propView);
        return new PhysTermNames_3Numbers(termNamesFinder, extractors, mappingFile);
    }
    
    public void
    toXmlFile()
    {
        XmlSink xmlSink = new XmlSink(_mappingFile);
        xmlSink.sinkNode(this);
    }
    
    public static final TagNodeId NATURAL_TAG_NODE_ID = new TagNodeId("allNes");

    @Override
    public TagNodeId naturalTagNodeId()
    {
        return NATURAL_TAG_NODE_ID;
    }

    @Override
    public void
    mostToXml(XmlSink      xmlSink,
              String       relativeName,
              XmlNameSpace nameSpace)
    {
        Iterator<String> it = _neNameToTermNames.keySet().iterator();
        while (it.hasNext())
        {
            String neName = it.next();
            PhysTermNamesOneNe_3Numbers oneNe = _neNameToTermNames.get(neName);
            xmlSink.sinkNode(oneNe);
        }
    }
}
