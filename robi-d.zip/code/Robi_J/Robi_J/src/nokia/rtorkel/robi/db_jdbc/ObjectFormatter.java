package nokia.rtorkel.robi.db_jdbc;

/**
 * @author torkel
 * 
 * This class is used to print information in a structured manner.
 * It is intended that objects which are big enough to be printed
 * over multiple lines use this to save themselves a lot of code
 * and to achieve uniform formatting.
 * <p>
 * A general rule applying to the various methods is that anything
 * printable can be null. In that case, it simply will not be printed.
 * <p>
 * Unit testing is not comprehensive, but there is a mini test in the
 * main function, which also serves as a demo.
 */
public class ObjectFormatter
{
    /**
     * @author rtorkel
     *
     * If an application class implement this, it will be easy to
     * format arrays of objects of that class using the
     * format(String, Formattable[]) method.
     */
    public static interface Formattable
    {
        public void
        format(ObjectFormatter formatter,
               String          title);
    }
    
	private static final String INDENT = "  ";
	public  static final String EQUALS = " = ";
	public  static final String BLOCK_BEGIN = "{";
	public  static final String BLOCK_END = "}";
	
	/**
	 * Initial line prefix plus whatever indentation has been applied
	 * due to incrementing indentation level.
	 */
	private String       myLinePrefix;
	
	/**
	 * Will never be negative.
	 */
	private int          myIndentLevel = 0;
	
	/**
	 * Used as a tool by this class.
	 */
	private StringBuffer myBuf = new StringBuffer();
	
	/**
	 * Simple constructor
	 */
	public
	ObjectFormatter()
	{
		myLinePrefix = "";
	}
	
	/**
	 * Constructor for when it is desirable to put the same prefix
	 * in front of every line of formatted output.
	 */
	public
	ObjectFormatter(String linePrefix)
	{
		if (linePrefix != null)
		{
			myLinePrefix = linePrefix;
		}
		else
		{
			myLinePrefix = "";
		}
	}
    
    public String
    getLinePrefix()
    {
        return myLinePrefix;
    }

    /**
     * Discards all generated text but maintains line prefix and indent level.
     * This function is useful when formatting a large amount of output that
     * ultimately goes to an out-of-memory destination such as a file.
     * By allowing formatted text to be generated and discarded in pieces,
     * memory usage is reduced.
     */
    public void
    clear()
    {
        myBuf = new StringBuffer();
    }

	/**
	 * Use this to open an indented block. This method also puts the
	 * block's opening delimiter. Blocks may be nested.
	 */
	public void
	incrementLevel()
	{
		appendLine("{");
		myIndentLevel++;
		myLinePrefix = myLinePrefix + INDENT;
	}
	
	/**
	 * Use this to close an indented block. This method also puts the
	 * block's closing delimiter.
	 * 
	 * Do not use this function if the object is not in an indented block.
	 */
	public void
	decrementLevel()
	{
		if (myIndentLevel <= 0)
		{
			throw new RuntimeException(
				"Level more often decremented than incremented");
		}
		myIndentLevel--;
		myLinePrefix =
			myLinePrefix.substring(0, myLinePrefix.length() - INDENT.length());
		appendLine("}");
	}
	
	/**
	 * Formats an array of objects into its own indented block.
	 * 
	 * @param title   The title. Put null if not required.
	 * @param objects The objects to be formatted. May be null in which
	 *                case no formatting happens. Each object's toString
	 *                function is used to get text for that object. It is
	 *                assumed that the toString function for each object
	 *                returns a string without line terminator.
	 */
	public void
	appendOnePerLine(String       title,
	                 Object[]     objects)
	{
		if (objects != null)
		{
			appendTitle(title);
			incrementLevel();
			for (int i = 0; i < objects.length; i++)
			{
				appendLine(objects[i]);
			}
			decrementLevel();
		}
	}

    /**
     * Formats an array of ints into its own indented block.
     * 
     * @param title The title. Put null if not required.
     * @param a     The ints to be formatted. May be null in which
     *              case no formatting happens.
     */
    public void
    appendOnePerLine(String title,
                     int[]  a)
    {
        if (a != null)
        {
            appendTitle(title);
            incrementLevel();
            for (int i = 0; i < a.length; i++)
            {
                appendLine("" + a[i]);
            }
            decrementLevel();
        }
    }

    /**
     * Formats an array of chars into its own indented block.
     * 
     * @param title The title. Put null if not required.
     * @param a     The array to be formatted. May be null in which
     *              case no formatting happens.
     */
    public void
    appendOnePerLine(String title,
                     char[]  a)
    {
        if (a != null)
        {
            appendTitle(title);
            incrementLevel();
            for (int i = 0; i < a.length; i++)
            {
                appendLine("" + a[i]);
            }
            decrementLevel();
        }
    }

    /**
     * Formats an array of bytes into its own indented block.
     * 
     * @param title The title. Put null if not required.
     * @param a     The array to be formatted. May be null in which
     *              case no formatting happens.
     */
    public void
    appendOnePerLine(String title,
                     byte[]  a)
    {
        if (a != null)
        {
            appendTitle(title);
            incrementLevel();
            for (int i = 0; i < a.length; i++)
            {
                appendLine("" + a[i]);
            }
            decrementLevel();
        }
    }

    /**
     * Formats an array of shorts into its own indented block.
     * 
     * @param title The title. Put null if not required.
     * @param a     The array to be formatted. May be null in which
     *              case no formatting happens.
     */
    public void
    appendOnePerLine(String title,
                     short[]  a)
    {
        if (a != null)
        {
            appendTitle(title);
            incrementLevel();
            for (int i = 0; i < a.length; i++)
            {
                appendLine("" + a[i]);
            }
            decrementLevel();
        }
    }

    /**
     * Formats an array of longs into its own indented block.
     * 
     * @param title The title. Put null if not required.
     * @param a     The array to be formatted. May be null in which
     *              case no formatting happens.
     */
    public void
    appendOnePerLine(String title,
                     long[]  a)
    {
        if (a != null)
        {
            appendTitle(title);
            incrementLevel();
            for (int i = 0; i < a.length; i++)
            {
                appendLine("" + a[i]);
            }
            decrementLevel();
        }
    }

    /**
     * Formats an array of floats into its own indented block.
     * 
     * @param title The title. Put null if not required.
     * @param a     The array to be formatted. May be null in which
     *              case no formatting happens.
     */
    public void
    appendOnePerLine(String title,
                     float[]  a)
    {
        if (a != null)
        {
            appendTitle(title);
            incrementLevel();
            for (int i = 0; i < a.length; i++)
            {
                appendLine("" + a[i]);
            }
            decrementLevel();
        }
    }

    /**
     * Formats an array of doubles into its own indented block.
     * 
     * @param title The title. Put null if not required.
     * @param a     The array to be formatted. May be null in which
     *              case no formatting happens.
     */
    public void
    appendOnePerLine(String title,
                     double[]  a)
    {
        if (a != null)
        {
            appendTitle(title);
            incrementLevel();
            for (int i = 0; i < a.length; i++)
            {
                appendLine("" + a[i]);
            }
            decrementLevel();
        }
    }

    /**
     * Formats an array of booleanss into its own indented block.
     * 
     * @param title The title. Put null if not required.
     * @param a     The array to be formatted. May be null in which
     *              case no formatting happens.
     */
    public void
    appendOnePerLine(String title,
                     boolean[]  a)
    {
        if (a != null)
        {
            appendTitle(title);
            incrementLevel();
            for (int i = 0; i < a.length; i++)
            {
                appendLine("" + a[i]);
            }
            decrementLevel();
        }
    }
	
	/**
	 * Puts the title, properly indented.
	 * 
	 * @param title  The title. Maybe null in which case no formatting occurs.
	 */
	public void
	appendTitle(String title)
	{
		if (title != null)
		{
			appendLine(title);
		}
	}
	
	/**
	 * Appends one line of text, properly indented.
	 */
	public void
	appendLine(Object line)
	{
		myBuf.append(myLinePrefix).append(line).append('\n');
	}
	
	/**
	 * Appends one field with name and value.
	 */
	public void
	appendField(String name,
	            String value)
	{
		if (value != null)
		{
			myBuf.append(myLinePrefix)
			     .append(name).append(EQUALS).append(value).append('\n');
		}
	}
	
	/**
	 * Appends one field with name and value. The string for value is
	 * obtained from the value's toString method which is assumed to
	 * return a string without line terminators.
	 */
	public void
	appendField(String name,
	            Object value)
	{
		if (value != null)
		{
			myBuf.append(myLinePrefix)
			     .append(name).append(EQUALS).append(value).append('\n');
		}
	}
	
	/**
	 * Appends one field with name and value.
	 */
	public void
	appendField(String name,
	            long   value)
	{
		myBuf.append(myLinePrefix)
		     .append(name).append(EQUALS).append(value).append('\n');
	}
    
    /**
     * Appends one field with name and value.
     */
    public void
    appendField(String name,
                int    value)
    {
        myBuf.append(myLinePrefix)
             .append(name).append(EQUALS).append(value).append('\n');
    }
	
	/**
	 * Appends one field with name and value.
	 */
	public void
	appendField(String  name,
	            boolean value)
	{
		myBuf.append(myLinePrefix)
		     .append(name).append(EQUALS).append(value).append('\n');
	}

	/**
	 * Appends one field with name and value.
	 */
	public void
	appendLine(String line)
	{
		myBuf.append(myLinePrefix).append(line).append('\n');
	}

	/**
	 * Appends one field with name and value.
	 */
	public String
	toString()
	{
		return myBuf.toString();
	}
    
    /**
     * Formats a formattable objects
     * @param title  The title to pass to the object when it formats itself.
     * @param object The object to format
     */
    public void
    format(String      title,
           Formattable object)
    {
        if (object != null)
        {
            object.format(this, title);
        }
    }
    
    /**
     * Formats an array of formattable objects
     * @param title   The title of the array.
     * @param objects The array to format.
     */
    public void
    format(String        title,
           Formattable[] objects)
    {
        if (objects != null)
        {
            appendTitle(title);
            incrementLevel();
            for (int i = 0; i < objects.length; i++)
            {
                if (objects[i] != null)
                {
                    objects[i].format(this, null);
                }
                else
                {
                    appendLine("null");
                }
            }
            decrementLevel();
        }
    }
    
    /**
     * Convenience function for formatting objects to strings
     * without dealing with an ObjectFormatter object.
     * @param title  Optional title
     * @param object Object to be formatted
     * @return Formatter object.
     */
    public static String
    toString(String      title,
             Formattable object)
    {
        ObjectFormatter formatter = new ObjectFormatter();
        formatter.format(title, object);
        return formatter.toString();
    }
    
    /**
     * A demo of this class
     */
    public static void
    main(String[] args)
    {
        ObjectFormatter formatter = new ObjectFormatter();
        formatter.appendTitle(null);
        formatter.appendTitle("A demo of ObjectFormatter");
        formatter.incrementLevel();
        formatter.appendField("name", "DummyObject");
        formatter.appendField("nullObject", (Object)null);
        formatter.appendField("nullString", (String)null);
        formatter.appendField("age", 3);
        formatter.appendField("ageObj", new Integer(3));
        formatter.appendField("cellQty", 1002003004005L);
        formatter.appendField("isLocked", true);
        formatter.decrementLevel();
        String output = formatter.toString();
        System.out.println("-------------------------------------");
        System.out.print(output);
        System.out.println("-------------------------------------");
        String expectedOutput =
            "A demo of ObjectFormatter\n" +
            "{\n" +
            "  name = DummyObject\n" +
            "  age = 3\n" +
            "  ageObj = 3\n" +
            "  cellQty = 1002003004005\n" +
            "  isLocked = true\n" +
            "}\n";
        if (!output.equals(expectedOutput))
        {
            System.out.println("-------------- Expected -------------");
            System.out.print(expectedOutput);
            System.out.println("-------------------------------------");
            throw new RuntimeException("Output differs from expectation");
        }
    }
}
