package nokia.rtorkel.robi.db_jdbc;

public abstract class DbContext implements DbContextInterface
{
    private final String m_dbLabel;
    
    public
    DbContext(String contextName)
    {
        m_dbLabel = contextName;
        outputMessage("constructed " + getClass().getName() + " with " + m_dbLabel);
    }
    
    @Override
    public String
    dbLabel()
    {
        return m_dbLabel;
    }

    @Override
    public void
    finishInitialisation(String message)
    {
        outputMessage(m_dbLabel + ", initialisation complete: " + message);
    }

    @Override
    public void
    commenceQuery(String query)
    {
        outputMessage(m_dbLabel + ", doing query:" + LINE_END + query);
    }

    @Override
    public void
    finishQuery()
    {
        outputMessage(m_dbLabel + ", finished query");
    }

    @Override
    public void
    enterFunction(String function)
    {
        outputMessage(m_dbLabel + ", starting " + function + " for " + m_dbLabel);
    }

    @Override
    public void
    showResult(String result)
    {
        outputMessage(m_dbLabel + ", result:" + LINE_END + result);
    }

    @Override
    public void
    setParam(String paramMessage)
    {
        outputMessage(m_dbLabel + ",   statement param: " + paramMessage);
    }

    @Override
    public void commenceUpdate(String update)
    {
        outputMessage(m_dbLabel + ", doing update:" + LINE_END + update);
    }

    @Override
    public void finishUpdate(int rowCount)
    {
        outputMessage(m_dbLabel + ", finished update, rowCount = " + rowCount);
    }

    @Override
    public void commenceCommit()
    {
        outputMessage(m_dbLabel + ", commencing commit");
    }

    @Override
    public void finishCommit()
    {
        outputMessage(m_dbLabel + ", finished commit");
    }

    @Override
    public void commenceRollback()
    {
        outputMessage(m_dbLabel + ", commencing rollback");
    }

    @Override
    public void finishRollback()
    {
        outputMessage(m_dbLabel + ", finished rollback");
    }
    
    /**
     * Outputs a message by whatever the output mechanism
     * @param message The last line should not be line-terminated (but it's not too serious
     * if it is).
     */
    protected abstract void
    outputMessage(String message);
}
