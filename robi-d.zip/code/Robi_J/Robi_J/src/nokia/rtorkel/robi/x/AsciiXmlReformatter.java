package nokia.rtorkel.robi.x;

import java.io.File;

import rasmus_torkel.set.chars.DefinedCharSets;
import rasmus_torkel.xml_basic.read.TagNode;
import rasmus_torkel.xml_basic.read.XmlReadOptions;
import rasmus_torkel.xml_basic.read.impl.XmlReader;
import rasmus_torkel.xml_basic.tool.XmlReformatter;
import rasmus_torkel.xml_basic.write.XmlSink;

public class AsciiXmlReformatter
{
    public static final XmlReadOptions READ_OPTIONS =
            XmlReadOptions.DEFAULT.diffCharSet(DefinedCharSets.BITS_7_NON_NULL);
    
    public static void
    main(String[] args)
    {
        if (args.length == 1)
        {
            String inFileName = args[0];
            File inFile = new File(inFileName);
            String outXml = reformat(inFile);
            System.out.print(outXml);
        }
        else if (args.length == 2)
        {
            String inFileName = args[0];
            String outFileName = args[1];
            File inFile = new File(inFileName);
            File outFile = new File(outFileName);
            reformat(inFile, outFile);
        }
        else
        {
            System.out.println("Need one or two arguments, inputFileName and optional outputFileName");
        }
    }
    
    public static String
    reformat(File inFile)
    {
        TagNode node = XmlReader.xmlFileToRoot(inFile, READ_OPTIONS);
        XmlSink xmlSink = new XmlSink();
        XmlReformatter.reformat(node, xmlSink);
        return xmlSink.toString();
    }
    
    public static void
    reformat(File                       inFile,
             File                       outFile)
    {
        TagNode node = XmlReader.xmlFileToRoot(inFile, READ_OPTIONS);
        XmlSink xmlSink = new XmlSink(outFile);
        XmlReformatter.reformat(node, xmlSink);
    }
}
