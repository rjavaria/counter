package nokia.rtorkel.robi.eric_iptnms;

public class EliminatedEntity
{
    //private static final Logger _logger = LogManager.getLogger(EliminatedEntity.class);
    
    public final String                 _id;
    public final String                 _category;
    public final String                 _reason;
    public final EliminatedEntity _previous;
    
    public
    EliminatedEntity(String id,
                     String category,
                     String reason)
    {
        _id = id;
        _category = category;
        _reason = reason;
        _previous = null;
    }
    
    public
    EliminatedEntity(String           id,
                     String           category,
                     EliminatedEntity previous)
    {
        _id = id;
        _category = category;
        _reason = null;
        _previous = previous;
    }
}
