package nokia.rtorkel.robi.db_jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;

public class LinkCapacity2 implements ObjectFormatter.Formattable
{
    public final long m_linkId;
    public final long m_capacityId;
    
    private final DbHandle m_db;
    
    private Link2     m_link;
    private Capacity2 m_capacity;
    
    /**
     * 
     * @param linkId
     * @param capacityId
     * @param link       may be null if not handy
     * @param capacity       may be null if not handy
     * @param db
     */
    public
    LinkCapacity2(long      linkId,
                  long      capacityId,
                  Link2     link,
                  Capacity2 capacity,
                  DbHandle  db)
    {
        m_linkId = linkId;
        m_capacityId = capacityId;
        m_link = link;
        m_capacity = capacity;
        m_db = db;
    }

    public Link2
    link() throws SQLException, DbException
    {
        if (m_link == null)
        {
            m_link = m_db.linkById(m_linkId);
        }
        return m_link;
    }

    public Capacity2
    capacity() throws SQLException, DbException
    {
        if (m_capacity == null)
        {
            m_capacity = m_db.capacityById(m_capacityId);
        }
        return m_capacity;
    }
    
    public static final class LinkCapacityTable extends EntityTable
    {
        public final EntityColumn m_linkIdColumn;
        public final EntityColumn m_capacityIdColumn;

        public
        LinkCapacityTable()
        {
            super("link_capacities");
            m_linkIdColumn = new EntityColumn(m_tableName, "link_id");
            m_capacityIdColumn = new EntityColumn(m_tableName, "capacity_id");
        }
        
        public String
        makeSimpleSelectClause()
        {
           return  "select " + m_capacityIdColumn.m_tabColPhrase +
                   ", " + m_linkIdColumn.m_tabColPhrase +
                   LINE_END;
        }
    }
    
    public static final LinkCapacityTable ENTITY_TABLE = new LinkCapacityTable();
    
    public static LinkCapacity2
    fromResultSet(DbHandleImpl db,
                  ResultSet    rs,
                  Link2        link,
                  Capacity2    capacity) throws SQLException, DbException
    {
        long linkId = rs.getLong(1);
        long capacityId = rs.getLong(2);
        return new LinkCapacity2(linkId, capacityId, link, capacity, db);
    }
    
    @Override
    public String
    toString()
    {
        return "linkCapacity|" + m_linkId + "|" + m_capacityId;
    }

    @Override
    public void
    format(ObjectFormatter formatter,
           String          title)
    {
        formatter.appendTitle(title);
        formatter.incrementLevel();
        formatter.appendField("linkId", m_linkId);
        formatter.appendField("capacityId", m_capacityId);
        formatter.decrementLevel();
    }
    
    public void
    formatWithEntities(ObjectFormatter formatter,
                       String          title)
    {
        formatter.appendTitle(title);
        formatter.incrementLevel();
        formatter.appendField("linkId", m_linkId);
        formatter.appendField("capacityId", m_capacityId);
        try
        {
            formatter.format("link", link());
        }
        catch (Exception e)
        {
            formatter.appendField("linkRetrievalException", e.toString());
        }
        try
        {
            formatter.format("capacity", capacity());
        }
        catch (Exception e)
        {
            formatter.appendField("capacityRetrievalException", e.toString());
        }
        formatter.decrementLevel();
    }
    
    public String
    formatWithEntities(String title)
    {
        ObjectFormatter formatter = new ObjectFormatter();
        formatWithEntities(formatter, title);
        return formatter.toString();
    }
}
