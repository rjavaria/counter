package nokia.rtorkel.robi.eric_iptnms;

import java.io.File;

public class InputFileDirectory
{
    File   _inputFileDir;
    File[] _inputFiles;
    
    public
    InputFileDirectory(File inputFileDir)
    {
        _inputFiles = inputFileDir.listFiles();
    }
    
    public File
    getInputFile(String entityPrefix)
    {
        String prefix = entityPrefix + "_";
        for (File inputFile : _inputFiles)
        {
            String name = inputFile.getName();
            if (name.startsWith(prefix) && name.endsWith(".xml"))
            {
                return inputFile;
            }
        }
        throw new RuntimeException("Could not find file for " + entityPrefix + " in " + _inputFileDir);
    }
}
