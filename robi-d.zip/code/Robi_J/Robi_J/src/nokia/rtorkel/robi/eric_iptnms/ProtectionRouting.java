package nokia.rtorkel.robi.eric_iptnms;

import rasmus_torkel.text.write.IndentingLineSink;
import rasmus_torkel.xml_basic.read.TagNode;

public class ProtectionRouting extends Routing
{
    private final Route _workerRoute;
    private final Route _protectionRoute;

    public ProtectionRouting(TagNode                node,
                             EricssonIptnmsEntities entities) throws EntityNotCreatedException
    {
        super(node, entities);
        _workerRoute = route(node, "ProtectionRouting.theWorkerRoute", entities);
        _protectionRoute = route(node, "ProtectionRouting.theProtectionRoute", entities);
        node.verifyNoMoreChildren();
        entities.putRouting(this);
        _supportedPath.putRouting(this);
    }
    
    @Override
    public AccessPoint
    firstAccessPoint()
    {
        AccessPoint wrAp = _workerRoute.firstAccessPoint();
        AccessPoint prAp = _protectionRoute.firstAccessPoint();
        if (wrAp == prAp)
        {
            return wrAp;
        }
        else
        {
            throw new RuntimeException("Different first access point for the routes in protection routing " + _id);
        }
    }
    
    @Override
    public AccessPoint
    lastAccessPoint()
    {
        AccessPoint wrAp = _workerRoute.lastAccessPoint();
        AccessPoint prAp = _protectionRoute.lastAccessPoint();
        if (wrAp == prAp)
        {
            return wrAp;
        }
        else
        {
            throw new RuntimeException("Different last access point for the routes in protection routing " + _id);
        }
    }
    
    public void
    toIndentingLineSink(IndentingLineSink sink)
    {
        sink.writeLine("Protection Routing");
        sink.incrementLevel();
        _workerRoute.toIndentingLineSink(sink, "Worker Route");
        _protectionRoute.toIndentingLineSink(sink, "Protection Route");
        sink.decrementLevel();
    }
    
    @Override
    public boolean
    findDepth()
    {
        if (   !_workerRoute.findDepth()
            || !_protectionRoute.findDepth())
        {
            return false;
        }
        int workerDepth = _workerRoute.depth();
        int protectionDepth = _protectionRoute.depth();
        if (workerDepth > protectionDepth)
        {
            _depth = workerDepth;
        }
        else
        {
            _depth = protectionDepth; 
        }
        return true;
    }
}
