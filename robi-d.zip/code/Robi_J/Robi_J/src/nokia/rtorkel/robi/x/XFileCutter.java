package nokia.rtorkel.robi.x;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;

import rasmus_torkel.text.read.PerlStyleInput;

public class XFileCutter
{
    public static void
    main(String[] args)
    {
        File inFile = new File("C:\\workspaces\\ws20160317\\Robi_J\\debug\\log_013.out");
        File outFile = new File("C:\\workspaces\\ws20160317\\Robi_J\\debug\\log_013_x.out");
        PerlStyleInput input = new PerlStyleInput(inFile);
        PrintStream writer;
        try
        {
            writer = new PrintStream(outFile);
        }
        catch (IOException e)
        {
            e.printStackTrace();
            return;
        }
        while (   input.read()
               && !input._.startsWith("2016-04-26 10:13:15,411"))
        {
            writer.println(input._);
        }
        input.close();
        writer.close();
    }
}
