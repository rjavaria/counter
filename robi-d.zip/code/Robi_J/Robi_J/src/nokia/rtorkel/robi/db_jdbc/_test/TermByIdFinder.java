package nokia.rtorkel.robi.db_jdbc._test;

import nokia.rtorkel.robi.db_jdbc.DbHandle;
import nokia.rtorkel.robi.db_jdbc.DbHandleImpl;
import nokia.rtorkel.robi.db_jdbc.Link2;
import nokia.rtorkel.robi.db_jdbc.ObjectFormatter;
import nokia.rtorkel.robi.db_jdbc.Path2;
import nokia.rtorkel.robi.db_jdbc.Termination2;

public class TermByIdFinder extends DbUnitTest
{
    public static void
    main(String[] args)
    {
        try
        {
            DbHandleImpl db = makeDbHandle(args, "termId");
            testRead(db, args[3]);
        }
        catch (Exception e)
        {
            e.printStackTrace(System.out);
        }
    }
    
    public static void
    testRead(DbHandle db,
             String   idS) throws Exception
    {
        long id = Long.parseLong(idS);
        Termination2 term = db.terminationById(id);
        String termDump = ObjectFormatter.toString("termination", term);
        System.out.println(termDump);
        Path2[] paths = term.paths();
        String pathDump = null;
        if (paths.length != 0)
        {
            pathDump = ObjectFormatter.toString("First path", paths[0]);
        }
        Link2[] aFacingLinks = term.aFacingLinks();
        String aFacingLinkDump = null;
        if (aFacingLinks.length != 0)
        {
            aFacingLinkDump = ObjectFormatter.toString("First A facing link", aFacingLinks[0]);
        }
        Link2[] zFacingLinks = term.zFacingLinks();
        String zFacingLinkDump = null;
        if (zFacingLinks.length != 0)
        {
            zFacingLinkDump = ObjectFormatter.toString("First Z facing link", zFacingLinks[0]);
        }
        System.out.println(termDump);
        if (pathDump != null)
        {
            System.out.println(pathDump);
        }
        else
        {
            System.out.println("No path");
            System.out.println();
        }
        if (aFacingLinkDump != null)
        {
            System.out.println(aFacingLinkDump);
        }
        else
        {
            System.out.println("No A facing link");
            System.out.println();
        }
        if (zFacingLinkDump != null)
        {
            System.out.println(zFacingLinkDump);
        }
        else
        {
            System.out.println("No Z facing link");
            System.out.println();
        }
    }
}
