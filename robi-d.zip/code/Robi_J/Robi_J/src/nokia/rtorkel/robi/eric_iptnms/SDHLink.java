package nokia.rtorkel.robi.eric_iptnms;

import rasmus_torkel.xml_basic.read.TagNode;

public class SDHLink extends PhLink
{
    public final String     _level;
    public final int        _rsLinkId;
    
    public
    SDHLink(TagNode                node,
            EricssonIptnmsEntities entities) throws EntityNotCreatedException
    {
        super(node.nextChildE("PhLink"), entities);
        _level = EricssonXmlUtil.nextEnumFieldE(node, "SDHLink.level", "DTSTMLevel");
        _rsLinkId = EricssonXmlUtil.nextIntFieldE(node, "SDHLink.rSLinkId");
        node.verifyNoMoreChildren();
    }
}
