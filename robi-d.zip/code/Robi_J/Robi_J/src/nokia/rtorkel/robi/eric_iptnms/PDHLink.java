package nokia.rtorkel.robi.eric_iptnms;

import rasmus_torkel.xml_basic.read.TagNode;

public class PDHLink extends PhLink
{
    public
    PDHLink(TagNode                node,
            EricssonIptnmsEntities entities) throws EntityNotCreatedException
    {
        super(node.nextChildE("PhLink"), entities);
        node.verifyNoMoreChildren();
    }
}
