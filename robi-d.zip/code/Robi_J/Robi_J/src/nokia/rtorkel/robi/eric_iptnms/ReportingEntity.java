package nokia.rtorkel.robi.eric_iptnms;

import rasmus_torkel.text.write.IndentingLineSink;

public interface ReportingEntity
{
    public void
    makeReport(IndentingLineSink sink);
}
