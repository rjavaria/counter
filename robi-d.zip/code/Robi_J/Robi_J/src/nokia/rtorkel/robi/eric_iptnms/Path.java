package nokia.rtorkel.robi.eric_iptnms;

import java.io.File;
import java.util.ArrayList;

import rasmus_torkel.text.write.IndentingLineSink;
import rasmus_torkel.xml_basic.read.TagNode;
import rasmus_torkel.xml_basic.read.XmlReadOptions;
import rasmus_torkel.xml_basic.read.impl.XmlReader;

public class Path implements RouteComponent, ReportingEntity
{
    public final String _id;
    public final String _name;
    public final String _type;
    public final String _connectionType;
    public final String _signalType;
    public final String _protectionFlag;
    public final String _protectionState;
    
    private final AccessPoint[] _from;
    private final AccessPoint[] _to;
    
    private Routing _routing;
    private int     _depth = -1;
    
    @Override
    public String
    toString()
    {
        return _id + " " + _name + " " + _type + " " + _connectionType +
               " D" + _depth +
               " " + (_signalType != null ? _signalType : "-") +
               " " + (_protectionFlag != null ? _protectionFlag : "-") +
               " " + (_protectionState != null ? _protectionState : "-") +
               " " + _from[0].name() + " " + _to[0].name() +
               " " + (_routing != null ? _routing : "-");
    }

    public String
    toSlightlyShorterString()
    {
        return _id + " " + _name + " " + _type + " " + _connectionType +
               " " + (_signalType != null ? _signalType : "-") +
               " " + (_protectionFlag != null ? _protectionFlag : "-") +
               " " + (_protectionState != null ? _protectionState : "-");
    }
    
    public
    Path(TagNode                node,
         EricssonIptnmsEntities entities) throws EntityNotCreatedException
    {
        TagNode pathNode = node.nextChildE("Path");
        _type = node._id._relativeName;
        _id = pathNode.attributeValueE("Id");
        pathNode.nextChildN("Path.trace");
        TagNode protectionNode = pathNode.nextChildN("Path.protection");
        if (protectionNode != null)
        {
            TagNode protectionStatusNode = protectionNode.nextChildE("ProtectionStatus");
            _protectionFlag = 
                    EricssonXmlUtil.nextEnumFieldE(
                            protectionStatusNode, "ProtectionStatus.protectionFlag", "DTProtectionFlag");
            _protectionState = 
                    EricssonXmlUtil.nextEnumFieldE(
                            protectionStatusNode, "ProtectionStatus.protectingState", "DTProtectingState");
        }
        else
        {
            _protectionFlag = null;
            _protectionState = null;
        }
        pathNode.nextChildE("Path.pathId");
        _name = EricssonXmlUtil.nextTextFieldE(pathNode, "Path.pathname");
        pathNode.nextChildE("Path.username");
        pathNode.nextChildE("Path.workerState");
        pathNode.nextChildE("Path.payload");
        pathNode.nextChildE("Path.creationDate");
        pathNode.nextChildE("Path.customerData");
        _connectionType =
                EricssonXmlUtil.nextEnumFieldE(
                        pathNode, "Path.connectionType", "DTConnectionType");
        pathNode.verifyNoMoreChildren();
        if (   _type.equals("PathODU")
            || _type.equals("PathGDC"))
        {
            _from = getAccessPoints(node, _type + ".fromTP", entities);
            _to = getAccessPoints(node, _type + ".toTP", entities);
        }
        else
        {
            _to = getAccessPoints(node, _type + ".toTP", entities);
            _from = getAccessPoints(node, _type + ".fromTP", entities);
        }
        node.nextChildN(_type + ".structure");
        String signalTypeTypeName = "DTHOSignalType";
        if (_type.equals("CircuitLO"))
        {
            signalTypeTypeName = "DTLOSignalType";
        }
        else if (_type.equals("PathODU"))
        {
            signalTypeTypeName = "DTODUSignalType";
        }
        _signalType =
                EricssonXmlUtil.nextEnumFieldN(
                        node, _type + ".signalType", signalTypeTypeName);
        node.nextChildN(_type + ".isStructured");
        node.nextChildN(_type + ".isVC4Path");
        node.verifyNoMoreChildren();
        entities.putPath(this);
    }
    
    private AccessPoint[]
    getAccessPoints(TagNode                parentNode,
                   String                 fieldName,
                   EricssonIptnmsEntities entities) throws EntityNotCreatedException
    {
        TagNode fieldNode = parentNode.nextChildE(fieldName);
        TagNode middleNode = fieldNode.nextChildE();
        ArrayList<AccessPoint> apAl = new ArrayList<AccessPoint>();
        boolean finished = false;
        while (!finished)
        {
            AccessPoint ap = getAccessPointFromDeeperInside(fieldNode, middleNode, fieldName, entities);
            if (ap == null)
            {
                finished = true;
            }
            else
            {
                apAl.add(ap);
            }
        }
        if (apAl.size() == 0)
        {
            entities.putEliminatedEntity("_id", "Path", "Missing " + fieldName + " AccessPoint");
        }
        fieldNode.verifyNoMoreChildren();
        AccessPoint[] aps = new AccessPoint[apAl.size()];
        apAl.toArray(aps);
        return aps;
    }
    
    private AccessPoint
    getAccessPointFromDeeperInside(TagNode                fieldNode,
                                   TagNode                middleNode,
                                   String                 fieldName,
                                   EricssonIptnmsEntities entities) throws EntityNotCreatedException
    {
        TagNode apRefNode = middleNode.nextChildN();
        if (apRefNode == null)
        {
            return null;
        }
        int attributeQty = apRefNode.attributeQty();
        if (attributeQty != 1)
        {
            throw new RuntimeException(
                    "Expected 1 attribute for " +
                    apRefNode + " under " + middleNode + " under " + fieldNode + " for path " + _id +
                    " but we have " + attributeQty);
        }
        String apId = apRefNode.attribute(0)._value;
        AccessPoint ap = entities.lookUpAp(apId);
        if (ap == null)
        {
            entities.putEliminatedDependentEntity(_id, "Path", apId, "AccessPoint");
            throw new EntityNotCreatedException();
        }
        return ap;
    }
    
    public void
    putRouting(Routing routing)
    {
        if (_routing != null)
        {
            throw new RuntimeException(
                    "Path " + _id + " has multiple routings, " + _routing._id + " and " + routing._id);
        }
        _routing = routing;
        AccessPoint firstAccessPoint = _routing.firstAccessPoint();
        if (!isIn(firstAccessPoint, _from))
        {
            throw new RuntimeException(
                    "Path " + _id +
                    " has no \"from\" access point which is the same as first access point of routing " +
                    _routing._id + " which is " + firstAccessPoint._id);
        }
        AccessPoint lastAccessPoint = _routing.lastAccessPoint();
        if (!isIn(lastAccessPoint, _from))
        {
            throw new RuntimeException(
                    "Path " + _id +
                    " has no \"to\" access point which is the same as last access point of routing " +
                    _routing._id + " which is " + lastAccessPoint._id);
        }
    }
    
    private boolean
    isIn(AccessPoint   ap,
         AccessPoint[] aps)
    {
        for (AccessPoint apFromArray : aps)
        {
            if (ap == apFromArray)
            {
                return true;
            }
        }
        return false;
    }
    
    @Override
    public AccessPoint
    firstAccessPoint()
    {
        if (_routing == null)
        {
            return null;
        }
        return _routing.firstAccessPoint();
    }
    
    @Override
    public AccessPoint
    lastAccessPoint()
    {
        if (_routing == null)
        {
            return null;
        }
        return _routing.lastAccessPoint();
    }
    
    @Override
    public void
    makeReport(IndentingLineSink sink)
    {
        toIndentingLineSink(sink);
    }
    
    public void
    toIndentingLineSink(IndentingLineSink sink)
    {
        sink.writeLine(toSlightlyShorterString());
        sink.incrementLevel();
        AccessPoint.accessPointsToIndentingLineSink(sink, "from", _from);
        if (_routing != null)
        {
            _routing.toIndentingLineSink(sink);
        }
        AccessPoint.accessPointsToIndentingLineSink(sink, "to", _to);
        sink.decrementLevel();
    }
    
    public int
    depth()
    {
        return _depth;
    }
    
    public boolean
    findDepth()
    {
        if (_depth != -1)
        {
            return true;
        }
        if (_routing == null)
        {
            _depth = 0;
            return true;
        }
        if (!_routing.findDepth())
        {
            return false;
        }
        _depth = _routing.depth();
        return true;
    }
    
    public static void
    load(InputFileDirectory     dir,
         EricssonIptnmsEntities entities)
    {
        File neFile = dir.getInputFile("Path");
        TagNode rootNode = XmlReader.xmlFileToRoot(neFile, XmlReadOptions.DEFAULT, "NetworkManager");
        rootNode.nextChildE("Version");
        boolean haveSummary = false;
        do
        {
            TagNode level1Node = rootNode.nextChildE();
            if (   level1Node._id._relativeName.equals("CircuitHO")
                || level1Node._id._relativeName.equals("CircuitLO")
                || level1Node._id._relativeName.equals("PathGDC")
                || level1Node._id._relativeName.equals("PathOCH")
                || level1Node._id._relativeName.equals("PathODU"))
            {
                try
                {
                    new Path(level1Node, entities);
                }
                catch (EntityNotCreatedException e)
                {
                }
            }
            else if (level1Node._id._relativeName.equals("Summary"))
            {
                rootNode.verifyNoMoreChildren();
                haveSummary = true;
            }
            else
            {
                throw new RuntimeException("Node with unexpected name: " + level1Node);
            }
        } while (!haveSummary);
    }
}
