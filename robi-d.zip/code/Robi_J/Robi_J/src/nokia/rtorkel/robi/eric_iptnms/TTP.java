package nokia.rtorkel.robi.eric_iptnms;

import rasmus_torkel.xml_basic.read.TagNode;

public class TTP extends AccessPoint
{
    public
    TTP(TagNode                node,
        EricssonIptnmsEntities entities,
        String                 type)
    {
        super(node.nextChildE("AccessPoint"), entities, type);
    }
}
