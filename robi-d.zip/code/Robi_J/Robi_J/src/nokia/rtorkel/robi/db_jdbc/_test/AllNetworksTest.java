package nokia.rtorkel.robi.db_jdbc._test;

import nokia.rtorkel.robi.db_jdbc.DbHandle;
import nokia.rtorkel.robi.db_jdbc.DbHandleImpl;
import nokia.rtorkel.robi.db_jdbc.ObjectFormatter;
import nokia.rtorkel.robi.db_jdbc.Network2;

public class AllNetworksTest extends DbUnitTest
{
    public static void
    main(String[] args)
    {
        try
        {
            DbHandleImpl db = makeDbHandle(args);
            testRead(db);
        }
        catch (Exception e)
        {
            e.printStackTrace(System.out);
        }
    }
    
    public static void
    testRead(DbHandle db) throws Exception
    {
        Network2[] networks = db.networksAll();
        for (Network2 network : networks)
        {
            if (network.featureQty() > 0)
            {
                System.out.println(ObjectFormatter.toString("first network with features", network));
                return;
            }
        }
        if (networks.length > 0)
        {
            System.out.println("There is not network with features, here is the first one without features");
            System.out.println(ObjectFormatter.toString(null, networks[0]));
        }
    }
}
