package nokia.rtorkel.robi.db_jdbc.query;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import nokia.rtorkel.robi.db_jdbc.DbContextInterface;
import nokia.rtorkel.robi.db_jdbc.EntityColumn;
import nokia.rtorkel.robi.db_jdbc.EntityTable;
import nokia.rtorkel.robi.db_jdbc.LazyPreparedStatement;

public class EntityBy2LongColumns extends LazyPreparedStatement
{
    public
    EntityBy2LongColumns(Connection          connection,
                         EntityTable         table,
                         EntityColumn        column1,
                         EntityColumn        column2,
                         DbContextInterface  context)
    {
        super(connection, table.make2ColumnsQuery(column1, column2), context);
    }
    
    public ResultSet
    run(long value1,
        long value2) throws SQLException
    {
        ensureReady();
        setLong(1, value1);
        setLong(2, value2);
        return executeQuery();
    }
}
