/*---------------------------------------------------------------------
 * (C) COPYRIGHT 2014 ALCATEL AUSTRALIA LIMITED
 * 
 * This program contains proprietary information which is a trade secret
 * of ALCATEL AUSTRALIA LIMITED and also is protected under the applicable
 * copyright law. Recipient is to retain this program in confidence and is
 * not permitted to use or make any copy thereof other than as permitted
 * under a written agreement with ALCATEL AUSTRALIA LIMITED.
 *-------------------------------------------------------------------*/
package nokia.rtorkel.robi.db_jdbc;

import java.sql.SQLException;
import java.util.Arrays;

/**
 * Represents any of those basic entities that have identifier, name and type (which is a foreign key into
 * a type table for that entity type) and typically also features.
 * <p>
 * The instances are immutable in terms of their external state.
 * However, as this class utilises lazy evaluation, the internal state of instances can change.
 * <p>
 * For the time being, this class is for rows retrieved from the database. However, it is entirely possible
 * that it will be extended for rows to be inserted.
 * 
 * @author rtorkel
 *
 */
public abstract class PrimaryEntity implements DbConstants, ObjectFormatter.Formattable, Comparable<PrimaryEntity>
{
    public    final EntityType m_entityType;
    
    /**
     * The numerical primary key which is part of each table containing primary entities.
     */
    public    final long       m_id;
    
    /**
     * Tables for primary entity have a column containing the name of the primary entity.
     */
    public    final String     m_name;
    
    /**
     * Most but not all primary entities tables have a foreign numerical key into a separate
     * corresponding type table containing the string representation for the type. 
     */
    public    final String     m_type;
    
    public    final String     m_discoveredName;
    
    /**
     * For lazy evaluation.
     */
    protected final DbHandle m_db;
    
    private Feature2[] m_features;
    
    protected
    PrimaryEntity(EntityType entityType,
                  long       id,
                  String     name,
                  String     type,
                  String     discoveredName,
                  DbHandle   db)
    {
        m_entityType = entityType;
        m_id = id;
        m_name = name;
        m_type = type;
        m_discoveredName = discoveredName;
        m_db = db;
    }
    
    public static class PrimaryEntityTable extends EntityTable
    {
        public final EntityColumn m_idColumn;
        public final EntityColumn m_nameColumn;
        public final EntityColumn m_typeColumn;
        public final EntityColumn m_discoveredNameColumn;
        
        public
        PrimaryEntityTable(String tableName,
                    String idColumnName,
                    String nameColumnName,
                    String typeColumnName,
                    String discoveredNameColumnName)
        {
            super(tableName);
            m_idColumn = new EntityColumn(tableName, idColumnName);
            m_nameColumn = new EntityColumn(tableName, nameColumnName);
            if (typeColumnName != null)
            {
                m_typeColumn = new EntityColumn(tableName, typeColumnName);
            }
            else
            {
                m_typeColumn = null;
            }
            if (discoveredNameColumnName != null)
            {
                m_discoveredNameColumn = new EntityColumn(tableName, discoveredNameColumnName);
            }
            else
            {
                m_discoveredNameColumn = null;
            }
        }
        
        public final String
        makeSimpleSelectClause()
        {
            return makeSimpleSelectClauseNoLineEnd() + LINE_END;
        }
        
        public final String
        makeSimpleSelectClauseNoLineEnd()
        {
            return makeSelectClauseNoLineEnd(null);
        }
        
        public String
        makeSelectClauseNoLineEnd(String tableLabel)
        {
            StringBuilder buf = new StringBuilder(120);
            buf.append("select ");
            columnToSelectClauseWithoutComma(buf, m_idColumn, tableLabel);
            columnToSelectClause(buf, m_nameColumn, tableLabel);
            columnToSelectClause(buf, m_typeColumn, tableLabel);
            columnToSelectClause(buf, m_discoveredNameColumn, tableLabel);
            doExtraColumns(buf, tableLabel);
            return buf.toString();
        }
        
        protected void
        columnToSelectClause(StringBuilder buf,
                             EntityColumn  column,
                             String        tableLabel)
        {
            if (column == null)
            {
                return;
            }
            buf.append(", ");
            columnToSelectClauseWithoutComma(buf, column, tableLabel);
        }
        
        private void
        columnToSelectClauseWithoutComma(StringBuilder buf,
                                         EntityColumn  column,
                                         String        tableLabel)
        {
            if (tableLabel == null)
            {
                buf.append(column.m_tabColPhrase);
            }
            else
            {
                buf.append(tableLabel);
                buf.append(".");
                buf.append(column.m_name);
            }
        }
        
        protected void
        doExtraColumns(StringBuilder buf,
                       String        tableLabel)
        {
        }
    }
    
    public static class FeatureTable
    {
        public final String             m_tableName;
        public final PrimaryEntityTable m_primaryEntityTable;
        public final String             m_entityColumnName;
        public final String             m_retrieveFeaturesSql;
        
        public
        FeatureTable(String             tableName,
                     PrimaryEntityTable primaryEntityTable)
        {
            m_tableName = tableName;
            m_primaryEntityTable = primaryEntityTable;
            m_entityColumnName = m_primaryEntityTable.m_idColumn.m_name;
            m_retrieveFeaturesSql =
                    Feature2.SIMPLE_SELECT_CLAUSE +
                    "    from " + m_tableName + LINE_END +
                    "    where " + m_entityColumnName + " = ?";
        }
    }
    
    public abstract PrimaryEntityTable
    entityTable();
    
    public abstract FeatureTable
    featureTable();
    
    @Override
    public String
    toString()
    {
        return m_entityType.m_lCase + "|" + m_id + "|" + m_name + "|" + m_type;
    }
    
    /**
     * Gives a key for hashing which is only meaningful for entities which were read from DB.
     * We want to hold open the option for later using this class
     * for entities to be created. Such entities would not have a meaningful m_id field
     * and would have to be hashed differently and would need a different key generation.
     * That's why a hashCode function may not be the right thing. Likewise for equality.
     * 
     * @return key for hashing
     */
    public String
    key()
    {
        return m_entityType.m_lCase + "_" + m_id;
    }
    
    @Override
    public int
    compareTo(PrimaryEntity otherPE)
    {
        int entityTypeCmp = m_entityType.compareTo(otherPE.m_entityType);
        if (entityTypeCmp != 0)
        {
            return entityTypeCmp;
        }
        int typeCmp = m_type.compareTo(otherPE.m_type);
        if (typeCmp != 0)
        {
            return typeCmp;
        }
        if (m_name != null && otherPE.m_name == null)
        {
            return -1;
        }
        if (otherPE.m_name != null && m_name == null)
        {
            return 1;
        }
        if (m_name != null && otherPE.m_name != null)
        {
            int nameCmp = m_name.compareTo(otherPE.m_name);
            if (nameCmp != 0)
            {
                return nameCmp;
            }
        }
        if (m_id < otherPE.m_id)
        {
            return -1;
        }
        else if (m_id > otherPE.m_id)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }

    @Override
    public void
    format(ObjectFormatter formatter,
           String          title)
    {
        formatter.appendTitle(title);
        formatter.incrementLevel();
        formatCore(formatter);
        formatter.decrementLevel();
    }
    
    public void
    formatCore(ObjectFormatter formatter)
    {
        formatter.appendField("id", m_id);
        formatter.appendField("name", m_name);
        formatter.appendField("type", m_type);
        formatter.appendField("discoveredName", m_discoveredName);
        formatExtraFields(formatter);
        try
        {
            ensureFeatures();
            formatter.appendTitle("Features");
            formatter.incrementLevel();
            for (Feature2 feature : m_features)
            {
                formatter.appendField(feature.m_name, feature.m_value);
            }
            formatter.decrementLevel();
        }
        catch (SQLException e)
        {
            formatter.appendField("featureException", e);
        }
    }
    
    protected void
    formatExtraFields(ObjectFormatter formatter)
    {
    }
    
    public void
    ensureFeatures() throws SQLException
    {
        if (m_features == null)
        {
            m_features = lookUpFeatures();
            Arrays.sort(m_features);
        }
    }
    
    public abstract Feature2[]
    lookUpFeatures() throws SQLException;
    
    public int
    featureQty() throws SQLException
    {
        ensureFeatures();
        return m_features.length;
    }
    
    public Feature2
    feature(int index) throws SQLException
    {
        ensureFeatures();
        return m_features[index];
    }
    
    /**
     * Return the value of a feature if the feature exists an null otherwise.
     * That's what the "N" in the method name represents, the "null otherwise".
     * @param name
     * @return feature value if feature exists, null otherwise.
     * @throws SQLException
     */
    public String
    featureValueN(String name) throws SQLException
    {
        ensureFeatures();
        for (Feature2 feature : m_features)
        {
            if (name.equals(feature.m_name))
            {
                return feature.m_value;
            }
        }
        return null;
    }
}
