/*---------------------------------------------------------------------
 * (C) COPYRIGHT 2014 ALCATEL AUSTRALIA LIMITED
 * 
 * This program contains proprietary information which is a trade secret
 * of ALCATEL AUSTRALIA LIMITED and also is protected under the applicable
 * copyright law. Recipient is to retain this program in confidence and is
 * not permitted to use or make any copy thereof other than as permitted
 * under a written agreement with ALCATEL AUSTRALIA LIMITED.
 *-------------------------------------------------------------------*/
package nokia.rtorkel.robi.db_jdbc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import nokia.rtorkel.robi.db_jdbc.query.AllOfEntityType;
import nokia.rtorkel.robi.db_jdbc.query.AncestryByLongColumn;
import nokia.rtorkel.robi.db_jdbc.query.EntityBy2LongColumns;
import nokia.rtorkel.robi.db_jdbc.query.EntityBy2LongColumnsAndFeature;
import nokia.rtorkel.robi.db_jdbc.query.EntityByLikeColumn;
import nokia.rtorkel.robi.db_jdbc.query.EntityByLongColumn;
import nokia.rtorkel.robi.db_jdbc.query.EntityByRelatedEntity;
import nokia.rtorkel.robi.db_jdbc.query.EntityByStringColumn;
import nokia.rtorkel.robi.db_jdbc.query.FeaturesByEntity;
import nokia.rtorkel.robi.db_jdbc.query.LinksByEquipmentId;
import nokia.rtorkel.robi.db_jdbc.query.PathTerminationsByEquipmentId;

/**
 * Implementation for accessing actual databases.
 * <p>
 * This class does no direct logging. That's the job of the IxdbContext supplied to it.
 * 
 * @author rtorkel
 *
 */
public class DbHandleImpl extends DbHandle implements DbConstants
{
    protected final Connection      m_connection;
    public    final DbContextInterface     m_context;
    private   final Statement       m_straightQueryStatement;

    public final IdStringMapping m_equipTypeMap;
    public final IdStringMapping m_termTypeMap;
    public final IdStringMapping m_linkTypeMap;
    public final IdStringMapping m_pathTypeMap;
    
    protected final FeaturesByEntity      m_featuresBySubnet;
    protected final FeaturesByEntity      m_featuresByEquip;
    protected final FeaturesByEntity      m_featuresByTerm;
    protected final FeaturesByEntity      m_featuresByLink;
    protected final FeaturesByEntity      m_featuresByPath;
    protected final FeaturesByEntity      m_featuresByService;
    protected final FeaturesByEntity      m_featuresByCapacity;
    
    protected final AllOfEntityType       m_netsAll;
    protected final EntityByLongColumn    m_netById;
    protected final EntityByStringColumn  m_netByName;
    protected final EntityByRelatedEntity m_netsByEquipId;
    
    protected final EntityByLongColumn    m_equipById;
    protected final EntityByStringColumn  m_equipByName;
    protected final EntityByLongColumn    m_equipsByType;

    protected final EntityByLongColumn    m_termById;
    protected final EntityByStringColumn  m_termByName;
    protected final EntityByLongColumn    m_termsByType;
    protected final EntityByLikeColumn    m_termByNamePattern;
    protected final EntityByLongColumn    m_termsByEquipId;
    protected final EntityByRelatedEntity m_termsByPathId;
    protected final AncestryByLongColumn  m_termsByParentId;

    protected final EntityByLongColumn    m_linkById;
    protected final EntityByStringColumn  m_linkByName;
    protected final EntityByLongColumn    m_linksByTermAId;
    protected final EntityByLongColumn    m_linksByTermZId;
    protected final EntityBy2LongColumns  m_linksByBothTermIds;
    protected final EntityBy2LongColumnsAndFeature m_linksByBothTermIdsAndFeature;
    protected final LinksByEquipmentId    m_linksByEquipAId;
    protected final LinksByEquipmentId    m_linksByEquipZId;
    
    protected final EntityByLongColumn    m_pathById;
    protected final EntityByRelatedEntity m_pathsByTermId;
    protected final AncestryByLongColumn  m_pathsByParentId;

    protected final PathTerminationsByEquipmentId m_pathTermsByEquipId;
    protected final EntityByLongColumn            m_pathTermsByTermId;
    protected final EntityByLongColumn            m_pathTermsByPathId;

    protected final EntityByLongColumn    m_serviceById;
    protected final EntityByStringColumn  m_servicesByName;
    protected final EntityByLongColumn    m_servicesByCustomerId;
    
    protected final EntityByLongColumn    m_customerById;
    protected final EntityByStringColumn  m_customerByName;

    protected final EntityByLongColumn    m_capacityById;
    protected final EntityByStringColumn  m_capacityByName;
    protected final EntityByRelatedEntity m_capacitiesByLinkId;
    
    public
    DbHandleImpl(Connection         connection,
                 DbContextInterface context,
                 TransactionMode    transactionMode) throws SQLException
    {
        super(transactionMode);
        m_connection = connection;
        if (transactionMode.m_mayWrite)
        {
            connection.setAutoCommit(m_transactionMode.m_autoCommitFlag);
        }
        if (context != null)
        {
            m_context = context;
        }
        else
        {
            m_context = new StdoutDbContext("unnamed");
        }
        m_straightQueryStatement = m_connection.createStatement();
        m_equipTypeMap = new IdStringMapping(this, "equipment_types", "equipment_type_id", "equipment_type");
        m_termTypeMap =
                new IdStringMapping(
                        this, "termination_types", "termination_type_id", "termination_type");
        m_linkTypeMap = new IdStringMapping(this, "link_types", "link_type_id", "link_type");
        m_pathTypeMap = new IdStringMapping(this, "path_types", "path_type_id", "path_type");

        m_featuresBySubnet =
                new FeaturesByEntity(
                        m_connection, Network2.FEATURE_TABLE, m_context);
        m_featuresByEquip =
                new FeaturesByEntity(
                        m_connection, Equipment2.FEATURE_TABLE, m_context);
        m_featuresByTerm =
                new FeaturesByEntity(
                        m_connection, Termination2.FEATURE_TABLE, m_context);
        m_featuresByLink =
                new FeaturesByEntity(
                        m_connection, Link2.FEATURE_TABLE, m_context);
        m_featuresByPath =
                new FeaturesByEntity(
                        m_connection, Path2.FEATURE_TABLE, m_context);
        m_featuresByService =
                new FeaturesByEntity(
                        m_connection, Service2.FEATURE_TABLE, m_context);
        m_featuresByCapacity =
                new FeaturesByEntity(
                        m_connection, Capacity2.FEATURE_TABLE, m_context);

        m_netsAll = new AllOfEntityType(m_connection, Network2.ENTITY_TABLE, m_context);
        m_netById =
                new EntityByLongColumn(
                        m_connection,
                        Network2.ENTITY_TABLE, Network2.ENTITY_TABLE.m_idColumn,
                        m_context);
        m_netByName =
                new EntityByStringColumn(
                        m_connection,
                        Network2.ENTITY_TABLE, Network2.ENTITY_TABLE.m_nameColumn,
                        m_context);
        m_netsByEquipId =
                new EntityByRelatedEntity(
                        m_connection,
                        NetworkEquipment2.ENTITY_TABLE,
                        NetworkEquipment2.ENTITY_TABLE.m_equipIdColumn,
                        NetworkEquipment2.ENTITY_TABLE.m_subnetIdColumn,
                        Network2.ENTITY_TABLE,
                        m_context);

        m_equipById =
                new EntityByLongColumn(
                        m_connection,
                        Equipment2.ENTITY_TABLE, Equipment2.ENTITY_TABLE.m_idColumn,
                        m_context);
        m_equipByName =
                new EntityByStringColumn(
                        m_connection,
                        Equipment2.ENTITY_TABLE, Equipment2.ENTITY_TABLE.m_nameColumn,
                        m_context);
        m_equipsByType =
                new EntityByLongColumn(
                        m_connection,
                        Equipment2.ENTITY_TABLE, Equipment2.ENTITY_TABLE.m_typeColumn,
                        m_context);

        m_termById =
                new EntityByLongColumn(
                        m_connection,
                        Termination2.ENTITY_TABLE, Termination2.ENTITY_TABLE.m_idColumn,
                        m_context);
        m_termByName =
                new EntityByStringColumn(
                        m_connection,
                        Termination2.ENTITY_TABLE, Termination2.ENTITY_TABLE.m_nameColumn,
                        m_context);
        m_termsByType =
                new EntityByLongColumn(
                        m_connection,
                        Termination2.ENTITY_TABLE, Termination2.ENTITY_TABLE.m_typeColumn,
                        m_context);
        m_termByNamePattern =
                new EntityByLikeColumn(
                        m_connection,
                        Termination2.ENTITY_TABLE, Termination2.ENTITY_TABLE.m_nameColumn,
                        m_context);
        m_termsByEquipId =
                new EntityByLongColumn(
                        m_connection,
                        Termination2.ENTITY_TABLE, Termination2.ENTITY_TABLE.m_equipIdColumn,
                        m_context);
        m_termsByPathId =
                new EntityByRelatedEntity(
                        m_connection,
                        PathTermination2.ENTITY_TABLE,
                        PathTermination2.ENTITY_TABLE.m_pathIdColumn,
                        PathTermination2.ENTITY_TABLE.m_termIdColumn,
                        Termination2.ENTITY_TABLE,
                        m_context);
        m_termsByParentId =
                new AncestryByLongColumn(
                        m_connection,
                        AncestryTable.TERM_SUBTERM,
                        AncestryTable.TERM_SUBTERM.m_parentColumn,
                        AncestryTable.TERM_SUBTERM.m_childColumn,
                        m_context);

        m_linkById =
                new EntityByLongColumn(
                        m_connection,
                        Link2.ENTITY_TABLE, Link2.ENTITY_TABLE.m_idColumn,
                        m_context);
        m_linkByName =
                new EntityByStringColumn(
                        m_connection,
                        Link2.ENTITY_TABLE, Link2.ENTITY_TABLE.m_nameColumn,
                        m_context);
        m_linksByTermAId =
                new EntityByLongColumn(
                        m_connection,
                        Link2.ENTITY_TABLE, Link2.ENTITY_TABLE.m_termAIdColumn,
                        m_context);
        m_linksByTermZId =
                new EntityByLongColumn(
                        m_connection,
                        Link2.ENTITY_TABLE, Link2.ENTITY_TABLE.m_termZIdColumn,
                        m_context);
        m_linksByBothTermIds =
                new EntityBy2LongColumns(
                        m_connection,
                        Link2.ENTITY_TABLE, Link2.ENTITY_TABLE.m_termAIdColumn, Link2.ENTITY_TABLE.m_termZIdColumn,
                        m_context);
        m_linksByBothTermIdsAndFeature =
                new EntityBy2LongColumnsAndFeature(
                        m_connection,
                        Link2.ENTITY_TABLE, Link2.ENTITY_TABLE.m_termAIdColumn, Link2.ENTITY_TABLE.m_termZIdColumn,
                        Link2.FEATURE_TABLE,
                        m_context);
        m_linksByEquipAId =
                new LinksByEquipmentId(connection, Link2.ENTITY_TABLE.m_termAIdColumn, context);
        m_linksByEquipZId =
                new LinksByEquipmentId(connection, Link2.ENTITY_TABLE.m_termZIdColumn, context);

        m_pathById =
                new EntityByLongColumn(
                        m_connection,
                        Path2.ENTITY_TABLE, Path2.ENTITY_TABLE.m_idColumn,
                        m_context);
        m_pathsByTermId =
                new EntityByRelatedEntity(
                        m_connection,
                        PathTermination2.ENTITY_TABLE,
                        PathTermination2.ENTITY_TABLE.m_termIdColumn,
                        PathTermination2.ENTITY_TABLE.m_pathIdColumn,
                        Path2.ENTITY_TABLE,
                        m_context);
        m_pathsByParentId =
                new AncestryByLongColumn(
                        m_connection,
                        AncestryTable.PATH_SUBPATH,
                        AncestryTable.PATH_SUBPATH.m_parentColumn,
                        AncestryTable.PATH_SUBPATH.m_childColumn,
                        m_context);

        m_pathTermsByEquipId =
                new PathTerminationsByEquipmentId(m_connection, m_context);
        m_pathTermsByTermId =
                new EntityByLongColumn(
                        m_connection,
                        PathTermination2.ENTITY_TABLE, PathTermination2.ENTITY_TABLE.m_termIdColumn,
                        m_context);
        m_pathTermsByPathId =
                new EntityByLongColumn(
                        m_connection,
                        PathTermination2.ENTITY_TABLE, PathTermination2.ENTITY_TABLE.m_pathIdColumn,
                        m_context);

        m_serviceById =
                new EntityByLongColumn(
                        m_connection,
                        Service2.ENTITY_TABLE, Service2.ENTITY_TABLE.m_idColumn,
                        m_context);
        m_servicesByName =
                new EntityByStringColumn(
                        m_connection,
                        Service2.ENTITY_TABLE, Service2.ENTITY_TABLE.m_nameColumn,
                        m_context);
        m_servicesByCustomerId =
                new EntityByLongColumn(
                        m_connection,
                        Service2.ENTITY_TABLE, Service2.ENTITY_TABLE.m_customerIdColumn,
                        m_context);

        m_customerById =
                new EntityByLongColumn(
                        m_connection,
                        Customer2.ENTITY_TABLE, Customer2.ENTITY_TABLE.m_idColumn,
                        m_context);
        m_customerByName =
                new EntityByStringColumn(
                        m_connection,
                        Customer2.ENTITY_TABLE, Customer2.ENTITY_TABLE.m_nameColumn,
                        m_context);

        m_capacityById =
                new EntityByLongColumn(
                        m_connection,
                        Capacity2.ENTITY_TABLE, Capacity2.ENTITY_TABLE.m_idColumn,
                        m_context);
        m_capacityByName =
                new EntityByStringColumn(
                        m_connection,
                        Capacity2.ENTITY_TABLE, Capacity2.ENTITY_TABLE.m_nameColumn,
                        m_context);
        m_capacitiesByLinkId =
                new EntityByRelatedEntity(
                        m_connection,
                        LinkCapacity2.ENTITY_TABLE,
                        LinkCapacity2.ENTITY_TABLE.m_linkIdColumn,
                        LinkCapacity2.ENTITY_TABLE.m_capacityIdColumn,
                        Capacity2.ENTITY_TABLE,
                        m_context);
        
        m_context.finishInitialisation("Transaction mode = " + m_transactionMode);
    }

    @Override
    public String
    label()
    {
        return m_context.dbLabel();
    }
    
    public ResultSet
    executeStraightQuery(String querySql) throws SQLException
    {
        m_context.commenceQuery(querySql);
        ResultSet rs = m_straightQueryStatement.executeQuery(querySql);
        m_context.finishQuery();
        return rs;
    }
    
    public int
    executeStraightUpdate(String updateSql) throws SQLException
    {
        checkWritable();
        m_context.commenceUpdate(updateSql);
        int rowCount = m_straightQueryStatement.executeUpdate(updateSql);
        m_context.finishUpdate(rowCount);
        return rowCount;
    }
    
    public void
    commit() throws SQLException, DbException
    {
        checkWritable();
        m_context.commenceCommit();
        m_connection.commit();
        m_context.finishCommit();
    }
    
    public void
    rollback() throws SQLException, DbException
    {
        checkWritable();
        m_context.commenceRollback();
        m_connection.rollback();
        m_context.finishRollback();
    }
    
    public Feature2[]
    networkFeatures(Network2 subnet) throws SQLException
    {
        return featuresByEntity(subnet, m_featuresBySubnet);
    }
    
    public Feature2[]
    equipmentFeatures(Equipment2 equip) throws SQLException
    {
        return featuresByEntity(equip, m_featuresByEquip);
    }
    
    public Feature2[]
    terminationFeatures(Termination2 term) throws SQLException
    {
        return featuresByEntity(term, m_featuresByTerm);
    }
    
    public Feature2[]
    linkFeatures(Link2 term) throws SQLException
    {
        return featuresByEntity(term, m_featuresByLink);
    }
    
    public Feature2[]
    pathFeatures(Path2 path) throws SQLException
    {
        return featuresByEntity(path, m_featuresByPath);
    }
    
    public Feature2[]
    serviceFeatures(Service2 service) throws SQLException
    {
        return featuresByEntity(service, m_featuresByService);
    }
    
    public Feature2[]
    capacityFeatures(Capacity2 service) throws SQLException
    {
        return featuresByEntity(service, m_featuresByCapacity);
    }

    private Feature2[]
    featuresByEntity(PrimaryEntity    entity,
                     FeaturesByEntity statement) throws SQLException
    {
        enterFunction("featuresByEntity: " + entity.m_entityType);
        ResultSet rs = statement.run(entity);
        Feature2[] features = featuresFromResultSet(rs);
        return features;
    }
    
    public Network2[]
    networksAll() throws SQLException, DbException
    {
        enterFunction("subnetworksAll");
        ResultSet rs = m_netsAll.run();
        return subnetworksFromResultSet(rs);
    }
    
    public Network2
    networkById(long id) throws SQLException, DbException
    {
        enterFunction("subnetworkById");
        ResultSet rs = m_netById.run(id);
        return singleSubnetworkFromResultSet(rs);
    }
    
    public Network2
    networkByName(String name) throws SQLException, DbException
    {
        enterFunction("subnetworkByName");
        ResultSet rs = m_netByName.run(name);
        return singleSubnetworkFromResultSet(rs);
    }
    
    public Network2[]
    networksByEquipment(Equipment2 equip) throws SQLException, DbException
    {
        enterFunction("subnetworksByEquipment");
        ResultSet rs = m_netsByEquipId.run(equip.m_id);
        return subnetworksFromResultSet(rs);
    }
    
    public Equipment2
    equipmentById(long id) throws SQLException, DbException
    {
        enterFunction("equipmentById");
        ResultSet rs = m_equipById.run(id);
        return singleEquipmentFromResultSet(rs);
    }
    
    public Equipment2
    equipmentByName(String name) throws SQLException, DbException
    {
        enterFunction("equipmentByName");
        ResultSet rs = m_equipByName.run(name);
        return singleEquipmentFromResultSet(rs);
    }
    
    public Equipment2[]
    equipmentsByType(String type) throws DbException, SQLException
    {
        enterFunction("equipmentsByType");
        long typeId = m_equipTypeMap.getId(type);
        ResultSet rs = m_equipsByType.run(typeId);
        Equipment2[] equips = equipmentsFromResultSet(rs);
        return equips;
    }
    
    public Termination2
    terminationById(long id) throws SQLException, DbException
    {
        enterFunction("terminationById");
        ResultSet rs = m_termById.run(id);
        return singleTerminationFromResultSet(rs, null);
    }
    
    public Termination2
    terminationByName(String name) throws SQLException, DbException
    {
        enterFunction("terminationByName");
        ResultSet rs = m_termByName.run(name);
        return singleTerminationFromResultSet(rs, null);
    }
    
    public Termination2[]
    terminationsByType(String type) throws DbException, SQLException
    {
        enterFunction("terminationsByType");
        long typeId = m_termTypeMap.getId(type);
        ResultSet rs = m_termsByType.run(typeId);
        Termination2[] terms = terminationsFromResultSet(rs, null);
        return terms;
    }
    
    public Termination2[]
    terminationsByNamePattern(String namePattern) throws SQLException, DbException
    {
        enterFunction("terminationsByNamePattern");
        ResultSet rs = m_termByNamePattern.run(namePattern);
        return terminationsFromResultSet(rs, null);
    }
    
    public Termination2[]
    terminationsByEquipmentId(long equipId) throws SQLException, DbException
    {
        enterFunction("terminationByEquipmentId");
        ResultSet rs = m_termsByEquipId.run(equipId);
        return terminationsFromResultSet(rs, null);
    }
    
    public Termination2[]
    terminationsByEquipment(Equipment2 equip) throws SQLException, DbException
    {
        enterFunction("terminationByEquipment");
        ResultSet rs = m_termsByEquipId.run(equip.m_id);
        return terminationsFromResultSet(rs, equip);
    }
    
    public Termination2[]
    terminationsByPath(Path2 path) throws SQLException, DbException
    {
        enterFunction("terminationsByPath");
        ResultSet rs = m_termsByPathId.run(path.m_id);
        return terminationsFromResultSet(rs, null);
    }
    
    public Termination2[]
    subterminations(Termination2 parentTerm) throws SQLException, DbException
    {
        enterFunction("subTerminations");
        ResultSet rs = m_termsByParentId.run(parentTerm.m_id);
        return terminationsFromResultSet(rs, null);
    }
    
    public Link2
    linkById(long id) throws SQLException, DbException
    {
        enterFunction("linkById");
        ResultSet rs = m_linkById.run(id);
        return singleLinkFromResultSet(rs, null, null);
    }
    
    public Link2
    linkByName(String name) throws SQLException, DbException
    {
        enterFunction("linkByName");
        ResultSet rs = m_linkByName.run(name);
        return singleLinkFromResultSet(rs, null, null);
    }
    
    public Link2[]
    aFacingLinks(Termination2 termZ) throws SQLException, DbException
    {
        enterFunction("aFacingLinks");
        ResultSet rs = m_linksByTermZId.run(termZ.m_id);
        return linksFromResultSet(rs, null, termZ);
    }
    
    public Link2[]
    zFacingLinks(Termination2 termA) throws SQLException, DbException
    {
        enterFunction("zFacingLinks");
        ResultSet rs = m_linksByTermAId.run(termA.m_id);
        return linksFromResultSet(rs, termA, null);
    }
    
    public Link2[]
    aFacingLinksFromEquipment(Equipment2 equipZ) throws SQLException, DbException
    {
        enterFunction("aFacingLinksFromEquipment");
        ResultSet rs = m_linksByEquipZId.run(equipZ.m_id);
        return linksFromResultSet(rs, null, null);
    }
    
    public Link2[]
    linksByBothTerminations(Termination2 termA,
                            Termination2 termZ) throws SQLException, DbException
    {
        enterFunction("linksByBothTerminations");
        ResultSet rs = m_linksByBothTermIds.run(termA.m_id, termZ.m_id);
        return linksFromResultSet(rs, termA, termZ);
    }
    
    public Link2[]
    linksByBothTerminationsAndFeature(Termination2 termA,
                                      Termination2 termZ,
                                      String       name,
                                      String       value) throws SQLException, DbException
    {
        enterFunction("linksByBothTerminationsAndFeature");
        ResultSet rs = m_linksByBothTermIdsAndFeature.run(termA.m_id, termZ.m_id, name, value);
        return linksFromResultSet(rs, termA, termZ);
    }
    
    public Link2[]
    zFacingLinksFromEquipment(Equipment2 equipA) throws SQLException, DbException
    {
        enterFunction("zFacingLinksFromEquipment");
        ResultSet rs = m_linksByEquipAId.run(equipA.m_id);
        return linksFromResultSet(rs, null, null);
    }
    
    public Path2
    pathById(long id) throws SQLException, DbException
    {
        enterFunction("pathById");
        ResultSet rs = m_pathById.run(id);
        return singlePathFromResultSet(rs);
    }
    
    public Path2[]
    pathsByTermination(Termination2 term) throws SQLException, DbException
    {
        enterFunction("pathsByTermination");
        ResultSet rs = m_pathsByTermId.run(term.m_id);
        return pathsFromResultSet(rs);
    }
    
    public Path2[]
    subpaths(Path2 parentPath) throws SQLException, DbException
    {
        enterFunction("subPaths");
        ResultSet rs = m_pathsByParentId.run(parentPath.m_id);
        return pathsFromResultSet(rs);
    }
    
    public Path2[]
    pathsByTypeAndFeatures(String      type,
                           Feature2... expectedFeatures) throws DbException, SQLException
    {
        String sql =
               makeSqlByTypeAndFeatures(Path2.FEATURE_TABLE, m_pathTypeMap, type, expectedFeatures);
        ResultSet rs = executeStraightQuery(sql);
        return pathsFromResultSet(rs);
    }
    
    public PathTermination2[]
    pathTerminationsByEquipment(Equipment2 equip) throws SQLException, DbException
    {
        enterFunction("pathTerminationsByEquipment");
        ResultSet rs = m_pathTermsByEquipId.run(equip.m_id);
        return pathTerminationsFromResultSet(rs, null, null);
    }
    
    public PathTermination2[]
    pathTerminationsByTermination(Termination2 term) throws SQLException, DbException
    {
        enterFunction("pathTerminationsByTermination");
        ResultSet rs = m_pathTermsByTermId.run(term.m_id);
        return pathTerminationsFromResultSet(rs, null, term);
    }
    
    public PathTermination2[]
    pathTerminationsByPath(Path2 path) throws SQLException, DbException
    {
        enterFunction("pathTerminationsByPath");
        ResultSet rs = m_pathTermsByPathId.run(path.m_id);
        return pathTerminationsFromResultSet(rs, path, null);
    }
    
    public Service2
    serviceById(long id) throws SQLException, DbException
    {
        enterFunction("servicesById");
        ResultSet rs = m_serviceById.run(id);
        return singleServiceFromResultSet(rs, null);
    }
    
    public Service2[]
    servicesByName(String name) throws SQLException, DbException
    {
        enterFunction("servicesByName");
        ResultSet rs = m_servicesByName.run(name);
        return servicesFromResultSet(rs, null);
    }
    
    public Service2[]
    servicesByCustomer(Customer2 customer) throws SQLException, DbException
    {
        enterFunction("servicesByCustomer");
        ResultSet rs = m_servicesByCustomerId.run(customer.m_id);
        return servicesFromResultSet(rs, customer);
    }
    
    public Customer2
    customerById(long id) throws SQLException, DbException
    {
        enterFunction("customersById");
        ResultSet rs = m_customerById.run(id);
        return singleCustomerFromResultSet(rs);
    }
    
    public Customer2
    customerByName(String name) throws SQLException, DbException
    {
        enterFunction("customerByName");
        ResultSet rs = m_customerByName.run(name);
        return singleCustomerFromResultSet(rs);
    }
    
    public Capacity2
    capacityById(long id) throws SQLException, DbException
    {
        enterFunction("capacityById");
        ResultSet rs = m_capacityById.run(id);
        return singleCapacityFromResultSet(rs);
    }
    
    public Capacity2
    capacityByName(String name) throws SQLException, DbException
    {
        enterFunction("capacityByName");
        ResultSet rs = m_capacityByName.run(name);
        return singleCapacityFromResultSet(rs);
    }
    
    public Capacity2[]
    capacitiesByLink(Link2 link) throws SQLException, DbException
    {
        enterFunction("capacitiesByLink");
        ResultSet rs = m_capacitiesByLinkId.run(link.m_id);
        return capacitiesFromResultSet(rs);
    }
    
    /**
     * Makes a select query by optional type and by features.
     * @param type             null if type does not matter
     * @param expectedFeatures We are only interested in name and value.
     * @return query SQL
     * @throws DbException 
     */
    public String
    makeSqlByTypeAndFeatures(PrimaryEntity.FeatureTable featureTable,
                             IdStringMapping            typeMap,
                             String                     type,
                             Feature2...                expectedFeatures) throws DbException
    {
        long typeId = -1;
        if (type != null)
        {
            typeId = typeMap.getId(type);
        }
        PrimaryEntity.PrimaryEntityTable primaryEntityTable = featureTable.m_primaryEntityTable;
        StringBuilder buf = new StringBuilder(120);
        String tableLabel = "prim";
        buf.append(primaryEntityTable.makeSelectClauseNoLineEnd(tableLabel));
        buf.append(LINE_END);
        
        buf.append("    from ");
        buf.append(primaryEntityTable.m_tableName);
        buf.append(" ");
        buf.append(tableLabel);
        for (int i = 0; i < expectedFeatures.length; i++)
        {
            buf.append(",");
            buf.append(LINE_END);
            buf.append(featureTable.m_tableName);
            buf.append(" f");
            buf.append(i);
        }
        final String wherePrefix = "    where     ";
        final String andPrefix =   "          and ";
        if (type != null)
        {
            buf.append(LINE_END);
            buf.append(wherePrefix);
            buf.append(tableLabel);
            buf.append(".");
            buf.append(primaryEntityTable.m_typeColumn.m_name);
            buf.append(" = ");
            buf.append(typeId);
        }
        for (int i = 0; i < expectedFeatures.length; i++)
        {
            buf.append(LINE_END);
            if (i == 0 && type == null)
            {
                buf.append(wherePrefix);
            }
            else
            {
                buf.append(andPrefix);
            }
            buf.append("f");
            buf.append(i);
            buf.append(".");
            buf.append(primaryEntityTable.m_idColumn.m_name);
            buf.append(" = ");
            buf.append(tableLabel);
            buf.append(".");
            buf.append(primaryEntityTable.m_idColumn.m_name);
            buf.append(LINE_END);
            buf.append(andPrefix);
            buf.append("f");
            buf.append(i);
            buf.append(".name = '");
            buf.append(expectedFeatures[i].m_name);
            buf.append("'");
            buf.append(LINE_END);
            buf.append(andPrefix);
            buf.append("f");
            buf.append(i);
            buf.append(".value = '");
            buf.append(expectedFeatures[i].m_value);
            buf.append("'");
        }
        return buf.toString();
    }
    
    protected Network2
    singleSubnetworkFromResultSet(ResultSet  rs) throws SQLException, DbException
    {
        try
        {
            if (rs.next())
            {
                Network2 subnetwork = Network2.fromResultSet(this, rs);
                if (rs.next())
                {
                    throw new DbException("More than one service");
                }
                showResult(subnetwork);
                return subnetwork;
            }
            else
            {
                return null;
            }
        }
        finally
        {
            rs.close();
        }
    }
    
    protected Network2[]
    subnetworksFromResultSet(ResultSet rs) throws SQLException, DbException
    {
        try
        {
            ArrayList<Network2> subnetworkAl = new ArrayList<Network2>();
            while (rs.next())
            {
                Network2 subnetwork = Network2.fromResultSet(this, rs);
                subnetworkAl.add(subnetwork);
            }
            Network2[] subnetworks = new Network2[subnetworkAl.size()];
            subnetworkAl.toArray(subnetworks);
            showResult(subnetworks);
            return subnetworks;
        }
        finally
        {
            rs.close();
        }
    }
    
    protected Equipment2
    singleEquipmentFromResultSet(ResultSet rs) throws SQLException, DbException
    {
        try
        {
            if (rs.next())
            {
                Equipment2 equip = Equipment2.fromResultSet(this, rs);
                if (rs.next())
                {
                    throw new DbException("More than one equipment");
                }
                showResult(equip);
                return equip;
            }
            else
            {
                return null;
            }
        }
        finally
        {
            rs.close();
        }
    }
    
    protected Equipment2[]
    equipmentsFromResultSet(ResultSet rs) throws SQLException, DbException
    {
        try
        {
            ArrayList<Equipment2> equipAl = new ArrayList<Equipment2>();
            while (rs.next())
            {
                Equipment2 equip = Equipment2.fromResultSet(this, rs);
                equipAl.add(equip);
            }
            Equipment2[] equips = new Equipment2[equipAl.size()];
            equipAl.toArray(equips);
            showResult(equips);
            return equips;
        }
        finally
        {
            rs.close();
        }
    }
    
    /**
     * 
     * @param rs
     * @param equip Put null if not handy
     * @return
     * @throws SQLException
     * @throws DbException
     */
    protected Termination2
    singleTerminationFromResultSet(ResultSet  rs,
                                   Equipment2 equip) throws SQLException, DbException
    {
        try
        {
            if (rs.next())
            {
                Termination2 term = Termination2.fromResultSet(this, rs, equip);
                if (rs.next())
                {
                    throw new DbException("More than one termination");
                }
                showResult(term);
                return term;
            }
            else
            {
                return null;
            }
        }
        finally
        {
            rs.close();
        }
    }
    
    /**
     * 
     * @param rs
     * @param equip Put null if not handy
     * @return
     * @throws SQLException
     * @throws DbException
     */
    protected Termination2[]
    terminationsFromResultSet(ResultSet  rs,
                              Equipment2 equip) throws SQLException, DbException
    {
        try
        {
            ArrayList<Termination2> termAl = new ArrayList<Termination2>();
            while (rs.next())
            {
                Termination2 term = Termination2.fromResultSet(this, rs, equip);
                termAl.add(term);
            }
            Termination2[] terms = new Termination2[termAl.size()];
            termAl.toArray(terms);
            showResult(terms);
            return terms;
        }
        finally
        {
            rs.close();
        }
    }
    
    protected Link2
    singleLinkFromResultSet(ResultSet    rs,
                            Termination2 termA,
                            Termination2 termZ) throws SQLException, DbException
    {
        try
        {
            if (rs.next())
            {
                Link2 link = Link2.fromResultSet(this, rs, termA, termZ);
                if (rs.next())
                {
                    throw new DbException("More than one link");
                }
                showResult(link);
                return link;
            }
            else
            {
                return null;
            }
        }
        finally
        {
            rs.close();
        }
    }
    
    protected Link2[]
    linksFromResultSet(ResultSet    rs,
                       Termination2 termA,
                       Termination2 termZ) throws SQLException, DbException
    {
        try
        {
            ArrayList<Link2> linkAl = new ArrayList<Link2>();
            while (rs.next())
            {
                Link2 link = Link2.fromResultSet(this, rs, termA, termZ);
                linkAl.add(link);
            }
            Link2[] links = new Link2[linkAl.size()];
            linkAl.toArray(links);
            showResult(links);
            return links;
        }
        finally
        {
            rs.close();
        }
    }
    
    protected Path2
    singlePathFromResultSet(ResultSet    rs) throws SQLException, DbException
    {
        try
        {
            if (rs.next())
            {
                Path2 path = Path2.fromResultSet(this, rs);
                if (rs.next())
                {
                    throw new DbException("More than one path");
                }
                showResult(path);
                return path;
            }
            else
            {
                return null;
            }
        }
        finally
        {
            rs.close();
        }
    }
    
    protected Path2[]
    pathsFromResultSet(ResultSet    rs) throws SQLException, DbException
    {
        try
        {
            ArrayList<Path2> pathAl = new ArrayList<Path2>();
            while (rs.next())
            {
                Path2 path = Path2.fromResultSet(this, rs);
                pathAl.add(path);
            }
            Path2[] paths = new Path2[pathAl.size()];
            pathAl.toArray(paths);
            showResult(paths);
            return paths;
        }
        finally
        {
            rs.close();
        }
    }
    
    protected PathTermination2
    pathTerminationFromResultSet(ResultSet    rs,
                                 Path2        path,
                                 Termination2 term) throws SQLException, DbException
    {
        try
        {
            if (rs.next())
            {
                PathTermination2 pt = PathTermination2.fromResultSet(this, rs, path, term);
                if (rs.next())
                {
                    throw new DbException("More than one Path to Termination maplet");
                }
                showResult(pt);
                return pt;
            }
            else
            {
                return null;
            }
        }
        finally
        {
            rs.close();
        }
    }
    
    protected PathTermination2[]
    pathTerminationsFromResultSet(ResultSet    rs,
                                  Path2        path,
                                  Termination2 term) throws SQLException, DbException
    {
        try
        {
            ArrayList<PathTermination2> ptAl = new ArrayList<PathTermination2>();
            while (rs.next())
            {
                PathTermination2 pt = PathTermination2.fromResultSet(this, rs, path, term);
                ptAl.add(pt);
            }
            PathTermination2[] pts = new PathTermination2[ptAl.size()];
            ptAl.toArray(pts);
            showResult(pts);
            return pts;
        }
        finally
        {
            rs.close();
        }
    }
    
    protected Service2
    singleServiceFromResultSet(ResultSet  rs,
                               Customer2  customer) throws SQLException, DbException
    {
        try
        {
            if (rs.next())
            {
                Service2 service = Service2.fromResultSet(this, rs, customer);
                if (rs.next())
                {
                    throw new DbException("More than one service");
                }
                showResult(service);
                return service;
            }
            else
            {
                return null;
            }
        }
        finally
        {
            rs.close();
        }
    }
    
    protected Service2[]
    servicesFromResultSet(ResultSet rs,
                          Customer2 customer) throws SQLException, DbException
    {
        try
        {
            ArrayList<Service2> serviceAl = new ArrayList<Service2>();
            while (rs.next())
            {
                Service2 service = Service2.fromResultSet(this, rs, customer);
                serviceAl.add(service);
            }
            Service2[] services = new Service2[serviceAl.size()];
            serviceAl.toArray(services);
            showResult(services);
            return services;
        }
        finally
        {
            rs.close();
        }
    }
    
    protected Customer2
    singleCustomerFromResultSet(ResultSet  rs) throws SQLException, DbException
    {
        try
        {
            if (rs.next())
            {
                Customer2 customer = Customer2.fromResultSet(this, rs);
                if (rs.next())
                {
                    throw new DbException("More than one customer");
                }
                showResult(customer);
                return customer;
            }
            else
            {
                return null;
            }
        }
        finally
        {
            rs.close();
        }
    }
    
    protected Customer2[]
    customersFromResultSet(ResultSet rs) throws SQLException, DbException
    {
        try
        {
            ArrayList<Customer2> customerAl = new ArrayList<Customer2>();
            while (rs.next())
            {
                Customer2 customer = Customer2.fromResultSet(this, rs);
                customerAl.add(customer);
            }
            Customer2[] customers = new Customer2[customerAl.size()];
            customerAl.toArray(customers);
            showResult(customers);
            return customers;
        }
        finally
        {
            rs.close();
        }
    }
    
    protected Capacity2
    singleCapacityFromResultSet(ResultSet rs) throws SQLException, DbException
    {
        try
        {
            if (rs.next())
            {
                Capacity2 capacity = Capacity2.fromResultSet(this, rs);
                if (rs.next())
                {
                    throw new DbException("More than one capacity");
                }
                showResult(capacity);
                return capacity;
            }
            else
            {
                return null;
            }
        }
        finally
        {
            rs.close();
        }
    }
    
    protected Capacity2[]
    capacitiesFromResultSet(ResultSet rs) throws SQLException, DbException
    {
        try
        {
            ArrayList<Capacity2> capacityAl = new ArrayList<Capacity2>();
            while (rs.next())
            {
                Capacity2 capacity = Capacity2.fromResultSet(this, rs);
                capacityAl.add(capacity);
            }
            Capacity2[] capacities = new Capacity2[capacityAl.size()];
            capacityAl.toArray(capacities);
            showResult(capacities);
            return capacities;
        }
        finally
        {
            rs.close();
        }
    }
    
    protected Feature2[]
    featuresFromResultSet(ResultSet rs) throws SQLException
    {
        try
        {
            ArrayList<Feature2> featureAl = new ArrayList<Feature2>();
            while (rs.next())
            {
                Feature2 feature = Feature2.fromResultSet(rs);
                featureAl.add(feature);
            }
            Feature2[] features = new Feature2[featureAl.size()];
            featureAl.toArray(features);
            showResult(features);
            return features;
        }
        finally
        {
            rs.close();
        }
    }
    
    protected void
    enterFunction(String functionName)
    {
        m_context.enterFunction(functionName);
    }
    
    protected void
    showResult(Object object)
    {
        String s = object.toString();
        m_context.showResult(s);
    }
    
    protected void
    showResult(Object[] objects)
    {
        String s = toString(objects);
        m_context.showResult(s);
    }
    
    protected static String
    toString(Object[] entities)
    {
        StringBuilder buf = new StringBuilder();
        buf.append(entities.length);
        buf.append(" rows");
        buf.append(DbConstants.LINE_END);
        for (Object entity : entities)
        {
            buf.append("  ");
            buf.append(entity);
            buf.append(DbConstants.LINE_END);
        }
        return buf.toString();
    }
    
    private void
    checkWritable()
    {
        if (!m_transactionMode.m_mayWrite)
        {
            throw new RuntimeException(
                    "Attempted a write transaction on a non-write database handle");
        }
    }
}
