package nokia.rtorkel.robi.db_jdbc;

public class DbException extends Exception
{
    public
    DbException(String message)
    {
        super(message);
    }
    
    public
    DbException(Exception e)
    {
        super(e.getMessage(), e);
    }
}
