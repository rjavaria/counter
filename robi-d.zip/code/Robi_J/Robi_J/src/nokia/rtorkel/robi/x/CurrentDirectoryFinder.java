package nokia.rtorkel.robi.x;

import java.io.File;
import java.io.IOException;

public class CurrentDirectoryFinder
{
    public static void
    main(String[] args)
    {
        File currentDir = new File(".");
        String canonicalName;
        try
        {
            canonicalName = currentDir.getCanonicalPath();
        }
        catch (IOException e)
        {
            System.out.println("No canonical path: " + e);
            return;
        }
        System.out.println("Current directory is " + canonicalName);
    }
}
