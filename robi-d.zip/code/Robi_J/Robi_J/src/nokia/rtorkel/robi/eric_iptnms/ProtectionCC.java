package nokia.rtorkel.robi.eric_iptnms;

import rasmus_torkel.text.write.IndentingLineSink;
import rasmus_torkel.xml_basic.read.TagNode;

public class ProtectionCC extends CrossConnection
{
    public final AccessPoint _workerTp;
    public final AccessPoint _standByTp;
    public final AccessPoint _commonTp;
    public final AccessPoint _commonTpStandBy;
    
    @Override
    public String
    toString()
    {
        return super.toString() +
               " workerTp(" + _workerTp.name() + ") standByTp(" + _standByTp.name() +
               ") commonTp(" + _commonTp.name() + ") " +
               (_commonTpStandBy != null ? "commonTpStandBy(" + _commonTpStandBy.name() + ")" : "no commonTpStandBy");
    }
    
    public
    ProtectionCC(TagNode                node,
                 EricssonIptnmsEntities entities) throws EntityNotCreatedException
    {
        super(node);
        _workerTp = doOneSide(node, "ProtectionCC.designatedWorker", entities);
        _standByTp = doOneSide(node, "ProtectionCC.designatedStandby", entities);
        TagNode commonTpNode = node.nextChildE("ProtectionCC.commonTP");
        String commonTpId = commonTpNode.attributeValueE("AccessPoint");
        _commonTp = lookUpAp(commonTpId, entities);
        TagNode commonTpStandbyNode = node.nextChildN("ProtectionCC.commonTPStandBy");
        if (commonTpStandbyNode != null)
        {
            String commonTpStandById = commonTpNode.attributeValueE("AccessPoint");
            _commonTpStandBy = lookUpAp(commonTpStandById, entities);
        }
        else
        {
            _commonTpStandBy = null;
        }
        node.nextChildE("ProtectionCC.revertive");
        node.nextChildE("ProtectionCC.waitToRestoreTime");
        node.verifyNoMoreChildren();
        entities.putCC(this);
        _workerTp.notifyCrossConnection(this);
        _standByTp.notifyCrossConnection(this);
        _commonTp.notifyCrossConnection(this);
        if (_commonTpStandBy != null)
        {
            _commonTpStandBy.notifyCrossConnection(this);
        }
    }
    
    public AccessPoint
    doOneSide(TagNode                node,
              String                 sideNodeName,
              EricssonIptnmsEntities entities) throws EntityNotCreatedException
    {
        TagNode sideNode = node.nextChildE(sideNodeName);
        TagNode singleCCNode = sideNode.nextChildE("SingleCC");
        TagNode apNode = singleCCNode.nextChildE("SingleCC.diverseTP");
        String apId = apNode.attributeValueE("AccessPoint");
        singleCCNode.nextChildE("SingleCC.protectionCCStatus");
        singleCCNode.nextChildE("SingleCC.operatingState");
        singleCCNode.nextChildE("SingleCC.cycleLifeState");
        singleCCNode.nextChildE("SingleCC.degenerate");
        singleCCNode.verifyNoMoreChildren();
        sideNode.verifyNoMoreChildren();
        return lookUpAp(apId, entities);
    }
    
    public void
    toIndentingLineSink(IndentingLineSink sink)
    {
        sink.writeLine(toSlightlyShorterString());
        sink.incrementLevel();
        sink.writeLine("worker:        " + _workerTp.toStructureString());
        sink.writeLine("standBy:       " + _standByTp.toStructureString());
        sink.writeLine("common:        " + _commonTp.toStructureString());
        sink.writeLine("commonStandBy: " + _commonTpStandBy.toStructureString());
        sink.decrementLevel();
    }
}
