package nokia.rtorkel.robi.eric_iptnms.physterm;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CardPortOnShelf1Extractor extends ShelfCardPortExtractor
{
    public
    CardPortOnShelf1Extractor(Pattern pattern)
    {
        super(pattern);
    }
    
    protected String
    nameForInternalUse(String  neName,
                       String  dbTermName,
                       Matcher matcher)
    {
        String cardStr = matcher.group(1);
        String portStr = matcher.group(2);
        return InternalPortNameMaker.makeName(
                neName,
                1,
                toInt(dbTermName, cardStr),
                toInt(dbTermName, portStr));
    }
}
