package nokia.rtorkel.robi.eric_iptnms;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import nokia.rtorkel.robi.config.ConfigUtil;
import nokia.rtorkel.robi.config.LogConfigurer;
import nokia.rtorkel.robi.eric_iptnms.physterm.PhysTermNames_3Numbers;
import nokia.rtorkel.robi.eric_iptnms.physterm.PortNameFinder;
import nokia.rtorkel.robi.eric_iptnms.physterm.PortNameFinderOption;
import rasmus_torkel.config.ConfigFileReader;
import rasmus_torkel.config.PropertiesView;
import rasmus_torkel.text.write.Indent;
import rasmus_torkel.text.write.IndentingLineSink;
import rasmus_torkel.text.write.IndentingLineSinkOptions;
import rasmus_torkel.text.write.LineEndOption;
import rasmus_torkel.xml_basic.write.XmlSink;
import rasmus_torkel.xml_basic.write.XmlSinkWritable;

public class EricssonIptnmsEntities
{
    private static final Logger _logger = LogManager.getLogger(EricssonIptnmsEntities.class);
    
    public final PortNameFinder _portNameFinder;
    
    private HashMap<String,NetworkElement> _idToNe = new HashMap<String,NetworkElement>();
    private ArrayList<NetworkElement>      _neAl = new ArrayList<NetworkElement>();
    
    private HashMap<String,Subnetwork> _idToSubnet = new HashMap<String,Subnetwork>();
    private ArrayList<Subnetwork> _subnetAl = new ArrayList<Subnetwork>();
    
    private HashMap<String,PhLayerTtp> _idToPlt = new HashMap<String,PhLayerTtp>();
    private ArrayList<PhLayerTtp> _pltAl = new ArrayList<PhLayerTtp>();
    
    private HashMap<String,PhLink> _idToPhLk = new HashMap<String,PhLink>();
    private ArrayList<PhLink> _phLkAl = new ArrayList<PhLink>();
    
    private HashMap<String,HOLink> _idToHoLk = new HashMap<String,HOLink>();
    private ArrayList<HOLink> _hoLkAl = new ArrayList<HOLink>();
    
    private HashMap<String,AccessPoint> _idToAp = new HashMap<String,AccessPoint>();
    private ArrayList<AccessPoint> _apAl = new ArrayList<AccessPoint>();
    
    private ArrayList<CrossConnection> _ccAl = new ArrayList<CrossConnection>();
    
    private HashMap<String,Path> _idToPath = new HashMap<String,Path>();
    private ArrayList<Path> _pathAl = new ArrayList<Path>();
    
    private HashMap<String,Routing> _idToRouting = new HashMap<String,Routing>();
    private ArrayList<Routing> _routingAl = new ArrayList<Routing>();
    
    private HashMap<String,EliminatedEntity> _idToEliminatedEntity = new HashMap<String,EliminatedEntity>();
    
    public void
    putNe(NetworkElement ne)
    {
        _idToNe.put(ne._id, ne);
        _neAl.add(ne);
    }
    
    public NetworkElement
    lookUpNe(String id)
    {
        return _idToNe.get(id);
    }
    
    public void
    putSubnet(Subnetwork subnet)
    {
        _idToSubnet.put(subnet._id, subnet);
        _subnetAl.add(subnet);
    }
    
    public Subnetwork
    lookUpSubnet(String id)
    {
        return _idToSubnet.get(id);
    }
    
    public void
    putPlt(PhLayerTtp plt)
    {
        _idToPlt.put(plt._id, plt);
        _pltAl.add(plt);
    }
    
    public PhLayerTtp
    lookUpPlt(String id)
    {
        return _idToPlt.get(id);
    }
    
    public void
    putPhLk(PhLink phLk)
    {
        _idToPhLk.put(phLk._id, phLk);
        _phLkAl.add(phLk);
    }
    
    public PhLink
    lookUpPhLk(String id)
    {
        return _idToPhLk.get(id);
    }
    
    public void
    putHoLk(HOLink hoLk)
    {
        _idToHoLk.put(hoLk._id, hoLk);
        _hoLkAl.add(hoLk);
    }
    
    public HOLink
    lookUpHoLk(String id)
    {
        return _idToHoLk.get(id);
    }
    
    private void
    doPltProtectionRelations()
    {
        for (PhLayerTtp plt : _pltAl)
        {
            try
            {
                plt.assignProtectingPlt(this);
            }
            catch (EntityNotCreatedException e)
            {
            }
        }
    }
    
    public void
    putApId(String      id,
            AccessPoint ap)
    {
        _idToAp.put(id, ap);
    }
    
    public void
    putAp(AccessPoint ap)
    {
        _idToAp.put(ap._id, ap);
        _apAl.add(ap);
    }
    
    public AccessPoint
    lookUpAp(String id)
    {
        return _idToAp.get(id);
    }
    
    public void
    putCC(CrossConnection cc)
    {
        _ccAl.add(cc);
    }
    
    public Path
    lookUpPath(String id)
    {
        return _idToPath.get(id);
    }
    
    public void
    putPath(Path path)
    {
        _idToPath.put(path._id, path);
        _pathAl.add(path);
    }
    
    public Routing
    lookUpRouting(String id)
    {
        return _idToRouting.get(id);
    }
    
    public void
    putRouting(Routing routing)
    {
        _idToRouting.put(routing._id, routing);
        _routingAl.add(routing);
    }
    
    public void
    putEliminatedEntity(String id,
                        String category,
                        String reason)
    {
        EliminatedEntity entity = new EliminatedEntity(id, category, reason);
        _idToEliminatedEntity.put(id, entity);
        _logger.warn("Eliminated " + category + " " + id + ": " + reason);
    }
    
    public void
    putEliminatedEntityByDifferentId(String id,
                                     String category,
                                     String alreadyRecordedId)
    {
        EliminatedEntity eliminatedEntity = getEliminatedEntity(alreadyRecordedId);
        if (eliminatedEntity == null)
        {
            throw new RuntimeException(
                    "Eliminated " + category + " " + id +
                    " should have already been recorded as " + alreadyRecordedId + " but wasn't");
        }
        if (eliminatedEntity._reason != null)
        {
            _logger.warn("Eliminated " + category + " " + id + " because it is an alias for eliminated id " + alreadyRecordedId);
            putEliminatedEntity(id, category, eliminatedEntity._reason);
        }
        else
        {
            putEliminatedEntity(id, category, eliminatedEntity._previous);
        }
    }
    
    public void
    putEliminatedEntity(String           id,
                        String           category,
                        EliminatedEntity previous)
    {
        EliminatedEntity entity = new EliminatedEntity(id, category, previous);
        _idToEliminatedEntity.put(id, entity);
        StringBuilder buf = new StringBuilder();
        buf.append("Cascaded elimination for " + category + " " + id);
        for (EliminatedEntity current = previous; current != null; current = current._previous)
        {
            buf.append(" <-- " + current._category + " " + current._id);
            if (current._previous == null)
            {
                buf.append(": " + current._reason);
            }
        }
        _logger.warn(buf.toString());
    }
    
    public void
    putEliminatedDependentEntity(String id,
                                 String category,
                                 String referredToId,
                                 String referredToCategory)
    {
        EliminatedEntity previous = getEliminatedEntity(referredToId);
        if (previous == null)
        {
            String reason = "refers to non-existent " + category + " " + referredToId;
            putEliminatedEntity(id, category, reason);
        }
        else
        {
            putEliminatedEntity(id, category, previous);
        }
    }
    
    public EliminatedEntity
    getEliminatedEntity(String id)
    {
        return _idToEliminatedEntity.get(id);
    }
    
    public void
    summarise(File summaryDir)
    {
        summarise(summaryDir, "NetworkElement", _neAl);
        summarise(summaryDir, "Subnetwork", _subnetAl);
        summarise(summaryDir, "PhLink", _phLkAl);
        summarise(summaryDir, "HOLink", _hoLkAl);
        summarise(summaryDir, "PhLayerTtp", _pltAl);
        summarise(summaryDir, "AccessPoint", _apAl);
        summarise(summaryDir, "CrossConnection", _ccAl);
        summarise(summaryDir, "Path", _pathAl);
        summarise(summaryDir, "Routing", _routingAl);
        summariseApTypesToPhysical();
        _logger.info("Summarised all");
    }
    
    public void
    summarise(File         summaryDir,
              String       prefix,
              ArrayList<?> summarisableAl)
    {
        _logger.info("Summarising " + prefix);
        FileWriter summaryWriter = null;
        File summaryFile = new File(summaryDir, prefix + "_summary.txt");
        try
        {
            try
            {
                summaryWriter = new FileWriter(summaryFile);
                for (Object summarisable : summarisableAl)
                {
                    summaryWriter.write(summarisable + LineEndOption.UNIX._lineEndStr);
                }
            }
            finally
            {
                if (summaryWriter != null)
                {
                    summaryWriter.close();
                }
            }
        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }
    }
    
    public void
    summariseApTypesToPhysical()
    {
        HashMap<String,AccessPointSubtypeSummary> subtypeToSummary = new HashMap<String, AccessPointSubtypeSummary>();
        for (AccessPoint ap : _apAl)
        {
            AccessPointSubtypeSummary summary = subtypeToSummary.get(ap._type);
            if (summary == null)
            {
                summary = new AccessPointSubtypeSummary(ap._type);
                subtypeToSummary.put(ap._type, summary);
            }
            if (ap._plt == null)
            {
                summary._noPhLayerTpSummary.record(ap._id);
            }
            else if (   ap._subnet._ne == ap._plt._subnet._ne
                     && ap._shelf == ap._plt._shelf
                     && ap._card == ap._plt._card
                     && ap._port == ap._plt._port)
            {
                summary._phLayerTpMatchesTopoSummary.record(ap._id);
            }
            else
            {
                summary._phLayerTpDoesNotMatchTopoSummary.record(ap._id);
            }
        }
        AccessPointSubtypeSummary.report(subtypeToSummary);
    }
    
    public void
    report(File reportDir)
    {
        report(reportDir, "NetworkElement", _neAl);
        report(reportDir, "Path", _pathAl);
        report(reportDir, "AccessPoint", _apAl);
        report(reportDir, "HOLink", _hoLkAl);
        _logger.info("Reported all");
    }
    
    public void
    report(File         reportDir,
           String       prefix,
           ArrayList<?> reportableAl)
    {
        _logger.info("Reporting " + prefix);
        IndentingLineSinkOptions options = new IndentingLineSinkOptions(Indent.DEFAULT, LineEndOption.UNIX);
        IndentingLineSink reportWriter = null;
        File reportFile = new File(reportDir, prefix + "_report.txt");
        try
        {
            try
            {
                reportWriter = new IndentingLineSink(reportFile, options);
                for (Object reportableObj : reportableAl)
                {
                    ReportingEntity reportable = (ReportingEntity)reportableObj;
                    reportable.makeReport(reportWriter);
                }
            }
            finally
            {
                if (reportWriter != null)
                {
                    reportWriter.close();
                }
            }
        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }
    }
    
    public void
    makeXmlEntities(File entitiesDir)
    {
        makeXmlEntities(entitiesDir, "NetworkElement", _neAl);
        _logger.info("Reported all");
    }
    
    public void
    makeXmlEntities(File         entitiesDir,
                    String       prefix,
                    ArrayList<?> entityAl)
    {
        _logger.info("Making XML entities for " + prefix);
        File xmlEntitiesFile = new File(entitiesDir, prefix + ".xml");
        XmlSink sink = new XmlSink(xmlEntitiesFile);
        sink.startNode("entities");
        for (Object entity : entityAl)
        {
            XmlSinkWritable writableEntity = (XmlSinkWritable)entity;
            sink.sinkNode(writableEntity);
        }
        sink.closeNode();
    }
    
    private void
    findPathDepths()
    {
        _logger.info("Doing path depths");
        int previousUndoneQty = _pathAl.size();
        int round = 0;
        int undoneQty;
        do
        {
            _logger.info("Doing round " + round + ", " + previousUndoneQty + " left to do");
            round++;
            undoneQty = 0;
            Path undoneSample = null;
            for (Path path : _pathAl)
            {
                if (!path.findDepth())
                {
                    undoneQty++;
                    if (undoneSample == null)
                    {
                        undoneSample = path;
                    }
                }
            }
            if (undoneQty == previousUndoneQty)
            {
                throw new RuntimeException(
                        "Failed to do any undone path in round, therefore there must be a circularity, for example " +
                        undoneSample);
            }
            previousUndoneQty = undoneQty;
        } while (undoneQty > 0);
        _logger.info("Did path depths");
    }
    
    public
    EricssonIptnmsEntities(InputFileDirectory inputDir,
                           PortNameFinder     portNameFinder)
    {
        _portNameFinder = portNameFinder;
        _logger.info("Loading network elements");
        NetworkElement.load(inputDir, this);
        _logger.info("Loading subnetworks");
        Subnetwork.load(inputDir, this);
        _logger.info("Loading PhLayerTtps");
        PhLayerTtp.load(inputDir, this);
        doPltProtectionRelations();
        if (portNameFinder instanceof PhysTermNames_3Numbers)
        {
            PhysTermNames_3Numbers portNameFinder_3n = (PhysTermNames_3Numbers)portNameFinder;
            portNameFinder_3n.toXmlFile();
        }
        _logger.info("Loading PhLinks");
        PhLink.load(inputDir, this);
        _logger.info("Loading HOLinks");
        HOLink.load(inputDir, this);
        _logger.info("Loading access points");
        AccessPoint.load(inputDir, this);
        _logger.info("Loading cross connections");
        CrossConnection.load(inputDir, this);
        _logger.info("Loading paths");
        Path.load(inputDir, this);
        _logger.info("Loading routings");
        Routing.load(inputDir, this);
        _logger.info("Loaded all");
        findPathDepths();
    }
    /*
    public static EricssonIptnmsEntities
    make(InputFileDirectory inputFileDir,
         File               summaryDir)
    {
        PropertiesView dbPropView = SureDbConfigurer.getConfigurationFromResourceFile();
        DbHandle db = SureDbConfigurer.configureHandle(
                "SureDB", TransactionMode.READ_ONLY, dbPropView, SureDbConfigurer.XDM_DB_PARAM_NAME_PREFIX);
        File businessRulesFile = ConfigUtil.fileFromResource("ericsson_iptnms_business_rules.properties");
        PropertiesView businessRulesPropView = ConfigFileReader.propertiesViewFromFile(businessRulesFile);
        PhysTermNames_3Numbers portNameFinder = PhysTermNames_3Numbers.make(db, businessRulesPropView);
        EricssonIptnmsEntities entities = new EricssonIptnmsEntities(inputFileDir, summaryDir, portNameFinder);
        return entities;
    }*/
    
    public static EricssonIptnmsEntities
    make(PropertiesView propView)
    {
        File inputFileRawDir = getDirE(propView, "inputDir");
        InputFileDirectory inputFileDir = new InputFileDirectory(inputFileRawDir);
        PortNameFinder portNameFinder = PortNameFinderOption.makeFinder(propView);
        EricssonIptnmsEntities entities = new EricssonIptnmsEntities(inputFileDir, portNameFinder);
        return entities;
    }
    
    public static void
    main(String[] args)
    {
        if (args.length != 0)
        {
            throw new RuntimeException("This program takes no arguments");
        }
        try
        {
            LogConfigurer.configureLoggerDom();
            _logger.info("Configured logging");
            File configFile = ConfigUtil.fileFromResource("mdlgen_step1_ericsson_iptnms.properties");
            PropertiesView propView = ConfigFileReader.propertiesViewFromFile(configFile);
            File summaryDir = getDirN(propView, "summaryDir");
            File reportDir = getDirN(propView, "reportDir");
            EricssonIptnmsEntities entities = EricssonIptnmsEntities.make(propView);
            _logger.info(entities._neAl.size() + " network elements");
            _logger.info(entities._subnetAl.size() + " subnetworks");
            _logger.info(entities._pltAl.size() + " PhLayerTtp entities");
            _logger.info(entities._phLkAl.size() + " PhLink entities");
            _logger.info(entities._apAl.size() + " access points");
            _logger.info(entities._ccAl.size() + " cross connections");
            _logger.info(entities._pathAl.size() + " paths");
            _logger.info(entities._routingAl.size() + " routings");
            if (summaryDir != null)
            {
                entities.summarise(summaryDir);
            }
            if (reportDir != null)
            {
                entities.report(reportDir);
            }
        }
        catch (Exception e)
        {
            _logger.fatal(e.getMessage(), e);
        }
    }
    
    private static File
    getDirE(PropertiesView propView,
            String         propName)
    {
        File dir = propView.fileE(propName);
        verifyDirectory(propName, dir);
        return dir;
    }
    
    private static File
    getDirN(PropertiesView propView,
            String         propName)
    {
        File dir = propView.fileN(propName);
        if (dir == null)
        {
            return null;
        }
        verifyDirectory(propName, dir);
        return dir;
    }
    
    private static void
    verifyDirectory(String propName,
                    File   dir)
    {
        if (!dir.exists())
        {
            String message = "Directory " + dir + " declared in property " + propName + " does not exist";
            _logger.fatal(message);
            throw new RuntimeException(message);
        }
        if (!dir.isDirectory())
        {
            String message = "Directory " + dir + " declared in property " + propName + " is not a directory";
            _logger.fatal(message);
            throw new RuntimeException(message);
        }
        _logger.info("Directory " + dir + " declared as property " + propName);
    }
}
