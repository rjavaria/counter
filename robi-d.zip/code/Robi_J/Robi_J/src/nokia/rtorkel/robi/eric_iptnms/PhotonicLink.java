package nokia.rtorkel.robi.eric_iptnms;

import rasmus_torkel.xml_basic.read.TagNode;

public class PhotonicLink extends PhLink
{
    public final int _maxChannelNumber;
    
    public
    PhotonicLink(TagNode                node,
                 EricssonIptnmsEntities entities) throws EntityNotCreatedException
    {
        super(node.nextChildE("PhLink"), entities);
        _maxChannelNumber = EricssonXmlUtil.nextIntFieldE(node, "PhotonicLink.maxChannelNumber");
    }
}
