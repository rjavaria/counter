package nokia.rtorkel.robi.db_jdbc.query;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import nokia.rtorkel.robi.db_jdbc.EntityColumn;
import nokia.rtorkel.robi.db_jdbc.EntityTable;
import nokia.rtorkel.robi.db_jdbc.DbContextInterface;
import nokia.rtorkel.robi.db_jdbc.LazyPreparedStatement;
import nokia.rtorkel.robi.db_jdbc.PrimaryEntity;

public class EntityByRelatedEntity extends LazyPreparedStatement
{
    public
    EntityByRelatedEntity(Connection                connection,
                          EntityTable               relTable,
                          EntityColumn              relTableColumn1,
                          EntityColumn              relTableColumn2,
                          PrimaryEntity.PrimaryEntityTable table2,
                          DbContextInterface      context)
    {
        this(connection, relTable, relTableColumn1, relTableColumn2, table2, table2.m_idColumn, context);
    }

    protected
    EntityByRelatedEntity(Connection           connection,
                          EntityTable          relTable,
                          EntityColumn         relTableColumn1,
                          EntityColumn         relTableColumn2,
                          EntityTable          table2,
                          EntityColumn         table2IdColumn,
                          DbContextInterface context)
    {
        super(connection,
              makeSql(relTable, relTableColumn1, relTableColumn2, table2, table2IdColumn),
              context);
    }

    private static String
    makeSql(EntityTable  relTable,
            EntityColumn relTableColumn1,
            EntityColumn relTableColumn2,
            EntityTable  table2,
            EntityColumn table2IdColumn)
    {
        return
            table2.makeSimpleSelectClause() +
            "    from " + relTable.m_tableName + ", " + table2.m_tableName + LINE_END +
            "    where     " + relTableColumn1.m_tabColPhrase + " = ?" + LINE_END +
            "          and " + table2IdColumn.m_tabColPhrase + " = " + relTableColumn2.m_tabColPhrase;
    }
    
    public ResultSet
    run(long value) throws SQLException
    {
        ensureReady();
        setLong(1, value);
        return executeQuery();
    }
}
