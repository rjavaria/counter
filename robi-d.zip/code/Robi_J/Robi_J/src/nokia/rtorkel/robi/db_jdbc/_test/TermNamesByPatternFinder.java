package nokia.rtorkel.robi.db_jdbc._test;

import java.sql.Connection;

import nokia.rtorkel.robi.db_jdbc.DbContextInterface;
import nokia.rtorkel.robi.db_jdbc.DbHandle;
import nokia.rtorkel.robi.db_jdbc.DbHandleImpl;
import nokia.rtorkel.robi.db_jdbc.JdbcManager2;
import nokia.rtorkel.robi.db_jdbc.StdoutDbContext;
import nokia.rtorkel.robi.db_jdbc.Termination2;
import nokia.rtorkel.robi.db_jdbc.TransactionMode;

public class TermNamesByPatternFinder
{
    public static void
    main(String[] args)
    {
        if (args.length != 4)
        {
            System.out.println("params are url userName password namePattern");
            System.exit(-1);
        }
        try
        {
            JdbcManager2 manager =
                    new JdbcManager2(args[0], args[1], args[2], "oracle.jdbc.driver.OracleDriver");
            DbContextInterface context = new StdoutDbContext("DB unit test");
            Connection connection = manager.getConnection();
            DbHandle db = new DbHandleImpl(connection, context, TransactionMode.READ_ONLY);
            testRead(db, args[3]);
        }
        catch (Exception e)
        {
            e.printStackTrace(System.out);
        }
    }
    
    public static void
    testRead(DbHandle db,
             String     namePattern) throws Exception
    {
        Termination2[] terms = db.terminationsByNamePattern(namePattern);
        for (Termination2 term : terms)
        {
            System.out.println(term.m_name);
        }
        System.out.println("");
        System.out.println(terms.length);
    }
}
