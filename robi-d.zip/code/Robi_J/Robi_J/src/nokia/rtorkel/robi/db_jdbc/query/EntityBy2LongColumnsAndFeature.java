package nokia.rtorkel.robi.db_jdbc.query;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import nokia.rtorkel.robi.db_jdbc.DbContextInterface;
import nokia.rtorkel.robi.db_jdbc.EntityColumn;
import nokia.rtorkel.robi.db_jdbc.LazyPreparedStatement;
import nokia.rtorkel.robi.db_jdbc.PrimaryEntity;
import nokia.rtorkel.robi.db_jdbc.PrimaryEntity.FeatureTable;

public class EntityBy2LongColumnsAndFeature extends LazyPreparedStatement
{
    public
    EntityBy2LongColumnsAndFeature(Connection                       connection,
                                   PrimaryEntity.PrimaryEntityTable entityTable,
                                   EntityColumn                     column1,
                                   EntityColumn                     column2,
                                   FeatureTable                     featureTable,
                                   DbContextInterface               context)
    {
        super(connection, makeSql(entityTable, column1, column2, featureTable), context);
    }

    public static String
    makeSql(PrimaryEntity.PrimaryEntityTable  entityTable,
            EntityColumn column1,
            EntityColumn column2,
            FeatureTable featureTable)
    {
        String sql =
                entityTable.makeSimpleSelectClause() +
                "    from " + entityTable.m_tableName + "," + LINE_END +
                "         " + featureTable.m_tableName + LINE_END +
                "    where     " + column1.m_tabColPhrase + " = ?" + LINE_END +
                "          and " + column2.m_tabColPhrase + " = ?" + LINE_END +
                "          and " + featureTable.m_tableName + "." + featureTable.m_entityColumnName + " = " + entityTable.m_idColumn.m_tabColPhrase + LINE_END +
                "          and name = ?" + LINE_END +
                "          and value = ?";
        return sql;
    }
    
    public ResultSet
    run(long   columnValue1,
        long   columnValue2,
        String featureName,
        String featureValue) throws SQLException
    {
        ensureReady();
        setLong(1, columnValue1);
        setLong(2, columnValue2);
        setString(3, featureName);
        setString(4, featureValue);
        return executeQuery();
    }
}
