package nokia.rtorkel.robi.eric_iptnms;

import java.io.File;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import nokia.rtorkel.robi.eric_iptnms.physterm.InternalPortNameMaker;
import rasmus_torkel.xml_basic.read.TagNode;
import rasmus_torkel.xml_basic.read.XmlReadOptions;
import rasmus_torkel.xml_basic.read.impl.XmlReader;

public class PhLayerTtp
{
    private static final Logger _logger = LogManager.getLogger(PhLayerTtp.class);
    
    public final String     _id;
    public final String     _name;
    public final Subnetwork _subnet;
    public final int        _shelf;
    public final int        _card;
    public final int        _port;
    public final String     _channelName;
    public final int        _tp;
    public final boolean    _isVirtual;
    public final String     _protectionType;
    public final String     _portType;
    public final String     _protectingPltId;
    private      PhLayerTtp _protectingPlt;
    
    @Override
    public String
    toString()
    {
        return _id + " " + _name + " " + _portType + " " + _protectionType + " " + _channelName;
    }
    
    public
    PhLayerTtp(TagNode                node,
               EricssonIptnmsEntities entities) throws EntityNotCreatedException
    {
        _id = node.attributeValueE("Id");
        String subnetId = node.nextChildE("PhLayerTtp.subNetwork").attributeValueE("SubNetwork");
        _subnet = entities.lookUpSubnet(subnetId);
        if (_subnet == null)
        {
            entities.putEliminatedDependentEntity(_id, "PhLayerTtp", subnetId, "subnetwork");
            throw new EntityNotCreatedException();
        }
        if (_subnet._neName == null)
        {
            entities.putEliminatedEntity(
                    _id, "PhLayerTtp",
                    "refers to subnetwork " + subnetId + " which is not associated with any NetworkElement");
            throw new EntityNotCreatedException();
        }
        _protectingPltId = EricssonXmlUtil.nextIdFieldN(node, "PhLayerTtp.thePhLayerTtpProtecting", "PhLayerTtp");
        int slot = EricssonXmlUtil.nextIntFieldD(node, "PhLayerTtp.physicalSlotId", -1);
        EricssonXmlUtil.nextIntFieldD(node, "PhLayerTtp.mSPRingDataNodeId", -1);
        EricssonXmlUtil.nextIntFieldD(node, "PhLayerTtp.mSPRingDataRingId", -1);
        _tp = EricssonXmlUtil.nextIntFieldE(node, "PhLayerTtp.tPId");
        node.nextChildE("PhLayerTtp.subNetworkId");
        _channelName = EricssonXmlUtil.nextTextFieldE(node, "PhLayerTtp.channelName");
        node.nextChildE("PhLayerTtp.logicalPortLabel");
        node.nextChildE("PhLayerTtp.freeBusyTx");
        node.nextChildE("PhLayerTtp.freeBusyRx");
        _shelf = EricssonXmlUtil.nextIntFieldE(node, "PhLayerTtp.shelfIdOnNM");
        _card = EricssonXmlUtil.nextIntFieldE(node, "PhLayerTtp.cardId");
        if (slot != -1 && slot != _card)
        {
            entities.putEliminatedEntity(
                    _id, "PhLayerTtp", "has physicalSlotId " + slot + " different from cardId " + _card);
            throw new EntityNotCreatedException();
        }
        _port = EricssonXmlUtil.nextIntFieldE(node, "PhLayerTtp.portId");
        _protectionType = EricssonXmlUtil.nextEnumFieldE(node, "PhLayerTtp.protectionType", "DTProtectionType");
        _portType = EricssonXmlUtil.nextEnumFieldE(node, "PhLayerTtp.portType", "DTPortType");
        _isVirtual = _subnet._neName.startsWith("virtualSubnet_");
        String internalName = InternalPortNameMaker.makeName(_subnet._neName, _shelf, _card, _port);
        if (_isVirtual)
        {
            _name = internalName;
        }
        else
        {
            _name = entities._portNameFinder.findPortName(_subnet._neName, _portType, _shelf, _card, _port);
            if (_name == null)
            {
                entities.putEliminatedEntity(
                        _id, "PhLayerTtp",
                        "has no match in DB for internal name " + internalName + ", we will discard it");
                throw new EntityNotCreatedException();
            }
        }
        if (_name != null)
        {
            entities.putPlt(this);
        }
        if (_subnet._ne != null)
        {
            NetworkElement ne = entities.lookUpNe(_subnet._ne._id);
            ne.notifyPhLayerTtp(this);
        }
    }
    
    public void
    assignProtectingPlt(EricssonIptnmsEntities entities) throws EntityNotCreatedException
    {
        if (_protectingPltId != null)
        {
            _protectingPlt = entities.lookUpPlt(_protectingPltId);
            if (_protectingPlt == null)
            {
                entities.putEliminatedDependentEntity(_id, "PhLayerTtp", _protectingPltId, "PhLayerTtp");
                throw new EntityNotCreatedException();
            }
        }
    }
    
    public PhLayerTtp
    protectingPlt()
    {
        return _protectingPlt;
    }
    
    public static void
    load(InputFileDirectory     dir,
         EricssonIptnmsEntities entities)
    {
        File neFile = dir.getInputFile("PhLayerTtp");
        TagNode rootNode = XmlReader.xmlFileToRoot(neFile, XmlReadOptions.DEFAULT, "NetworkManager");
        rootNode.nextChildE("Version");
        TagNode level1Node;
        int processedQty = 0;
        do
        {
            level1Node = rootNode.nextChildN("PhLayerTtp");
            if (level1Node != null)
            {
                try
                {
                    new PhLayerTtp(level1Node, entities);
                }
                catch (EntityNotCreatedException e)
                {
                }
            }
            processedQty++;
            if (   processedQty == 1
                || processedQty == 10
                || processedQty == 100
                || processedQty % 500 == 0)
            {
                _logger.info("Processed " + processedQty);
            }
        } while (level1Node != null);
        _logger.info("Processed " + processedQty + ", finished PhLayerTtp entities");
        rootNode.nextChildE("Summary");
        rootNode.verifyNoMoreChildren();
    }
}
