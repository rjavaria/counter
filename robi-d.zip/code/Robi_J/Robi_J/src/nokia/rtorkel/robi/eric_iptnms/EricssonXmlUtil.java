package nokia.rtorkel.robi.eric_iptnms;

import rasmus_torkel.xml_basic.read.TagNode;

public class EricssonXmlUtil
{
    public static String
    nextTextFieldE(TagNode parent,
                   String  fieldName)
    {
        TagNode fieldNode = parent.nextChildE(fieldName);
        String field = fieldNode.nextTextFieldE("DTString");
        fieldNode.verifyNoMoreChildren();
        return field;
    }
    
    public static String
    nextTextFieldN(TagNode parent,
                   String  fieldName)
    {
        TagNode fieldNode = parent.nextChildN(fieldName);
        if (fieldNode == null)
        {
            return null;
        }
        String field = fieldNode.nextTextFieldE("DTString");
        fieldNode.verifyNoMoreChildren();
        return field;
    }
    
    public static int
    nextIntFieldE(TagNode parent,
                  String  fieldName)
    {
        TagNode fieldNode = parent.nextChildE(fieldName);
        int textField = fieldNode.nextIntFieldE("DTInteger");
        fieldNode.verifyNoMoreChildren();
        return textField;
    }
    
    public static int
    nextIntFieldD(TagNode parent,
                  String  fieldName,
                  int     defaultValue)
    {
        TagNode fieldNode = parent.nextChildN(fieldName);
        if (fieldNode == null)
        {
            return defaultValue;
        }
        int textField = fieldNode.nextIntFieldE("DTInteger");
        fieldNode.verifyNoMoreChildren();
        return textField;
    }
    
    public static boolean
    nextBoolFieldE(TagNode parent,
                   String  fieldName)
    {
        TagNode fieldNode = parent.nextChildE(fieldName);
        return extractBool(fieldNode);
    }
    
    private static boolean
    extractBool(TagNode fieldNode)
    {
        TagNode boolNode = fieldNode.nextChildE("DTBoolean");
        TagNode boolValueNode = boolNode.nextChildE();
        if (boolValueNode._id._relativeName.equalsIgnoreCase("DTBoolean.true"))
        {
            return true;
        }
        else if (boolValueNode._id._relativeName.equalsIgnoreCase("DTBoolean.false"))
        {
            return false;
        }
        else
        {
            throw new RuntimeException(boolValueNode + " does not represent a valid boolean");
        }
    }
    
    public static String
    nextEnumFieldN(TagNode parent,
                   String  fieldName,
                   String  typeString)
    {
        TagNode fieldNode = parent.nextChildN(fieldName);
        if (fieldNode == null)
        {
            return null;
        }
        return extractEnumE(fieldNode, fieldName, typeString);
    }
    
    public static String
    nextEnumFieldE(TagNode parent,
                   String  fieldName,
                   String  typeString)
    {
        TagNode fieldNode = parent.nextChildE(fieldName);
        return extractEnumE(fieldNode, fieldName, typeString);
    }
    
    private static String
    extractEnumE(TagNode fieldNode,
                 String  fieldName,
                 String  typeString)
    {
        TagNode middleNode = fieldNode.nextChildE(typeString);
        TagNode innerNode = middleNode.nextChildE();
        String innerPrefix = typeString + ".";
        if (!innerNode._id._relativeName.startsWith(innerPrefix))
        {
            throw new RuntimeException(innerNode + ", name does not start with " + innerPrefix);
        }
        innerNode.verifyNoMoreChildren();
        middleNode.verifyNoMoreChildren();
        fieldNode.verifyNoMoreChildren();
        return innerNode._id._relativeName.substring(innerPrefix.length());
    }
    
    public static String
    nextIdFieldN(TagNode parent,
                 String  fieldName,
                 String  idAttributeName)
    {
        TagNode fieldNode = parent.nextChildN(fieldName);
        if (fieldNode == null)
        {
            return null;
        }
        return fieldNode.attributeValueE(idAttributeName);
    }
    
    public static String
    nextIdFieldE(TagNode parent,
                 String  fieldName,
                 String  idAttributeName)
    {
        TagNode fieldNode = parent.nextChildE(fieldName);
        return fieldNode.attributeValueE(idAttributeName);
    }
}
