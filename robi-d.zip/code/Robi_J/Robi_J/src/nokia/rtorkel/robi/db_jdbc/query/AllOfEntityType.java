package nokia.rtorkel.robi.db_jdbc.query;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import nokia.rtorkel.robi.db_jdbc.EntityTable;
import nokia.rtorkel.robi.db_jdbc.DbContextInterface;
import nokia.rtorkel.robi.db_jdbc.LazyPreparedStatement;

public class AllOfEntityType extends LazyPreparedStatement
{
    public AllOfEntityType(Connection            connection,
                           EntityTable           table,
                           DbContextInterface  context)
    {
        super(connection, table.makeAllQuery(), context);
    }
    
    public ResultSet
    run() throws SQLException
    {
        ensureReady();
        return executeQuery();
    }
}
