package nokia.rtorkel.robi.eric_iptnms;

import java.io.File;
import java.util.ArrayList;

import rasmus_torkel.text.write.IndentingLineSink;
import rasmus_torkel.xml_basic.read.TagNode;
import rasmus_torkel.xml_basic.read.XmlReadOptions;
import rasmus_torkel.xml_basic.read.impl.XmlReader;

public abstract class Routing
{
    public final String _id;
    public final String _type;
    public final Path   _supportedPath;
    public final String _pathType;
    
    protected int _depth = -1;
    
    @Override
    public String
    toString()
    {
        return _id + " " + _type + " " + _supportedPath._id + " " + _pathType;
    }
    
    public
    Routing(TagNode                node,
            EricssonIptnmsEntities entities) throws EntityNotCreatedException
    {
        _type = node._id._relativeName;
        TagNode pathRoutingNode = node.nextChildE("PathRouting");
        _id = pathRoutingNode.attributeValueE("Id");
        TagNode pathIdNode = pathRoutingNode.nextChildE("PathRouting.thePath");
        String pathId = pathIdNode.attributeValueE("Path");
        _supportedPath = entities.lookUpPath(pathId);
        if (_supportedPath == null)
        {
            throw new EntityNotCreatedException(_id, "Routing", pathId, "Path", entities);
        }
        pathRoutingNode.nextChildE("PathRouting.pathId");
        _pathType = EricssonXmlUtil.nextEnumFieldE(pathRoutingNode, "PathRouting.pathType", "DTPathType");
        pathRoutingNode.verifyNoMoreChildren();
    }
    
    protected Route
    route(TagNode                parentNode,
          String                 routeName,
          EricssonIptnmsEntities entities) throws EntityNotCreatedException
    {
        TagNode outerRouteNode = parentNode.nextChildE(routeName);
        TagNode innerRouteNode = outerRouteNode.nextChildE("Route");
        ArrayList<RouteComponent> componentAl = new ArrayList<RouteComponent>();
        boolean gotAllComponents = false;
        while (!gotAllComponents)
        {
            TagNode outerComponentNode = innerRouteNode.nextChildN("Route.theRouteNode");
            if (outerComponentNode != null)
            {
                TagNode middleComponentNode = outerComponentNode.nextChildE("RouteNode");
                TagNode componentRefNode = middleComponentNode.nextChildE();
                RouteComponent component;
                if (componentRefNode._id._relativeName.equals("RouteNode.theTp"))
                {
                    String apId = componentRefNode.attributeValueE("AccessPoint");
                    component = entities.lookUpAp(apId);
                    if (component == null)
                    {
                        entities.putEliminatedDependentEntity(_id, "Routing", apId, "AccessPoint");
                        throw new EntityNotCreatedException();
                        //System.out.println(
                        //        "Routing " + _id +
                        //        " references non-existent component access point " + apId);
                        //component = new MissingRouteComponent("AccessPoint", apId);
                    }
                }
                else if (componentRefNode._id._relativeName.equals("RouteNode.thePath"))
                {
                    String pathId = componentRefNode.attributeValueE("Path");
                    component = entities.lookUpPath(pathId);
                    if (component == null)
                    {
                        entities.putEliminatedDependentEntity(_id, "Routing", pathId, "Path");
                        throw new EntityNotCreatedException();
                    }
                }
                else
                {
                    throw new RuntimeException(
                            "Routing " + _id +
                            " has unrecognised component reference node " + componentRefNode);
                }
                componentAl.add(component);
            }
            else
            {
                gotAllComponents = true;
            }
        }
        RouteComponent[] components = new RouteComponent[componentAl.size()];
        componentAl.toArray(components);
        return new Route(components);
    }
    
    public abstract AccessPoint
    firstAccessPoint();
    
    public abstract AccessPoint
    lastAccessPoint();
    
    public abstract void
    toIndentingLineSink(IndentingLineSink sink);
    
    public int
    depth()
    {
        return _depth;
    }
    
    public abstract boolean
    findDepth();
    
    public static void
    load(InputFileDirectory     dir,
         EricssonIptnmsEntities entities)
    {
        File neFile = dir.getInputFile("Routing");
        TagNode rootNode = XmlReader.xmlFileToRoot(neFile, XmlReadOptions.DEFAULT, "NetworkManager");
        rootNode.nextChildE("Version");
        boolean haveSummary = false;
        do
        {
            TagNode level1Node = rootNode.nextChildE();
            if (level1Node._id._relativeName.equals("SimpleRouting"))
            {
                try
                {
                    new SimpleRouting(level1Node, entities);
                }
                catch (EntityNotCreatedException e)
                {
                }
            }
            else if (level1Node._id._relativeName.equals("ProtectionRouting"))
            {
                try
                {
                    new ProtectionRouting(level1Node, entities);
                }
                catch (EntityNotCreatedException e)
                {
                }
            }
            else if (level1Node._id._relativeName.equals("Summary"))
            {
                rootNode.verifyNoMoreChildren();
                haveSummary = true;
            }
            else
            {
                throw new RuntimeException("Node with unexpected name: " + level1Node);
            }
        } while (!haveSummary);
    }
}
