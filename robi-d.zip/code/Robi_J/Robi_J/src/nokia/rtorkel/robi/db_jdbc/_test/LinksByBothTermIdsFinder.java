package nokia.rtorkel.robi.db_jdbc._test;

import nokia.rtorkel.robi.db_jdbc.DbHandle;
import nokia.rtorkel.robi.db_jdbc.DbHandleImpl;
import nokia.rtorkel.robi.db_jdbc.Link2;
import nokia.rtorkel.robi.db_jdbc.ObjectFormatter;
import nokia.rtorkel.robi.db_jdbc.Termination2;

public class LinksByBothTermIdsFinder extends DbUnitTest
{
    public static void
    main(String[] args)
    {
        try
        {
            DbHandleImpl db = makeDbHandle(args, "aTermId", "zTermId");
            testRead(db, args[3], args[4]);
        }
        catch (Exception e)
        {
            e.printStackTrace(System.out);
        }
    }
    
    public static void
    testRead(DbHandle db,
             String   aTermIdS,
             String   zTermIdS) throws Exception
    {
        long aTermId = Long.parseLong(aTermIdS);
        long zTermId = Long.parseLong(zTermIdS);
        Termination2 aTerm = db.terminationById(aTermId);
        if (aTerm == null)
        {
            System.out.println("No termination for aTermId " + aTermId);
            return;
        }
        Termination2 zTerm = db.terminationById(zTermId);
        if (zTerm == null)
        {
            System.out.println("No termination for zTermId " + zTermId);
            return;
        }
        Link2[] links = db.linksByBothTerminations(aTerm, zTerm);
        if (links.length == 0)
        {
            System.out.println("No links");
            return;
        }
        String linkDump = ObjectFormatter.toString("link", links[0]);
        System.out.println(linkDump);
    }
}
