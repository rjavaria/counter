package nokia.rtorkel.robi.x;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import rasmus_torkel.namedvalue.NamedString;
import rasmus_torkel.text.write.LineEndOption;

public class EmsNeMilGenerator_FileWriter
{
    private static final String[] _sites = { "Dhaka", "Khulna", "Sylhet" };
    private static final String[] _neTypes = { "Generic NE", "1650SMC" };
    private static final String   _lineEnd = LineEndOption.SYSTEM_PROPERTY._lineEndStr;
    
    public static void
    main(String[] args)
    {
        if (args.length != 2)
        {
            throw new RuntimeException("Need exactly two args, outputFileName, neQty");
        }
        try
        {
            FileWriter sink = new FileWriter(new File(args[0]));
            int qty = Integer.parseInt(args[1]);
            sink.write("<NetworkEntity>" + _lineEnd);
            for (int i = 0; i < qty; i++)
            {
                if (i == 10 || i == 100 || i == 1000 || i == 10000 || i == 100000)
                {
                    System.out.println("Did " + i);
                }
                doOne(sink, i);
            }
            sink.write("</NetworkEntity>" + _lineEnd);
        }
        catch (Exception e)
        {
            e.printStackTrace(System.out);
        }
    }
    
    private static void
    doOne(FileWriter sink,
          int        i) throws IOException
    {
        sink.write("  <Equipment>" + _lineEnd);
        sink.write("    <Name>ROBINE_BANGL_" + i + "</Name>" + _lineEnd);
        sink.write("    <Type>" + _neTypes[i % _neTypes.length] + "</Type>" + _lineEnd);
        sink.write("    <NetworkName>ntwDomId=1/emlDomId=100</NetworkName>" + _lineEnd);
        sink.write("    <LocationName>" + _sites[i % _sites.length] + "<LocationName>" + _lineEnd);
        sink.write("    <Features>" + _lineEnd);
        NamedString fdnFeature = new NamedString("FDN", "ntwDomId=1/emlDomId=100/neId=" + i);
        doFeature(sink, fdnFeature);
        sink.write("    </Features>" + _lineEnd);
        sink.write("  </Equipment>" + _lineEnd);
    }
    
    private static void
    doFeature(FileWriter  sink,
              NamedString feature) throws IOException
    {
        sink.write("      <Feature>" + _lineEnd);
        sink.write("        <Name>" + feature._name + "</Name>" + _lineEnd);
        sink.write("        <Value>" + feature._value + "</Value>" + _lineEnd);
        sink.write("        <DisplayName>" + feature._name + "</DisplayName>" + _lineEnd);
        sink.write("        <Mandatory>false</Mandatory>" + _lineEnd);
        sink.write("        <ReadOnly>true</ReadOnly>" + _lineEnd);
        sink.write("        <Discovered>true</Discovered>" + _lineEnd);
        sink.write("      </Feature>" + _lineEnd);
    }
}
