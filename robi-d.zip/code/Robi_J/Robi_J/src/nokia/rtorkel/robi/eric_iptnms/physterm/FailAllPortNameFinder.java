package nokia.rtorkel.robi.eric_iptnms.physterm;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class FailAllPortNameFinder implements PortNameFinder
{
    private static final Logger _logger = LogManager.getLogger(FailAllPortNameFinder.class);
    
    @Override
    public String
    findPortName(String neName,
                 String portType,
                 int    shelf,
                 int    card,
                 int    port)
    {
        _logger.debug("Simulating non-existence of " + neName + "/" + shelf + "/" + card + "/" + port);
        return null;
    }
}
