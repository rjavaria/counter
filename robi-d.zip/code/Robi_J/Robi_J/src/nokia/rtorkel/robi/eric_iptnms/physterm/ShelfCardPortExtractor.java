package nokia.rtorkel.robi.eric_iptnms.physterm;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import rasmus_torkel.config.PropertiesView;

public class ShelfCardPortExtractor
{
    private static final Logger _logger = LogManager.getLogger(ShelfCardPortExtractor.class);
    
    protected final Pattern _pattern;
    
    public
    ShelfCardPortExtractor(Pattern pattern)
    {
        _pattern = pattern;
    }
    
    public String
    toString()
    {
        return getClass().getName() + " for /" + _pattern.pattern() + "/";
    }
    
    public String
    nameForInternalUse(String neName,
                       String dbTermName)
    {
        Matcher matcher = _pattern.matcher(dbTermName);
        if (!matcher.matches())
        {
            return null;
        }
        try
        {
            return nameForInternalUse(neName, dbTermName, matcher);
        }
        catch (Exception e)
        {
            _logger.warn(e.getMessage());
            return null;
        }
    }
    
    protected String
    nameForInternalUse(String  neName,
                       String  dbTermName,
                       Matcher matcher)
    {
        String shelfStr = matcher.group(1);
        String cardStr = matcher.group(2);
        String portStr = matcher.group(3);
        return InternalPortNameMaker.makeName(
                neName,
                toInt(dbTermName, shelfStr),
                toInt(dbTermName, cardStr),
                toInt(dbTermName, portStr));
    }
    
    protected int
    toInt(String  dbTermName,
          String  intStr)
    {
        int n;
        try
        {
            n = Integer.parseInt(intStr);
        }
        catch (Exception e)
        {
            String message =
                    "termination name " + dbTermName +
                    " from DB has component " + intStr + " which can't be convered to int";
            throw new RuntimeException(message);
        }
        return n;
    }
    
    public static ShelfCardPortExtractor[]
    makeExtractors(PropertiesView propView)
    {
        ArrayList<ShelfCardPortExtractor> extractorAl = new ArrayList<ShelfCardPortExtractor>();
        boolean finished = false;
        for (int index = 0; !finished; index++)
        {
            String propNameCommon = "termNamePiecesExtractor." + index + ".";
            String classPropName = propNameCommon + "class";
            String patternPropName = propNameCommon + "pattern";
            String className = propView.stringN(classPropName);
            String patternString = propView.stringN(patternPropName);
            if (className == null && patternString == null)
            {
                finished = true;
            }
            else if (className != null && patternString == null)
            {
                String message = classPropName + "=" + className + " but there is no value for " + patternPropName;
                _logger.error(message);
                throw new RuntimeException(message);
            }
            else if (patternString != null && className == null)
            {
                String message = patternPropName + "=" + patternString + " but there is no value for " + classPropName;
                _logger.error(message);
                throw new RuntimeException(message);
            }
            else
            {
                Pattern pattern;
                try
                {
                    pattern = Pattern.compile(patternString);
                }
                catch (Exception e)
                {
                    String message = patternPropName + "=" + patternString + ", this does not compile to pattern: " + e;
                    _logger.error(message, e);
                    throw new RuntimeException(message, e);
                }
                ShelfCardPortExtractor extractor = makeExtractor(classPropName, className, pattern);
                extractorAl.add(extractor);
            }
        }
        ShelfCardPortExtractor[] extractors = new ShelfCardPortExtractor[extractorAl.size()];
        extractorAl.toArray(extractors);
        if (extractors.length == 0)
        {
            String message = "No ShelfCardPortExtractor";
            _logger.error(message);
            throw new RuntimeException(message);
        }
        return extractors;
    }
    
    private static ShelfCardPortExtractor
    makeExtractor(String  classPropName,
                  String  className,
                  Pattern pattern)
    {
        Class<?> extractorClass;
        try
        {
            extractorClass = Class.forName(className);
        }
        catch (Exception e)
        {
            String message = classPropName + "=" + className + ", but Class.forName fails: " + e;
            _logger.error(message, e);
            throw new RuntimeException(message, e);
        }
        Constructor<?> constructor;
        try
        {
            constructor = extractorClass.getConstructor(Pattern.class);
        }
        catch (SecurityException e)
        {
            String message =
                    classPropName + "=" + className +
                    ", but the Pattern constructor is not accessible: " + e;
            _logger.error(message, e);
            throw new RuntimeException(message, e);
        }
        catch (NoSuchMethodException e)
        {
            String message =
                    classPropName + "=" + className +
                    ", but the Pattern constructor does not exist or is not visible: " + e;
            _logger.error(message, e);
            throw new RuntimeException(message, e);
        }
        Object extractorObj;
        try
        {
            extractorObj = constructor.newInstance(pattern);
        }
        catch (Exception e)
        {
            String message =
                    classPropName + "=" + className +
                    " which is a valid class with Pattern constructor but construction failed: " + e;
            _logger.error(message, e);
            throw new RuntimeException(message, e);
        }
        ShelfCardPortExtractor extractor;
        try
        {
            extractor = (ShelfCardPortExtractor)extractorObj;
        }
        catch (Exception e)
        {
            String message =
                    classPropName + "=" + className +
                    " which does not appear to be " + ShelfCardPortExtractor.class +
                    " because class cast failed : " + e;
            _logger.error(message, e);
            throw new RuntimeException(message, e);
        }
        _logger.debug("Made extractor: " + extractor);
        return extractor;
    }
}
