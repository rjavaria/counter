/*---------------------------------------------------------------------
 * (C) COPYRIGHT 2015 ALCATEL-LUCENT AUSTRALIA LIMITED
 * 
 * This program contains proprietary information which is a trade secret
 * of ALCATEL AUSTRALIA LIMITED and also is protected under the applicable
 * copyright law. Recipient is to retain this program in confidence and is
 * not permitted to use or make any copy thereof other than as permitted
 * under a written agreement with ALCATEL AUSTRALIA LIMITED.
 *-------------------------------------------------------------------*/
package nokia.rtorkel.robi.db_jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;

public class Service2 extends PrimaryEntity
{
    public final long      m_customerId;
    //private Customer2      m_customer;

    protected
    Service2(long       id,
             String     name,
             String     type,
             String     discoveredName,
             long       customerId,
             Customer2  customer,
             DbHandle db)
    {
        super(EntityType.Service, id, name, type, discoveredName, db);
        m_customerId = customerId;
        //m_customer = customer;
    }
    /*
    public Customer2
    customer() throws SQLException, DbException
    {
        if (m_customer != null)
        {
            return m_customer;
        }
        else if (m_customerId == 0)
        {
            return null;
        }
        else
        {
            throw new RuntimeException("Not implemented");
            //m_customer = m_db.customerById(m_customerId);
            //return m_customer;
        }
    }*/
    
    public static final class ServiceTable extends PrimaryEntityTable
    {
        public final EntityColumn m_customerIdColumn;

        public
        ServiceTable()
        {
            super("services", "service_id", "service_name", "service_type", "discovered_name");
            m_customerIdColumn = new EntityColumn(m_tableName, "customer_id");
        }
        
        protected void
        doExtraColumns(StringBuilder buf,
                       String        tableLabel)
        {
            columnToSelectClause(buf, m_customerIdColumn, tableLabel);
        }
    }
    
    public static final ServiceTable ENTITY_TABLE = new ServiceTable();
    
    public static final FeatureTable FEATURE_TABLE =
            new FeatureTable("service_features", ENTITY_TABLE);
    
    public static Service2
    fromResultSet(DbHandleImpl db,
                  ResultSet      rs,
                  Customer2      customer) throws SQLException, DbException
    {
        long id = rs.getLong(1);
        String name = rs.getString(2);
        String type = rs.getString(3);
        String discoveredName = rs.getString(4);
        long customerId = rs.getLong(5);
        return new Service2(
                id, name, type, discoveredName,
                customerId, customer,
                db);
    }
    
    @Override
    public String
    toString()
    {
        return super.toString()
             + "|" + m_customerId;
    }
    
    protected void
    formatExtraFields(ObjectFormatter formatter)
    {
        formatter.appendField("customerId", m_customerId);
    }

    @Override
    public PrimaryEntityTable
    entityTable()
    {
        return ENTITY_TABLE;
    }

    @Override
    public FeatureTable
    featureTable()
    {
        return FEATURE_TABLE;
    }

    @Override
    public Feature2[]
    lookUpFeatures() throws SQLException
    {
        return m_db.serviceFeatures(this);
    }
}
