package nokia.rtorkel.robi.eric_iptnms;

import java.io.File;

import nokia.rtorkel.robi.eric_iptnms.physterm.DummyPortNameFinder;

public class EricssonIptnmsXmlEntitiesMaker
{
    public static void
    main(String[] args)
    {
        if (args.length != 2)
        {
            throw new RuntimeException("Need exactly two args, inputFileDir and entitiesDir");
        }
        InputFileDirectory inputFileDir = new InputFileDirectory(new File(args[0]));
        File entitiesDir = new File(args[1]);
        EricssonIptnmsEntities entities = new EricssonIptnmsEntities(inputFileDir, DummyPortNameFinder.INSTANCE);
        entities.makeXmlEntities(entitiesDir);
    }
}
