package nokia.rtorkel.robi.eric_iptnms.physterm;

import nokia.rtorkel.robi.db_jdbc.DbHandle;
import nokia.rtorkel.robi.db_jdbc.Termination2;

public class JdbcTermNamesOnNeFinder extends TermNamesOnNeFinder
{
    private final DbHandle _db;
    
    public
    JdbcTermNamesOnNeFinder(DbHandle db)
    {
        _db = db;
    }

    @Override
    public String[]
    termNames(String neName) throws Exception
    {
        Termination2[] terms = _db.terminationsByNamePattern(neName + "%");
        String termNames[] = new String[terms.length];
        for (int i = 0; i < terms.length; i++)
        {
            termNames[i] = terms[i].m_name;
        }
        return termNames;
    }
}
