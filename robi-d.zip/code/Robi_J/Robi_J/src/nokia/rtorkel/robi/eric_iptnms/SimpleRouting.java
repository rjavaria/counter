package nokia.rtorkel.robi.eric_iptnms;

import rasmus_torkel.text.write.IndentingLineSink;
import rasmus_torkel.xml_basic.read.TagNode;

public class SimpleRouting extends Routing
{
    private final Route _route;

    public SimpleRouting(TagNode                node,
                         EricssonIptnmsEntities entities) throws EntityNotCreatedException
    {
        super(node, entities);
        _route = route(node, "SimpleRouting.theRoute", entities);
        entities.putRouting(this);
        _supportedPath.putRouting(this);
    }
    
    public void
    toIndentingLineSink(IndentingLineSink sink)
    {
        _route.toIndentingLineSink(sink, "Simple Routing");
    }
    
    @Override
    public boolean
    findDepth()
    {
        if (_depth != -1)
        {
            return true;
        }
        if (!_route.findDepth())
        {
            return false;
        }
        _depth = _route.depth();
        return true;
    }
    
    @Override
    public AccessPoint
    firstAccessPoint()
    {
        return _route.firstAccessPoint();
    }
    
    @Override
    public AccessPoint
    lastAccessPoint()
    {
        return _route.lastAccessPoint();
    }
}
