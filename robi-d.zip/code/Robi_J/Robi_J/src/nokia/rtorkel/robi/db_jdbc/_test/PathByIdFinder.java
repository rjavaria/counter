package nokia.rtorkel.robi.db_jdbc._test;

import nokia.rtorkel.robi.db_jdbc.DbHandle;
import nokia.rtorkel.robi.db_jdbc.DbHandleImpl;
import nokia.rtorkel.robi.db_jdbc.ObjectFormatter;
import nokia.rtorkel.robi.db_jdbc.Path2;
import nokia.rtorkel.robi.db_jdbc.Termination2;

public class PathByIdFinder extends DbUnitTest
{
    public static void
    main(String[] args)
    {
        try
        {
            DbHandleImpl db = makeDbHandle(args, "pathId");
            testRead(db, args[3]);
        }
        catch (Exception e)
        {
            e.printStackTrace(System.out);
        }
    }
    
    public static void
    testRead(DbHandle db,
             String   idS) throws Exception
    {
        long id = Long.parseLong(idS);
        Path2 path = db.pathById(id);
        String pathDump = ObjectFormatter.toString("path", path);
        System.out.println(pathDump);
        Termination2[] terms = path.terminations();
        if (terms.length == 0)
        {
            System.out.println(pathDump);
            System.out.println("no terminations");
        }
        else
        {
            String termDump = ObjectFormatter.toString("First termination", terms[0]);
            System.out.println(pathDump);
            System.out.println(termDump);
        }
    }
}
