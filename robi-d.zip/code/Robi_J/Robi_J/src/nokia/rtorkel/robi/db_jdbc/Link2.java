/*---------------------------------------------------------------------
 * (C) COPYRIGHT 2014 ALCATEL AUSTRALIA LIMITED
 * 
 * This program contains proprietary information which is a trade secret
 * of ALCATEL AUSTRALIA LIMITED and also is protected under the applicable
 * copyright law. Recipient is to retain this program in confidence and is
 * not permitted to use or make any copy thereof other than as permitted
 * under a written agreement with ALCATEL AUSTRALIA LIMITED.
 *-------------------------------------------------------------------*/
package nokia.rtorkel.robi.db_jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Each instance corresponds to a row in the links table and associated information.
 * @author rtorkel
 *
 */
public class Link2 extends PrimaryEntity
{
    public final long m_termAId;
    public final long m_termZId;
    
    private Termination2 m_termA;
    private Termination2 m_termZ;
    
    /**
     * 
     * @param entityType
     * @param id
     * @param name
     * @param type
     * @param termAId
     * @param termZId
     * @param termA   May be null if not handy.
     * @param termZ   May be null if not handy
     * @param db
     */
    public
    Link2(long         id,
          String       name,
          String       type,
          String       discoveredName,
          long         termAId,
          long         termZId,
          Termination2 termA,
          Termination2 termZ,
          DbHandle   db)
    {
        super(EntityType.Link, id, name, type, discoveredName, db);
        m_termAId = termAId;
        m_termZId = termZId;
        m_termA = termA;
        m_termZ = termZ;
    }
    
    public static final class LinkTable extends PrimaryEntityTable
    {
        public final EntityColumn m_termAIdColumn;
        public final EntityColumn m_termZIdColumn;

        public
        LinkTable()
        {
            super("links", "link_id", "link_name", "link_type_id", "discovered_name");
            m_termAIdColumn = new EntityColumn(m_tableName, "a_termination_id");
            m_termZIdColumn = new EntityColumn(m_tableName, "z_termination_id");
        }
        
        protected void
        doExtraColumns(StringBuilder buf,
                       String        tableLabel)
        {
            columnToSelectClause(buf, m_termAIdColumn, tableLabel);
            columnToSelectClause(buf, m_termZIdColumn, tableLabel);
        }
    }
    
    public static final LinkTable ENTITY_TABLE = new LinkTable();
    
    public static final FeatureTable FEATURE_TABLE =
            new FeatureTable("link_features", ENTITY_TABLE);
    
    public static Link2
    fromResultSet(DbHandleImpl db,
                  ResultSet      rs,
                  Termination2   termA,
                  Termination2   termZ) throws SQLException, DbException
    {

        long id = rs.getLong(1);
        String name = rs.getString(2);
        long typeId = rs.getLong(3);
        String discoveredName = rs.getString(4);
        long termAId = rs.getLong(5);
        long termZId = rs.getLong(6);
        String type = db.m_linkTypeMap.getString(typeId);
        if (type == null)
        {
            throw new DbException(
                "Link type id " + typeId +
                " for link " + name + " does not map to type");
        }
        return new Link2(id, name, type, discoveredName, termAId, termZId, termA, termZ, db);
    }
    
    @Override
    public String
    toString()
    {
        return super.toString() + "|" + m_termAId + "|" + m_termZId;
    }
    
    protected void
    formatExtraFields(ObjectFormatter formatter)
    {
        formatter.appendField("termAId", m_termAId);
        formatter.appendField("termZId", m_termZId);
    }
    
    public void
    formatWithTerminations(ObjectFormatter formatter,
                        String          title)
    {
        formatter.appendTitle(title);
        formatter.incrementLevel();
        formatCore(formatter);
        try
        {
            terminationA().formatWithEquipment(formatter, "Termination A");
            terminationZ().formatWithEquipment(formatter, "Termination Z");
        }
        catch (Exception e)
        {
            formatter.appendField("termination retrieval exception", e.toString());
        }
        formatter.decrementLevel();
    }
    
    public String
    formatWithTerminations(String title)
    {
        ObjectFormatter formatter = new ObjectFormatter();
        formatWithTerminations(formatter, title);
        return formatter.toString();
    }

    @Override
    public Feature2[]
    lookUpFeatures() throws SQLException
    {
        return m_db.linkFeatures(this);
    }

    @Override
    public PrimaryEntityTable
    entityTable()
    {
        return ENTITY_TABLE;
    }

    @Override
    public FeatureTable
    featureTable()
    {
        return FEATURE_TABLE;
    }

    public Termination2
    terminationA() throws SQLException, DbException
    {
        if (m_termA == null)
        {
            m_termA = m_db.terminationById(m_termAId);
        }
        return m_termA;
    }

    public Termination2
    terminationZ() throws SQLException, DbException
    {
        if (m_termZ == null)
        {
            m_termZ = m_db.terminationById(m_termZId);
        }
        return m_termZ;
    }
    
    public Capacity2[]
    capacities() throws SQLException, DbException
    {
        return m_db.capacitiesByLink(this);
    }
}
