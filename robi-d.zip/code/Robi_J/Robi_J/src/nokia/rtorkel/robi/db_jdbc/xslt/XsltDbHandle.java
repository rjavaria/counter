package nokia.rtorkel.robi.db_jdbc.xslt;

import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.sql.Connection;
import java.sql.SQLException;

import nokia.rtorkel.robi.db_jdbc.DbHandleImpl;
import nokia.rtorkel.robi.db_jdbc.JdbcManager2;
import nokia.rtorkel.robi.db_jdbc.SilentDbContext;
import nokia.rtorkel.robi.db_jdbc.Termination2;
import nokia.rtorkel.robi.db_jdbc.TransactionMode;
import nokia.rtorkel.robi.db_jdbc.sure.SureDbConfigurer;
import rasmus_torkel.config.ConfigFileReader;
import rasmus_torkel.config.PropertiesView;

public class XsltDbHandle
{
    private static final DbHandleImpl _db = makeDb();
    
    private static DbHandleImpl
    makeDb()
    {
        String resourceName = "MDLSureConfig.properties";
        ClassLoader loader = SureDbConfigurer.class.getClassLoader();
        URL resourceUrl = loader.getResource(resourceName);
        URI resourceUri;
        try
        {
            resourceUri = resourceUrl.toURI();
        }
        catch (URISyntaxException e)
        {
            String message = "Failed to convert URL " + resourceUrl + " to URI: " + e;
            throw new RuntimeException(message, e);
        }
        File file = new File(resourceUri);
        PropertiesView config = ConfigFileReader.propertiesViewFromFile(file);
        String paramPrefix = SureDbConfigurer.XDM_DB_PARAM_NAME_PREFIX;
        String url = config.stringE(paramPrefix + "url.SM");
        String userName = config.stringE(paramPrefix + "userName.SM");
        String password = config.stringE(paramPrefix + "password.SM");
        String driver = config.stringE("hibernate.connection.driver.class");
        JdbcManager2 jm;
        try
        {
            jm = new JdbcManager2(url, userName, password, driver);
        }
        catch (ClassNotFoundException e)
        {
            throw new RuntimeException("Could not make JDBC Manager", e);
        }
        Connection connection;
        try
        {
            connection = jm.getConnection();
        }
        catch (SQLException e)
        {
            throw new RuntimeException("JDBC Manager could not make connection to DB", e);
        }
        SilentDbContext context = new SilentDbContext();
        DbHandleImpl db;
        try
        {
            db = new DbHandleImpl(connection, context, TransactionMode.READ_ONLY);
        }
        catch (SQLException e)
        {
            throw new RuntimeException("Could not make DB handle from connection", e);
        }
        return db;
    }
    
    public static String
    termNameByLike_1orE(String likeExpression)
    {
        Termination2[] terms = termsByLike(likeExpression);
        if (terms.length != 1)
        {
            throw new RuntimeException(
                    "terminationsByNamePattern(" + likeExpression +
                    ") lead to " + terms.length + " terminations, we want exactly 1");
        }
        return terms[0].m_name;
    }
    
    public static String
    termNameByLike_1stOrD(String likeExpression,
                          String defaultTermName)
    {
        Termination2[] terms = termsByLike(likeExpression);
        if (terms.length > 0)
        {
            return terms[0].m_name;
        }
        else
        {
            return defaultTermName;
        }
    }
    
    private static Termination2[]
    termsByLike(String likeExpression)
    {
        try
        {
            return _db.terminationsByNamePattern(likeExpression);
        }
        catch (Exception e)
        {
            throw new RuntimeException("terminationsByNamePattern(" + likeExpression + ") failed: ", e);
        }
    }
    
    /**
     * Quick test
     * @param args First argument is termination like expression
     */
    public static void
    main(String[] args)
    {
        if (args.length < 1)
        {
            throw new RuntimeException("No argument, need terminationName like expression");
        }
        String termNameLikeExpression = args[0];
        String termName = termNameByLike_1orE(termNameLikeExpression);
        System.out.println("termination " + termName + " has name like " + termNameLikeExpression);
        termName = termNameByLike_1stOrD(termNameLikeExpression, "dummyTermName");
        System.out.println("termination " + termName + " has name like " + termNameLikeExpression);
    }
}
