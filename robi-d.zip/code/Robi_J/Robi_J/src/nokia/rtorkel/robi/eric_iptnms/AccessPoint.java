package nokia.rtorkel.robi.eric_iptnms;

import java.io.File;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import rasmus_torkel.text.write.IndentingLineSink;
import rasmus_torkel.xml_basic.read.TagNode;
import rasmus_torkel.xml_basic.read.XmlReadOptions;
import rasmus_torkel.xml_basic.read.impl.XmlReader;

public abstract class AccessPoint implements RouteComponent, ReportingEntity
{
    private static final Logger _logger = LogManager.getLogger(AccessPoint.class);
    
    public final String     _id;
    protected      String   _name;
    public final String     _type;
    public final Subnetwork _subnet;
    public final int        _shelf;
    public final int        _card;
    public final int        _port;
    public final String     _channelName;
    public final int        _tp;
    public final int        _layer;
    public final PhLayerTtp _plt;
    
    protected boolean _isValid = true; // until proven otherwise
    
    private CrossConnection _cc;
    
    @Override
    public String
    toString()
    {
        return _id + " " + _name + " " + _tp + " " + _type +
               " " + pltRelationStatus() + " L" + _layer +
               " channel " + _channelName;
    }
    
    public String
    toSlightlyShorterString()
    {
        return _id + " " + _name + " " + _tp + " " + _type + " L" + _layer;
    }
    
    public String
    toStructureString()
    {
        return _id + " " + _name + " " + _tp + " " + _type + " " + _subnet._parent._nestedName +
               " " + (_cc != null ? _cc._id : "-") + ", channel " + _channelName;
    }
    
    public
    AccessPoint(TagNode                node,
                EricssonIptnmsEntities entities,
                String                 type)
    {
        _type = type;
        _id = node.attributeValueE("Id");
        PhLayerTtp plt = null;
        Subnetwork subnet = null;
        int tp = -1;
        int shelf = -1;
        int card = -1;
        int port = -1;
        String channelName = null;
        int layer = -1;
        try
        {
            String pltId = EricssonXmlUtil.nextIdFieldN(node, "AccessPoint.phLayerTTP", "PhLayerTtp");
            if (pltId != null)
            {
                plt = entities.lookUpPlt(pltId);
                if (plt == null)
                {
                    throw new EntityNotCreatedException(_id, "AccessPoint", pltId, "PhLayerTtp", entities);
                }
            }
            else
            {
                plt = null;
            }
            node.nextChildN("AccessPoint.phLayerTTP");
            String subnetId = node.nextChildE("AccessPoint.subNetwork").attributeValueE("SubNetwork");
            subnet = entities.lookUpSubnet(subnetId);
            if (subnet == null)
            {
                throw new EntityNotCreatedException(_id, "AccessPoint", subnetId, "subnetwork", entities);
            }
            if (subnet._neName == null)
            {
                throw new EntityNotCreatedException(
                        _id, "AccessPoint",
                        "refers to subnetwork " + subnetId +
                        " which is not associated with any NetworkElement",
                        entities);
            }
            if (plt != null && plt._subnet != subnet)
            {
                throw new EntityNotCreatedException(
                        _id, "AccessPoint",
                        "refers to PhLayerTtp " + plt._id +
                        " on different subnetwork " + plt._subnet._id,
                        entities);
            }
            int slot = EricssonXmlUtil.nextIntFieldD(node, "AccessPoint.physicalSlotId", -1);
            tp = EricssonXmlUtil.nextIntFieldE(node, "AccessPoint.tPId");
            node.nextChildE("AccessPoint.subNetworkId");
            channelName = EricssonXmlUtil.nextTextFieldE(node, "AccessPoint.channelName");
            node.nextChildE("AccessPoint.logicalPortLabel");
            node.nextChildE("AccessPoint.freeBusyTx");
            node.nextChildE("AccessPoint.freeBusyRx");
            shelf = EricssonXmlUtil.nextIntFieldE(node, "AccessPoint.shelfIdOnNM");
            card = EricssonXmlUtil.nextIntFieldE(node, "AccessPoint.cardId");
            if (slot != -1 && slot != card)
            {
                throw new EntityNotCreatedException(
                        _id, "AccessPoint",
                        "has physicalSlotId " + slot + " different from cardId " + card,
                        entities);
            }
            port = EricssonXmlUtil.nextIntFieldE(node, "AccessPoint.portId");
            layer = EricssonXmlUtil.nextIntFieldE(node, "AccessPoint.layerSnId");
            if (plt != null)
            {
                if (plt._subnet._ne != subnet._ne)
                {
                    throw new EntityNotCreatedException(
                            _id, "AccessPoint",
                            "has PhLayerTtp " + _id + " on different NE " + plt._subnet._neName,
                            entities);
                }
            }
            _name = subnet._neName + "/" + _type + "/TP " + tp;
            entities.putAp(this);
        }
        catch (EntityNotCreatedException e)
        {
            // We don't want to throw exceptions because we need to register the failure so we still
            // need to prevent NullPointerExceptions.
            _isValid = false;
            if (_name == null)
            {
                String neName = subnet != null && subnet._neName != null ? subnet._neName : "unknownNe";
                _name = neName + "/" + _type + "/TP " + tp;
            }
        }
        _plt = plt;
        _subnet = subnet;
        _tp = tp;
        _shelf = shelf;
        _card = card;
        _port = port;
        _channelName = channelName;
        _layer = layer;
    }
    
    public String
    name()
    {
        return _name;
    }
    
    public void
    registerApId(String                 id,
                 EricssonIptnmsEntities entities)
    {
        //String id = nodeContainingId.attributeValueE("Id");
        entities.putApId(id, this);
    }
    
    public void
    notifyCrossConnection(CrossConnection cc)
    {
        if (_cc == null)
        {
            _cc = cc;
        }
        else if (cc._id.equals(_cc._id))
        {
            // duplicates can happen
        }
        else
        {
            throw new RuntimeException(
                    "Access point " + _id +
                    " participates in multiple cross connections, " +
                    _cc._id + " and " + cc._id);
        }
    }
    
    @Override
    public AccessPoint
    firstAccessPoint()
    {
        return this;
    }
    
    @Override
    public AccessPoint
    lastAccessPoint()
    {
        return this;
    }
    
    public String
    pltRelationStatus()
    {
        if (_plt == null)
        {
            return "noPLT";
        }
        PhLayerTtp protectingPlt = _plt.protectingPlt();
        if (protectingPlt == null)
        {
            if (hasSamePort(_plt))
            {
                return "unprotectedPLT_samePort";
            }
            else
            {
                return "unprotectedPLT_diffPort";
            }
        }
        if (hasSamePort(_plt))
        {
            return "protectedPLT_samePort";
        }
        else if (hasSamePort(protectingPlt))
        {
            return "protectedPLT_samePortAsProtected";
        }
        else
        {
            return "protectedPLT_diffPort";
        }
    }
    
    public boolean
    hasSamePort(PhLayerTtp plt)
    {
        return    _plt._subnet == _subnet
               && _plt._shelf == _shelf
               && _plt._card == _card
               && _plt._port == _port;
    }

    @Override
    public void makeReport(IndentingLineSink sink)
    {
        sink.writeLine(toStructureString());
        if (_plt != null)
        {
            sink.incrementLevel();
            sink.writeLine(_plt.toString());
            PhLayerTtp protectingPlt = _plt.protectingPlt();
            if (protectingPlt != null)
            {
                sink.incrementLevel();
                sink.writeLine("Protecting: " + protectingPlt.toString());
                sink.decrementLevel();
            }
            sink.decrementLevel();
        }
    }
    
    public void
    toIndentingLineSink(IndentingLineSink sink)
    {
        sink.writeLine(toStructureString());
        if (_plt != null)
        {
            sink.incrementLevel();
            sink.writeLine(_plt.toString());
            PhLayerTtp protectingPlt = _plt.protectingPlt();
            if (protectingPlt != null)
            {
                sink.incrementLevel();
                sink.writeLine("Protecting: " + protectingPlt.toString());
                sink.decrementLevel();
            }
            sink.decrementLevel();
        }
    }
    
    public static void
    accessPointsToIndentingLineSink(IndentingLineSink sink,
                                    String            label,
                                    AccessPoint[]     aps)
    {
        sink.writeLine(label);
        sink.incrementLevel();
        for (AccessPoint ap : aps)
        {
            sink.writeLine(ap.toSlightlyShorterString());
        }
        sink.decrementLevel();
    }
    
    public static void
    load(InputFileDirectory     dir,
         EricssonIptnmsEntities entities)
    {
        File neFile = dir.getInputFile("AccessPoint");
        TagNode rootNode = XmlReader.xmlFileToRoot(neFile, XmlReadOptions.DEFAULT, "NetworkManager");
        rootNode.nextChildE("Version");
        boolean haveSummary = false;
        int processedQty = 0;
        do
        {
            TagNode level1Node = rootNode.nextChildE();
            if (   level1Node._id._relativeName.equals("CTPODU")
                || level1Node._id._relativeName.equals("CTPOCH")
                || level1Node._id._relativeName.equals("CTPGDC"))
            {
                new XCTP(level1Node, entities);
            }
            else if (   level1Node._id._relativeName.equals("CTPHO")
                     || level1Node._id._relativeName.equals("CTPLO"))
            {
                new XCTPSDH(level1Node, entities);
            }
            else if (   level1Node._id._relativeName.equals("TTPODU")
                     || level1Node._id._relativeName.equals("TTPOCH")
                     || level1Node._id._relativeName.equals("TTPLO")
                     || level1Node._id._relativeName.equals("TTPHO"))
            {
                new XTTP(level1Node, entities);
            }
            else if (level1Node._id._relativeName.equals("VCG"))
            {
                new VCG(level1Node, entities);
            }
            else if (level1Node._id._relativeName.equals("Summary"))
            {
                rootNode.verifyNoMoreChildren();
                haveSummary = true;
            }
            else
            {
                throw new RuntimeException("Node with unexpected name: " + level1Node);
            }
            processedQty++;
            if (   processedQty == 1
                || processedQty == 10
                || processedQty == 100
                || processedQty == 1000
                || processedQty % 10000 == 0)
            {
                _logger.info("Processed " + processedQty);
            }
        } while (!haveSummary);
        _logger.info("Processed " + processedQty + ", finished AccessPoint entities");
    }
}
