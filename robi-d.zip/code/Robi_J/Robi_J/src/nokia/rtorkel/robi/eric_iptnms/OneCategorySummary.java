package nokia.rtorkel.robi.eric_iptnms;

import rasmus_torkel.text.write.IndentingLineSink;

public class OneCategorySummary
{
    public final String _label;
    public       int    _qty;
    public       String _exampleId;
    
    public
    OneCategorySummary(String label)
    {
        _label = label;
    }
    
    public void
    record(String id)
    {
        _qty++;
        if (_qty == 1)
        {
            _exampleId = id;
        }
    }
    
    @Override
    public String
    toString()
    {
        return _label + ": " + _qty + " instance(s), example is " + _exampleId;
    }
    
    public static void
    reportSet(IndentingLineSink     lineSink,
              String                label,
              OneCategorySummary... summaries)
    {
        lineSink.writeLine(label);
        lineSink.incrementLevel();
        for (OneCategorySummary summary : summaries)
        {
            if (summary._qty != 0)
            {
                lineSink.writeLine(summary.toString());
            }
        }
        lineSink.decrementLevel();
    }
}
