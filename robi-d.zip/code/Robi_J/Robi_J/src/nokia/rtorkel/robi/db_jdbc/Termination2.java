/*---------------------------------------------------------------------
 * (C) COPYRIGHT 2014 ALCATEL AUSTRALIA LIMITED
 * 
 * This program contains proprietary information which is a trade secret
 * of ALCATEL AUSTRALIA LIMITED and also is protected under the applicable
 * copyright law. Recipient is to retain this program in confidence and is
 * not permitted to use or make any copy thereof other than as permitted
 * under a written agreement with ALCATEL AUSTRALIA LIMITED.
 *-------------------------------------------------------------------*/
package nokia.rtorkel.robi.db_jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Each instance corresponds to a row in the t_termination table and associated information.
 * 
 * @author rtorkel
 *
 */
public class Termination2 extends PrimaryEntity
{
    public final long m_equipId;
    
    private Equipment2 m_equip;

    /**
     * 
     * @param id         Corresponds to terminations.term_id
     * @param name       Corresponds to terminations.term_name
     * @param type       From termination_types
     * @param equipId    Corresponds to terminations.equipment_ne_id
     * @param equipment  If we happen to have equipment for equipId handy, we supply it here.
     *                   Otherwise null.
     * @param db         Required in lazy evaluation.
     */
    protected
    Termination2(long       id,
                 String     name,
                 String     type,
                 String     discoveredName,
                 long       equipId,
                 Equipment2 equipment,
                 DbHandle db)
    {
        super(EntityType.Termination, id, name, type, discoveredName, db);
        m_equipId = equipId;
    }
    
    public static final class TerminationTable extends PrimaryEntityTable
    {
        public final EntityColumn m_equipIdColumn;

        public
        TerminationTable()
        {
            super("terminations", "termination_id", "termination_name", "termination_type_id", "discovered_name");
            m_equipIdColumn = new EntityColumn(m_tableName, "equipment_id");
        }
        
        protected void
        doExtraColumns(StringBuilder buf,
                       String        tableLabel)
        {
            columnToSelectClause(buf, m_equipIdColumn, tableLabel);
        }
    }
    
    public static final TerminationTable ENTITY_TABLE = new TerminationTable();
    
    public static final FeatureTable FEATURE_TABLE =
            new FeatureTable("termination_features", ENTITY_TABLE);
    
    /**
     * 
     * @param db
     * @param rs
     * @param equip Put null if not readily available
     * @return
     * @throws SQLException
     * @throws IxdbException
     */
    public static Termination2
    fromResultSet(DbHandleImpl db,
                  ResultSet      rs,
                  Equipment2     equip) throws SQLException, DbException
    {

        long id = rs.getLong(1);
        String name = rs.getString(2);
        long typeId = rs.getLong(3);
        String discoveredName = rs.getString(4);
        long equipId = rs.getLong(5);
        String type = db.m_termTypeMap.getString(typeId);
        if (type == null)
        {
            throw new DbException(
                "Termination type id " + typeId +
                " for termination " + name + " does not map to type");
        }
        return new Termination2(id, name, type, discoveredName, equipId, equip, db);
    }

    @Override
    public Feature2[] lookUpFeatures() throws SQLException
    {
        return m_db.terminationFeatures(this);
    }

    public Equipment2
    equipment() throws SQLException, DbException
    {
        if (m_equip == null)
        {
            m_equip = m_db.equipmentById(m_equipId);
        }
        return m_equip;
    }
    
    /**
     * Obtains links facing towards the customer side of the network.
     * Results are not cached in this class.
     * @return
     * @throws SQLException
     * @throws IxdbException
     */
    public Link2[]
    aFacingLinks() throws SQLException, DbException
    {
        return m_db.aFacingLinks(this);
    }
    
    public Link2[]
    zFacingLinks() throws SQLException, DbException
    {
        return m_db.zFacingLinks(this);
    }
    
    public Termination2[]
    subterms() throws SQLException, DbException
    {
        return m_db.subterminations(this);
    }
    
    public PathTermination2[]
    pathTerminations() throws SQLException, DbException
    {
        return m_db.pathTerminationsByTermination(this);
    }
    
    public Path2[]
    paths() throws SQLException, DbException
    {
        return m_db.pathsByTermination(this);
    }
    
    protected void
    formatExtraFields(ObjectFormatter formatter)
    {
        formatter.appendField("equipId", m_equipId);
    }
    
    public void
    formatWithEquipment(ObjectFormatter formatter,
                        String          title)
    {
        formatter.appendTitle(title);
        formatter.incrementLevel();
        formatCore(formatter);
        try
        {
            formatter.format("equipment", equipment());
        }
        catch (Exception e)
        {
            formatter.appendField("equipment retrieval exception", e.toString());
        }
        formatter.decrementLevel();
    }
    
    public String
    formatWithEquipment(String title)
    {
        ObjectFormatter formatter = new ObjectFormatter();
        formatWithEquipment(formatter, title);
        return formatter.toString();
    }

    @Override
    public PrimaryEntityTable
    entityTable()
    {
        return ENTITY_TABLE;
    }

    @Override
    public FeatureTable
    featureTable()
    {
        return FEATURE_TABLE;
    }
    
    @Override
    public String
    toString()
    {
        return super.toString() + "|" + m_equipId;
    }
}
