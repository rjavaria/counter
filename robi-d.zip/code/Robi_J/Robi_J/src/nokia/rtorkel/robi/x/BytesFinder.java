package nokia.rtorkel.robi.x;

import java.io.File;
import java.io.FileInputStream;

public class BytesFinder
{
    private static class ByteRecord
    {
        final int  _firstOccurenceLine;
        final int  _firstOccurenceColumn;
        int        _qty;
        
        ByteRecord(int firstOccurenceLine,
                   int firstOccurenceColumn)
        {
            _firstOccurenceLine = firstOccurenceLine;
            _firstOccurenceColumn = firstOccurenceColumn;
        }
        
        @Override
        public String
        toString()
        {
            return "line " + _firstOccurenceLine + ", column " + _firstOccurenceColumn;
        }
    }
    
    public static void
    main(String[] args)
    {
        if (args.length != 1)
        {
            throw new RuntimeException("Need exactly one arg, name of file");
        }
        File file = new File(args[0]);
        try
        {
            processFile(file);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
    
    public static void
    processFile(File file) throws Exception
    {
        ByteRecord[] byteRecords = new ByteRecord[256];
        FileInputStream stream = new FileInputStream(file);
        int lineNr = 1;
        int columnNr = 1;
        int newLine = (int)'\n';
        try
        {
            System.out.println("************ In order of occurence ****************************************");
            int bint;
            do
            {
                bint = stream.read();
                if (bint < -1 || bint >= 256)
                {
                    throw new RuntimeException("Illegal byte " + bint);
                }
                else if (bint != -1)
                {
                    if (byteRecords[bint] == null)
                    {
                        byteRecords[bint] = new ByteRecord(lineNr, columnNr);
                        print(bint, byteRecords[bint], false);
                    }
                    byteRecords[bint]._qty++;
                    if (bint == newLine)
                    {
                        lineNr++;
                        columnNr = 1;
                    }
                    else
                    {
                        columnNr++;
                    }
                }
            } while (bint != -1);
        }
        finally
        {
            stream.close();
        }
        System.out.println("************ In order of byte value ***************************************");
        for (int bint = 0; bint < byteRecords.length; bint++)
        {
            if (byteRecords[bint] != null)
            {
                print(bint, byteRecords[bint], true);
            }
        }
    }
    
    private static void
    print(int        bint,
          ByteRecord byteRecord,
          boolean    wantQuantity)
    {
        int digit1 = bint / 16;
        int digit2 = bint % 16;
        System.out.println(Integer.toHexString(digit1).toUpperCase() +
                           Integer.toHexString(digit2).toUpperCase() +
                           ": " + byteRecord +
                           (wantQuantity ? ", quantity " + byteRecord._qty : ""));
    }
}
