/*---------------------------------------------------------------------
 * (C) COPYRIGHT 2015 ALCATEL-LUCENT AUSTRALIA LIMITED
 * 
 * This program contains proprietary information which is a trade secret
 * of ALCATEL-LUCENT AUSTRALIA LIMITED and also is protected under the applicable
 * copyright law. Recipient is to retain this program in confidence and is
 * not permitted to use or make any copy thereof other than as permitted
 * under a written agreement with ALCATEL-LUCENT AUSTRALIA LIMITED.
 *-------------------------------------------------------------------*/
package nokia.rtorkel.robi.db_jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;

public class Network2 extends PrimaryEntity
{
    public final String m_layer;
    
    public
    Network2(long       id,
                String     networkName,
                String     domainType,
                String     discoveredName,
                String     layer,
                DbHandleImpl db) // Fix type eventually
    {
        super(EntityType.Subnetwork, id, networkName, domainType, discoveredName, db);
        m_layer = layer;
    }
    
    public static final class SubnetworkTable extends PrimaryEntityTable
    {
        public final EntityColumn m_layerColumn;

        public
        SubnetworkTable()
        {
            super("networks", "network_id", "network_name", "domain_type", "discovered_name");
            m_layerColumn = new EntityColumn(m_tableName, "layer");
        }
        
        protected void
        doExtraColumns(StringBuilder buf,
                       String        tableLabel)
        {
            columnToSelectClause(buf, m_layerColumn, tableLabel);
        }
    }
    
    public static final SubnetworkTable ENTITY_TABLE = new SubnetworkTable();
    
    public static final FeatureTable FEATURE_TABLE =
            new FeatureTable("network_features", ENTITY_TABLE);

    @Override
    public PrimaryEntity.PrimaryEntityTable
    entityTable()
    {
        return ENTITY_TABLE;
    }

    @Override
    public FeatureTable
    featureTable()
    {
        return FEATURE_TABLE;
    }
    
    public static Network2
    fromResultSet(DbHandleImpl db,
                  ResultSet      rs) throws SQLException, DbException
    {

        long id = rs.getLong(1);
        String name = rs.getString(2);
        String type = rs.getString(3);
        String discoveredName = rs.getString(4);
        String layer = rs.getString(5);
        return new Network2(id, name, type, discoveredName, layer, db);
    }

    @Override
    public Feature2[]
    lookUpFeatures() throws SQLException
    {
        return m_db.networkFeatures(this);
    }
    
    protected void
    formatExtraFields(ObjectFormatter formatter)
    {
        formatter.appendField("layer", m_layer);
    }
    
    public String
    toString()
    {
        return m_id + "|" + m_name + "|" + m_type + "|" + m_layer;
    }
}
