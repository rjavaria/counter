package nokia.rtorkel.robi.db_jdbc._test;

import java.util.Arrays;

import nokia.rtorkel.robi.db_jdbc.DbHandle;
import nokia.rtorkel.robi.db_jdbc.ObjectFormatter;
import nokia.rtorkel.robi.db_jdbc.Termination2;

public class TermsByNamePatternFinder extends DbUnitTest
{
    public static void
    main(String[] args)
    {
        try
        {
            DbHandle db = makeDbHandle(args, "namePattern");
            testRead(db, args[3]);
        }
        catch (Exception e)
        {
            e.printStackTrace(System.out);
        }
    }
    
    public static void
    testRead(DbHandle db,
             String     namePattern) throws Exception
    {
        Termination2[] terms = db.terminationsByNamePattern(namePattern);
        Arrays.sort(terms);
        if (terms.length >= 1)
        {
            System.out.println(ObjectFormatter.toString("First termination", terms[0]));
        }
    }
}
