package nokia.rtorkel.robi.eric_iptnms;

import rasmus_torkel.text.write.IndentingLineSink;

public interface RouteComponent
{
    public void
    toIndentingLineSink(IndentingLineSink sink);
    
    public AccessPoint
    firstAccessPoint();
    
    public AccessPoint
    lastAccessPoint();
}
