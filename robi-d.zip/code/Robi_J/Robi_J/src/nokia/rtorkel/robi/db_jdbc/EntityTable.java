/*---------------------------------------------------------------------
 * (C) COPYRIGHT 2014 ALCATEL AUSTRALIA LIMITED
 * 
 * This program contains proprietary information which is a trade secret
 * of ALCATEL AUSTRALIA LIMITED and also is protected under the applicable
 * copyright law. Recipient is to retain this program in confidence and is
 * not permitted to use or make any copy thereof other than as permitted
 * under a written agreement with ALCATEL AUSTRALIA LIMITED.
 *-------------------------------------------------------------------*/
package nokia.rtorkel.robi.db_jdbc;

/**
 * Represents any sort of table in the database.
 * 
 * @author rtorkel
 *
 */
public abstract class EntityTable implements DbConstants
{
    public final String m_tableName;
    
    protected
    EntityTable(String tableName)
    {
        m_tableName = tableName;
    }
    
    /**
     * Returns a line termination select clause where the columns to be retrieved are
     * in the notation table.column.
     * @return
     */
    public abstract String
    makeSimpleSelectClause();
    
    public String
    makeColumnQuery(EntityColumn column)
    {
        return  makeSimpleSelectClause() +
                "    from " + m_tableName + LINE_END +
                "    where " + column.m_tabColPhrase + " = ?";
    }
    
    public String
    make2ColumnsQuery(EntityColumn column1,
                      EntityColumn column2)
    {
        return  makeSimpleSelectClause() +
                "    from " + m_tableName + LINE_END +
                "    where     " + column1.m_tabColPhrase + " = ?" + LINE_END +
                "          and " + column2.m_tabColPhrase + " = ?";
    }
    
    public String
    makeColumnLikeQuery(EntityColumn column)
    {
        return  makeSimpleSelectClause() +
                "    from " + m_tableName + LINE_END +
                "    where " + column.m_tabColPhrase + " like ?";
    }
    
    public String
    makeAllQuery()
    {
        return  makeSimpleSelectClause() +
                "    from " + m_tableName;
    }
}
