package nokia.rtorkel.robi.eric_iptnms.physterm;

public class InternalPortNameMaker
{
    public static String
    makeName(String neName,
             int    shelf,
             int    card,
             int    port)
    {
        return neName + "/" + shelf + "/" + card + "/" + port;
    }
}
