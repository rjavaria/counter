package nokia.rtorkel.robi.eric_iptnms;

import rasmus_torkel.xml_basic.read.TagNode;

public class XCTPSDH extends CTPSDH
{
    public
    XCTPSDH(TagNode                node,
            EricssonIptnmsEntities entities)
    {
        super(node.nextChildE("CTPSDH"), entities, node._id._relativeName);
        String id = node.attributeValueE("Id");
        if (_isValid)
        {
            registerApId(id, entities);
        }
        else
        {
            entities.putEliminatedEntityByDifferentId(id, node._id._relativeName, _id);
        }
    }
}
