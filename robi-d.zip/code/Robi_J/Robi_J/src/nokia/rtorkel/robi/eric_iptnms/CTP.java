package nokia.rtorkel.robi.eric_iptnms;

import rasmus_torkel.xml_basic.read.TagNode;

public abstract class CTP extends AccessPoint
{
    public CTP(TagNode                node,
               EricssonIptnmsEntities entities,
               String                 type)
    {
        super(node.nextChildE("AccessPoint"), entities, type);
        node.verifyNoMoreChildren();
        String id = node.attributeValueE("Id");
        if (_isValid)
        {
            registerApId(id, entities);
        }
        else
        {
            entities.putEliminatedEntityByDifferentId(id, "CTP", _id);
        }
    }
}
