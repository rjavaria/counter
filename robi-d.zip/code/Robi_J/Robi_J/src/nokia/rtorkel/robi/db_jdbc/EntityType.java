/*---------------------------------------------------------------------
 * (C) COPYRIGHT 2014 ALCATEL AUSTRALIA LIMITED
 * 
 * This program contains proprietary information which is a trade secret
 * of ALCATEL AUSTRALIA LIMITED and also is protected under the applicable
 * copyright law. Recipient is to retain this program in confidence and is
 * not permitted to use or make any copy thereof other than as permitted
 * under a written agreement with ALCATEL AUSTRALIA LIMITED.
 *-------------------------------------------------------------------*/
package nokia.rtorkel.robi.db_jdbc;

/**
 * This represents the types of primary entity. Those are the ones that have id, name, type and
 * usually features.
 * 
 * @author rtorkel
 *
 */
public enum EntityType
{
    Subnetwork(true),
    Equipment(true),
    Termination(true),
    Link(true),
    Path(false),
    Service(true),
    Customer(true),
    Capacity(true);
    
    public final boolean m_isNameUnique;
    public final String m_lCase = this.toString().toLowerCase();
    public final String m_uCase = this.toString().toUpperCase();
    
    private
    EntityType(boolean isNameUnique)
    {
        m_isNameUnique = isNameUnique;
    }
}
