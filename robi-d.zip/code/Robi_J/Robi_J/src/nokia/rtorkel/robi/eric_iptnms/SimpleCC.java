package nokia.rtorkel.robi.eric_iptnms;

import rasmus_torkel.text.write.IndentingLineSink;
import rasmus_torkel.xml_basic.read.TagNode;

public class SimpleCC extends CrossConnection
{
    public final AccessPoint _from;
    public final AccessPoint _to;
    
    @Override
    public String
    toString()
    {
        return super.toString() +
               " from(" + _from.name() + ") to(" + _to.name() + ")"; 
    }
    
    public
    SimpleCC(TagNode                node,
             EricssonIptnmsEntities entities) throws EntityNotCreatedException
    {
        super(node);
        String fromId = node.nextChildE("SimpleCC.fromTP").attributeValueE("AccessPoint");
        String toId = node.nextChildE("SimpleCC.toTP").attributeValueE("AccessPoint");
        _from = lookUpAp(fromId, entities);
        _to = lookUpAp(toId, entities);
        node.nextChildE("SimpleCC.ccStatus");
        node.nextChildE("SimpleCC.cycleLifeState");
        node.nextChildE("SimpleCC.degenerate");
        node.verifyNoMoreChildren();
        entities.putCC(this);
        _from.notifyCrossConnection(this);
        _to.notifyCrossConnection(this);
    }
    
    public void
    toIndentingLineSink(IndentingLineSink sink)
    {
        sink.writeLine(toSlightlyShorterString());
        sink.incrementLevel();
        sink.writeLine("from: " + _from.toStructureString());
        sink.writeLine("to:   " + _to.toStructureString());
        sink.decrementLevel();
    }
}
