package nokia.rtorkel.robi.db_jdbc._test;

import nokia.rtorkel.robi.db_jdbc.DbHandle;
import nokia.rtorkel.robi.db_jdbc.DbHandleImpl;
import nokia.rtorkel.robi.db_jdbc.Equipment2;
import nokia.rtorkel.robi.db_jdbc.Network2;
import nokia.rtorkel.robi.db_jdbc.ObjectFormatter;

public class EquipByNameFinder extends DbUnitTest
{
    public static void
    main(String[] args)
    {
        try
        {
            DbHandleImpl db = makeDbHandle(args, "equipmentName");
            testRead(db, args[3]);
        }
        catch (Exception e)
        {
            e.printStackTrace(System.out);
        }
    }
    
    public static void
    testRead(DbHandle db,
             String   name) throws Exception
    {
        Equipment2 equip = db.equipmentByName(name);
        System.out.println(ObjectFormatter.toString("equipment", equip));
        Network2[] networks = db.networksByEquipment(equip);
        if (networks.length == 0)
        {
            System.out.println(ObjectFormatter.toString("equipment", equip));
            System.out.println("No networks for " + equip);
        }
        else
        {
            String networkDump = ObjectFormatter.toString("first network for " + equip, networks[0]);
            System.out.println(ObjectFormatter.toString("equipment", equip));
            System.out.println(networkDump);
        }
    }
}
