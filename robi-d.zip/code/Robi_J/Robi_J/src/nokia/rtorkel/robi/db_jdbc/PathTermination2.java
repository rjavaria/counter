/*---------------------------------------------------------------------
 * (C) COPYRIGHT 2014 ALCATEL AUSTRALIA LIMITED
 * 
 * This program contains proprietary information which is a trade secret
 * of ALCATEL AUSTRALIA LIMITED and also is protected under the applicable
 * copyright law. Recipient is to retain this program in confidence and is
 * not permitted to use or make any copy thereof other than as permitted
 * under a written agreement with ALCATEL AUSTRALIA LIMITED.
 *-------------------------------------------------------------------*/
package nokia.rtorkel.robi.db_jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Represents one row from the t_path_termination table.
 * 
 * @author rtorkel
 *
 */
public class PathTermination2 implements ObjectFormatter.Formattable
{
    public final long m_pathId;
    public final long m_termId;
    
    private final DbHandle m_db;
    
    private Path2        m_path;
    private Termination2 m_term;
    
    /**
     * 
     * @param pathId
     * @param termId
     * @param path       may be null if not handy
     * @param term       may be null if not handy
     * @param db
     */
    public
    PathTermination2(long         pathId,
                    long         termId,
                    Path2        path,
                    Termination2 term,
                    DbHandle   db)
    {
        m_pathId = pathId;
        m_termId = termId;
        m_path = path;
        m_term = term;
        m_db = db;
    }

    public Termination2
    termination() throws SQLException, DbException
    {
        if (m_term == null)
        {
            m_term = m_db.terminationById(m_termId);
        }
        return m_term;
    }

    public Path2
    path() throws SQLException, DbException
    {
        if (m_path == null)
        {
            m_path = m_db.pathById(m_pathId);
        }
        return m_path;
    }
    
    public static final class PathTerminationTable extends EntityTable
    {
        public final EntityColumn m_pathIdColumn;
        public final EntityColumn m_termIdColumn;

        public
        PathTerminationTable()
        {
            super("path_terminations");
            m_pathIdColumn = new EntityColumn(m_tableName, "path_id");
            m_termIdColumn = new EntityColumn(m_tableName, "termination_id");
        }
        
        public String
        makeSimpleSelectClause()
        {
           return  "select " + m_pathIdColumn.m_tabColPhrase +
                   ", " + m_termIdColumn.m_tabColPhrase +
                   LINE_END;
        }
    }
    
    public static final PathTerminationTable ENTITY_TABLE = new PathTerminationTable();
    
    public static PathTermination2
    fromResultSet(DbHandleImpl db,
                  ResultSet      rs,
                  Path2          path,
                  Termination2   term) throws SQLException, DbException
    {
        long pathId = rs.getLong(1);
        long termId = rs.getLong(2);
        return new PathTermination2(pathId, termId, path, term, db);
    }
    
    @Override
    public String
    toString()
    {
        return "pathTermination|" + m_pathId + "|" + m_termId;
    }

    @Override
    public void
    format(ObjectFormatter formatter,
           String          title)
    {
        formatter.appendTitle(title);
        formatter.incrementLevel();
        formatter.appendField("pathId", m_pathId);
        formatter.appendField("termId", m_termId);
        formatter.decrementLevel();
    }
    
    public void
    formatWithEntities(ObjectFormatter formatter,
                       String          title)
    {
        formatter.appendTitle(title);
        formatter.incrementLevel();
        formatter.appendField("pathId", m_pathId);
        formatter.appendField("termId", m_termId);
        try
        {
            formatter.format("path", path());
        }
        catch (Exception e)
        {
            formatter.appendField("pathRetrievalException", e.toString());
        }
        try
        {
            formatter.format("termination", termination());
        }
        catch (Exception e)
        {
            formatter.appendField("terminationRetrievalException", e.toString());
        }
        formatter.decrementLevel();
    }
    
    public String
    formatWithEntities(String title)
    {
        ObjectFormatter formatter = new ObjectFormatter();
        formatWithEntities(formatter, title);
        return formatter.toString();
    }
}
