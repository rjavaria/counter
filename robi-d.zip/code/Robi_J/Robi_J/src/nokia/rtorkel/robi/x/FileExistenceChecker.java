package nokia.rtorkel.robi.x;

import java.io.File;

public class FileExistenceChecker
{
    public static void
    main(String[] args)
    {
        File file = new File("c:\\projects\\robi\\alu_isn\\data2\\step2_from_89\\alu_isn_parent_term_x.sql");
        if (file.exists())
        {
            System.out.println("File " + file + " exists");
        }
        else
        {
            System.out.println("File " + file + " does not exist");
        }
    }
}
