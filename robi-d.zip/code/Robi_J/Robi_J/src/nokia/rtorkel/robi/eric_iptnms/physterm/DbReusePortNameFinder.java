package nokia.rtorkel.robi.eric_iptnms.physterm;

import java.util.HashMap;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import rasmus_torkel.xml_basic.read.TagNode;
import rasmus_torkel.xml_basic.read.factory.MainXmlObjectFactory;
import rasmus_torkel.xml_basic.rw.TagNodeId;

public class DbReusePortNameFinder implements PortNameFinder
{
    private static final Logger _logger = LogManager.getLogger(DbReusePortNameFinder.class);
    
    public static final TagNodeId NATURAL_TAG_NODE_ID = PhysTermNames_3Numbers.NATURAL_TAG_NODE_ID;
    
    public static final MainXmlObjectFactory<DbReusePortNameFinder> FROM_XML_FACTORY =
            new MainXmlObjectFactory<DbReusePortNameFinder>(NATURAL_TAG_NODE_ID)
    {
        @Override
        public DbReusePortNameFinder extractFromNode(TagNode node)
        {
            return new DbReusePortNameFinder(node);
        }
    };
    
    private HashMap<String,String> _internalNameToDbName = new HashMap<String,String>();
    
    public
    DbReusePortNameFinder(TagNode allNesNode)
    {
        boolean finishedNes = false;
        while (!finishedNes)
        {
            TagNode oneNeNode = allNesNode.nextChildN("oneNe");
            if (oneNeNode == null)
            {
                finishedNes = true;
                allNesNode.verifyNoMoreChildren();
            }
            else
            {
                oneNeNode.nextTextFieldE("ne"); // We don't care what it is
                TagNode mappingsNode = oneNeNode.nextChildE("mappings");
                boolean finishedCurrentNe = false;
                while (!finishedCurrentNe)
                {
                    TagNode mappingNode = mappingsNode.nextChildN("mapping");
                    if (mappingNode == null)
                    {
                        mappingsNode.verifyNoMoreChildren();
                        finishedCurrentNe = true;
                    }
                    else
                    {
                        String internalName = mappingNode.nextTextFieldE("internalName");
                        String dbName = mappingNode.nextTextFieldE("dbName");
                        mappingNode.verifyNoMoreChildren();
                        _internalNameToDbName.put(internalName, dbName);
                    }
                }
                oneNeNode.verifyNoMoreChildren();
            }
        }
        allNesNode.verifyNoMoreChildren();
        _logger.info("Read " + _internalNameToDbName.size() + " names");
    }

    @Override
    public String
    findPortName(String neName,
                 String portType,
                 int    shelf,
                 int    card,
                 int    port)
    {
        String internalName = InternalPortNameMaker.makeName(neName, shelf, card, port);
        String dbName = _internalNameToDbName.get(internalName);
        return dbName;
    }
}
