package nokia.rtorkel.robi.eric_iptnms;

import rasmus_torkel.text.write.IndentingLineSink;

public class Route
{
    private final RouteComponent[] _components;
    private int                    _depth = -1;
    
    public
    Route(RouteComponent[] components)
    {
        _components = components;
    }
    
    public int
    depth()
    {
        return _depth;
    }
    
    public boolean
    findDepth()
    {
        int biggestComponentPathDepth = -1;
        if (_depth != -1)
        {
            return true;
        }
        boolean haveSubpath = false;
        for (RouteComponent component : _components)
        {
            if (component instanceof Path)
            {
                Path componentPath = (Path)component;
                int componentPathDepth = componentPath.depth();
                haveSubpath = true;
                if (componentPathDepth == -1)
                {
                    return false;
                }
                else if (componentPathDepth > biggestComponentPathDepth)
                {
                    biggestComponentPathDepth = componentPathDepth;
                }
            }
        }
        if (haveSubpath)
        {
            _depth = biggestComponentPathDepth + 1;
        }
        else
        {
            _depth = 0;
        }
        return true;
    }
    
    public AccessPoint
    firstAccessPoint()
    {
        if (_components.length == 0)
        {
            return null;
        }
        return _components[0].firstAccessPoint();
    }
    
    public AccessPoint
    lastAccessPoint()
    {
        if (_components.length == 0)
        {
            return null;
        }
        return _components[0].lastAccessPoint();
    }
    
    public void
    toIndentingLineSink(IndentingLineSink sink,
                        String            title)
    {
        sink.writeLine(title);
        sink.incrementLevel();
        for (RouteComponent component : _components)
        {
            component.toIndentingLineSink(sink);
        }
        sink.decrementLevel();
    }
}
