package nokia.rtorkel.robi.eric_iptnms.physterm;

public interface PortNameFinder
{
    public String
    findPortName(String         neName,
                 String         portType,
                 int            shelf,
                 int            card,
                 int            port);
}
