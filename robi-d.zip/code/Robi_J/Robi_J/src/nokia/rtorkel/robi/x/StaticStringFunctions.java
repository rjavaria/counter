package nokia.rtorkel.robi.x;

public class StaticStringFunctions
{
    public static void
    main(String[] args)
    {
        System.out.println("fHello returns " + fHello());
        System.out.println("fHello returns " + fHello());
        System.out.println("fDouble(8) returns " + fDouble("8"));
        try
        {
            Thread.sleep(10);
        }
        catch (InterruptedException e)
        {
            System.out.println("Sleeping did not complete");
        }
        System.out.println("fError returns " + fException());
    }
    
    private static int x = 1;
    
    public static String
    fHello()
    {
        String greeting = "Hello " + x;
        x++;
        return greeting;
    }
    
    public static String
    fDouble(String nString)
    {
        int n;
        try
        {
            n = Integer.parseInt(nString);
        }
        catch (Exception e)
        {
            throw new RuntimeException(nString + " is not an integer");
        }
        int nn = n * 2;
        return String.valueOf(nn);
    }
    
    public static String
    fException()
    {
        throw new RuntimeException("This is a test exception");
    }
}
