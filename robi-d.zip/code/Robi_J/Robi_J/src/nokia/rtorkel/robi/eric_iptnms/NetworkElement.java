package nokia.rtorkel.robi.eric_iptnms;

import java.io.File;

import rasmus_torkel.text.write.IndentingLineSink;
import rasmus_torkel.xml_basic.read.TagNode;
import rasmus_torkel.xml_basic.read.XmlReadOptions;
import rasmus_torkel.xml_basic.read.impl.XmlReader;
import rasmus_torkel.xml_basic.rw.TagNodeId;
import rasmus_torkel.xml_basic.rw.XmlNameSpace;
import rasmus_torkel.xml_basic.write.XmlSink;
import rasmus_torkel.xml_basic.write.XmlSinkWritable;

public class NetworkElement implements XmlSinkWritable, ReportingEntity
{
    public final String     _id;
    public final String     _name;
    public final String     _neType;
    
    public       Subnetwork _subnet;
    
    private PhLayerTtp _minShelfPlt;
    private PhLayerTtp _maxShelfPlt;
    private PhLayerTtp _minCardPlt;
    private PhLayerTtp _maxCardPlt;
    private PhLayerTtp _minPortPlt;
    private PhLayerTtp _maxPortPlt;
    
    @Override
    public String
    toString()
    {
        return _id + " " + _name + " " + _neType + " " + (_subnet == null ? "not_in_any_subnet" : _subnet._nestedName);
    }
    
    public
    NetworkElement(TagNode                neNode,
                   EricssonIptnmsEntities entities)
    {
        _id = neNode.attributeValueE("Id");
        EricssonXmlUtil.nextEnumFieldN(neNode, "NetworkElement.aSTNType", "DTASTNType");
        EricssonXmlUtil.nextIntFieldE(neNode, "NetworkElement.EMId");
        EricssonXmlUtil.nextIntFieldE(neNode, "NetworkElement.NEIdOnNM");
        EricssonXmlUtil.nextIntFieldE(neNode, "NetworkElement.NEIdOnEM");
        EricssonXmlUtil.nextTextFieldE(neNode, "NetworkElement.EMName");
        EricssonXmlUtil.nextBoolFieldE(neNode, "NetworkElement.isInstalled");
        _neType = EricssonXmlUtil.nextEnumFieldE(neNode, "NetworkElement.nEType", "DTNEType");
        _name = EricssonXmlUtil.nextTextFieldE(neNode, "NetworkElement.NELongName");
        entities.putNe(this);
    }
    
    public static void
    load(InputFileDirectory     dir,
         EricssonIptnmsEntities entities)
    {
        File neFile = dir.getInputFile("NetworkElement");
        TagNode rootNode = XmlReader.xmlFileToRoot(neFile, XmlReadOptions.DEFAULT, "NetworkManager");
        rootNode.nextChildE("Version");
        TagNode level1Node;
        do
        {
            level1Node = rootNode.nextChildN("NetworkElement");
            if (level1Node != null)
            {
                new NetworkElement(level1Node, entities);
            }
        } while (level1Node != null);
        rootNode.nextChildE("Summary");
        rootNode.verifyNoMoreChildren();
    }
    
    public void
    notifyPhLayerTtp(PhLayerTtp plt)
    {
        if (_minShelfPlt == null)
        {
            _minShelfPlt = plt;
            _maxShelfPlt = plt;
            _minCardPlt = plt;
            _maxCardPlt = plt;
            _minPortPlt = plt;
            _maxPortPlt = plt;
            return;
        }
        if (plt._shelf < _minShelfPlt._shelf)
        {
            _minShelfPlt = plt;
        }
        else if (plt._shelf > _maxShelfPlt._shelf)
        {
            _maxShelfPlt = plt;
        }
        if (plt._card < _minCardPlt._card)
        {
            _minCardPlt = plt;
        }
        else if (plt._card > _maxCardPlt._card)
        {
            _maxCardPlt = plt;
        }
        if (plt._port < _minPortPlt._port)
        {
            _minPortPlt = plt;
        }
        else if (plt._port > _maxPortPlt._port)
        {
            _maxPortPlt = plt;
        }
    }

    @Override
    public void
    makeReport(IndentingLineSink sink)
    {
        if (_minShelfPlt == null)
        {
            String topLine = toString() + " -/- -/- -/-";
            sink.writeLine(topLine);
        }
        else
        {
            String topLine =
                    toString() +
                    " " + _minShelfPlt._shelf + "/" + _maxShelfPlt._shelf +
                    " " + _minCardPlt._card + "/" + _maxCardPlt._card +
                    " " + _minPortPlt._port + "/" + _maxPortPlt._port;
            sink.writeLine(topLine);
            sink.incrementLevel();
            sink.writeLine("minShelf " + _minShelfPlt._shelf + " " + _minShelfPlt._id + " " + _minShelfPlt._name);
            sink.writeLine("maxShelf " + _maxShelfPlt._shelf + " " + _maxShelfPlt._id + " " + _maxShelfPlt._name);
            sink.writeLine("minCard " + _minCardPlt._card + " " + _minCardPlt._id + " " + _minCardPlt._name);
            sink.writeLine("maxCard " + _maxCardPlt._card + " " + _maxCardPlt._id + " " + _maxCardPlt._name);
            sink.writeLine("minPort " + _minPortPlt._port + " " + _minPortPlt._id + " " + _minPortPlt._name);
            sink.writeLine("maxPort " + _maxPortPlt._port + " " + _maxPortPlt._id + " " + _maxPortPlt._name);
            sink.decrementLevel();
        }
    }
    
    private static final TagNodeId NATURAL_TAG_NODE_ID = new TagNodeId("Equipment");

    @Override
    public TagNodeId
    naturalTagNodeId()
    {
        return NATURAL_TAG_NODE_ID;
    }

    @Override
    public void
    mostToXml(XmlSink      xmlSink,
              String       relativeName,
              XmlNameSpace nameSpace)
    {
        xmlSink.sinkSimpleNode("id", _id);
        xmlSink.sinkSimpleNode("name", _name);
        xmlSink.sinkSimpleNode("neType", _neType);
        if (_subnet != null)
        {
            xmlSink.sinkSimpleNode("subnet", _subnet._name);
        }
    }
}
