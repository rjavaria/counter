package nokia.rtorkel.robi.config;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class LogTester
{
    private static final Logger _logger = LogManager.getLogger(LogTester.class);
    
    public static void
    main(String[] args)
    {
        showEnvVar("java.class.path");
        LogConfigurer.configureLoggerDom();
        _logger.trace("Doing file");
        _logger.debug("Doing ok");
        _logger.info("Heads up");
        try
        {
            Thread.sleep(1000);
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
        _logger.warn("Potential problem");
        _logger.error("Things have gone wrong");
        _logger.fatal("We are dying");
    }
    
    public static void
    showEnvVar(String name)
    {
        System.out.println(name + " = " + System.getProperty(name));
    }
}
