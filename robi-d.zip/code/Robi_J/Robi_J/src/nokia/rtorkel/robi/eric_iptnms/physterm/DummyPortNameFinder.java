package nokia.rtorkel.robi.eric_iptnms.physterm;

public class DummyPortNameFinder implements PortNameFinder
{
    public static final DummyPortNameFinder INSTANCE = new DummyPortNameFinder();
    
    @Override
    public String
    findPortName(String         neName,
                 String         portType,
                 int            shelf,
                 int            card,
                 int            port)
    {
        return neName + "/" + shelf + "/" + card + "/" + port + "/dummy";
    }
}
