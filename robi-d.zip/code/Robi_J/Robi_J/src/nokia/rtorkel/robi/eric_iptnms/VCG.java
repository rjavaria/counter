package nokia.rtorkel.robi.eric_iptnms;

import rasmus_torkel.xml_basic.read.TagNode;

public class VCG extends AccessPoint
{
    public
    VCG(TagNode                node,
        EricssonIptnmsEntities entities)
    {
        super(node.nextChildE("AccessPoint"), entities, node._id._relativeName);
        String id = node.attributeValueE("Id");
        if (_isValid)
        {
            registerApId(id, entities);
        }
        else
        {
            entities.putEliminatedEntityByDifferentId(id, "VCG", _id);
        }
    }
}
