package nokia.rtorkel.robi.eric_iptnms;

import rasmus_torkel.xml_basic.read.TagNode;

public class XTTP extends TTP
{
    public XTTP(TagNode                node,
                EricssonIptnmsEntities entities)
    {
        super(node.nextChildE("TTP"), entities, node._id._relativeName);
        if (_type.equals("TTPHO") || _type.equals("TTPLO"))
        {
            if (_subnet != null)
            {
                _name = entities._portNameFinder.findPortName(_subnet._neName, null, _shelf, _card, _port) +
                        "/" + _type + "/tp" + _tp;
            }
            else if (_isValid)
            {
                // This should not happen
                throw new RuntimeException("no subnetwork for " + _type + " AccessPoint " + _id);
            }
        }
        String id = node.attributeValueE("Id");
        if (_isValid)
        {
            registerApId(id, entities);
        }
        else
        {
            entities.putEliminatedEntityByDifferentId(id, "XTTP", _id);
        }
    }
}
