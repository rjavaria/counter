package nokia.rtorkel.robi.db_jdbc._test;

import nokia.rtorkel.robi.db_jdbc.DbHandle;
import nokia.rtorkel.robi.db_jdbc.TransactionMode;
import nokia.rtorkel.robi.db_jdbc.sure.SureDbConfigurer;
import rasmus_torkel.config.PropertiesView;

public class TermNamesByPatternFinderUsingResource
{
    public static void
    main(String[] args)
    {
        if (args.length != 1)
        {
            System.out.println("Needs exactly one paramer, wildcard expression");
            System.exit(-1);
        }
        try
        {
            PropertiesView config = SureDbConfigurer.getConfigurationFromResourceFile();
            DbHandle db =
                    SureDbConfigurer.configureHandle(
                            "SureDB", TransactionMode.READ_ONLY, config, SureDbConfigurer.XDM_DB_PARAM_NAME_PREFIX);
            TermNamesByPatternFinder.testRead(db, args[0]);
        }
        catch (Exception e)
        {
            e.printStackTrace(System.out);
        }
    }
}
