package nokia.rtorkel.robi.x;

import java.io.File;

import rasmus_torkel.namedvalue.NamedString;
import rasmus_torkel.xml_basic.write.XmlSink;

public class EmsNeMilGenerator_xml
{

    private static final String[] _sites = { "Dhaka", "Khulna", "Sylhet" };
    private static final String[] _neTypes = { "Generic NE", "1650SMC" };
    
    public static void
    main(String[] args)
    {
        if (args.length != 2)
        {
            throw new RuntimeException("Need exactly two args, outputFileName, neQty");
        }
        XmlSink sink = new XmlSink(new File(args[0]));
        int qty = Integer.parseInt(args[1]);
        sink.startNode("NetworkEntity");
        for (int i = 0; i < qty; i++)
        {
            if (i == 10 || i == 100 || i == 1000 || i == 10000 || i == 100000)
            {
                System.out.println("Did " + i);
            }
            doOne(sink, i);
        }
        sink.closeNode();
    }
    
    private static void
    doOne(XmlSink sink,
          int     i)
    {
        sink.startNode("Equipment");
        sink.sinkSimpleNode("Name", "ROBINE_BANGL_" + i);
        sink.sinkSimpleNode("Type", _neTypes[i % _neTypes.length]);
        sink.sinkSimpleNode("NetworkName", "ntwDomId=1/emlDomId=100");
        sink.sinkSimpleNode("LocationName", _sites[i % _sites.length]);
        sink.startNode("Features");
        NamedString fdnFeature = new NamedString("FDN", "ntwDomId=1/emlDomId=100/neId=" + i);
        doFeature(sink, fdnFeature);
        sink.closeNode();
        sink.closeNode();
    }
    
    private static void
    doFeature(XmlSink     sink,
              NamedString feature)
    {
        sink.startNode("Feature");
        sink.sinkSimpleNode("Name", feature._name);
        sink.sinkSimpleNode("Value", feature._value);
        sink.sinkSimpleNode("DisplayName", feature._name);
        sink.sinkSimpleNode("Mandatory", false);
        sink.sinkSimpleNode("ReadOnly", false);
        sink.sinkSimpleNode("Discovered", true);
        sink.closeNode();
    }
}
