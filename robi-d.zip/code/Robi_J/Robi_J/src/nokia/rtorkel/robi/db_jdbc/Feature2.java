/*---------------------------------------------------------------------
 * (C) COPYRIGHT 2014 ALCATEL AUSTRALIA LIMITED
 * 
 * This program contains proprietary information which is a trade secret
 * of ALCATEL AUSTRALIA LIMITED and also is protected under the applicable
 * copyright law. Recipient is to retain this program in confidence and is
 * not permitted to use or make any copy thereof other than as permitted
 * under a written agreement with ALCATEL AUSTRALIA LIMITED.
 *-------------------------------------------------------------------*/
package nokia.rtorkel.robi.db_jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Corresponds to a row in one of those table which define features for the primary entities.
 * For example, an instance could refer to a row from t_equipment_feature which is associated
 * with a row from t_equipment.
 * 
 * @author rtorkel
 *
 */
public class Feature2 implements DbConstants, Comparable<Feature2>
{
    public final String m_name;
    public final String m_value;
    
    public
    Feature2(String name,
             String value)
    {
        m_name = name;
        m_value = value;
    }
    
    public static final String SIMPLE_SELECT_CLAUSE = "select name, value" + LINE_END;
    
    @Override
    public String
    toString()
    {
        return m_name + "|" + m_value;
    }
    
    public static Feature2
    fromResultSet(ResultSet      rs) throws SQLException
    {

        String name = rs.getString(1);
        String value = rs.getString(2);
        return new Feature2(name, value);
    }

    @Override
    public int
    compareTo(Feature2 other)
    {
        return m_name.compareTo(other.m_name);
    }
}
