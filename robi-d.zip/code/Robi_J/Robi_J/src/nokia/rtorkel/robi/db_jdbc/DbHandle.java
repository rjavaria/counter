/*---------------------------------------------------------------------
 * (C) COPYRIGHT 2014 ALCATEL AUSTRALIA LIMITED
 * 
 * This program contains proprietary information which is a trade secret
 * of ALCATEL AUSTRALIA LIMITED and also is protected under the applicable
 * copyright law. Recipient is to retain this program in confidence and is
 * not permitted to use or make any copy thereof other than as permitted
 * under a written agreement with ALCATEL AUSTRALIA LIMITED.
 *-------------------------------------------------------------------*/
package nokia.rtorkel.robi.db_jdbc;

import java.sql.SQLException;

/**
 * Defines various database access functions. It's done in such a way that stubbed databases are
 * possible.
 * 
 * @author rtorkel
 */
public abstract class DbHandle
{
    public final TransactionMode m_transactionMode;
    
    /**
     * Constructor.
     * @param transactionMode Note: subclasses do not have to support all transaction modes.
     */
    protected
    DbHandle(TransactionMode transactionMode)
    {
        m_transactionMode = transactionMode;
    }
    
    public abstract String
    label();
    
    /**
     * Commits for those subclasses which support committing.
     * @throws SQLException
     * @throws DbException
     */
    public void
    commit() throws SQLException, DbException
    {
    }
    
    /**
     * Rolls back for those subclasses which support rollback.
     * @throws SQLException
     * @throws DbException
     */
    public void
    rollback() throws SQLException, DbException
    {
        throw new DbException("Rollback is not supported");
    }


    public abstract Network2[]
    networksAll() throws SQLException, DbException;
    
    public abstract Feature2[]
    networkFeatures(Network2 subnet) throws SQLException;
    
    public abstract Network2
    networkById(long id) throws SQLException, DbException;
    
    public abstract Network2
    networkByName(String name) throws SQLException, DbException;
    
    public abstract Network2[]
    networksByEquipment(Equipment2 equip) throws SQLException, DbException;
    
    
    public abstract Equipment2
    equipmentById(long id) throws SQLException, DbException;
    
    public abstract Equipment2
    equipmentByName(String name) throws SQLException, DbException;
    
    public abstract Equipment2[]
    equipmentsByType(String type) throws DbException, SQLException;
    
    public abstract Feature2[]
    equipmentFeatures(Equipment2 equip) throws SQLException;
    
    
    public abstract Termination2
    terminationById(long id) throws SQLException, DbException;
    
    public abstract Termination2
    terminationByName(String name) throws SQLException, DbException;
    
    public abstract Termination2[]
    terminationsByType(String type) throws DbException, SQLException;
    
    public abstract Termination2[]
    terminationsByNamePattern(String namePattern) throws SQLException, DbException;
    
    public abstract Termination2[]
    terminationsByEquipmentId(long equipId) throws SQLException, DbException;
    
    public abstract Termination2[]
    terminationsByPath(Path2 path) throws SQLException, DbException;

    public abstract Feature2[]
    terminationFeatures(Termination2 term) throws SQLException;
    
    public Termination2[]
    terminationsByEquipment(Equipment2 equip) throws SQLException, DbException
    {
        return terminationsByEquipmentId(equip.m_id);
    }
    
    public abstract Termination2[]
    subterminations(Termination2 parentTerm) throws SQLException, DbException;

    
    public abstract Feature2[]
    linkFeatures(Link2 term) throws SQLException;
    
    public abstract Link2
    linkById(long id) throws SQLException, DbException;
    
    public abstract Link2
    linkByName(String name) throws SQLException, DbException;
    
    public abstract Link2[]
    aFacingLinks(Termination2 termZ) throws SQLException, DbException;
    
    public abstract Link2[]
    zFacingLinks(Termination2 termA) throws SQLException, DbException;
    
    public abstract Link2[]
    linksByBothTerminations(Termination2 termA,
                            Termination2 termZ) throws SQLException, DbException;
    
    public abstract Link2[]
    linksByBothTerminationsAndFeature(Termination2 termA,
                                      Termination2 termZ,
                                      String       name,
                                      String       value) throws SQLException, DbException;
    
    public abstract Link2[]
    aFacingLinksFromEquipment(Equipment2 equipZ) throws SQLException, DbException;
    
    public abstract Link2[]
    zFacingLinksFromEquipment(Equipment2 equipA) throws SQLException, DbException;
    
    
    public abstract Feature2[]
    pathFeatures(Path2 path) throws SQLException;
    
    public abstract Path2
    pathById(long id) throws SQLException, DbException;
    
    public abstract Path2[]
    pathsByTermination(Termination2 term) throws SQLException, DbException;
    
    public abstract Path2[]
    subpaths(Path2 parentPath) throws SQLException, DbException;
    
    public abstract Path2[]
    pathsByTypeAndFeatures(String      type,
                           Feature2... expectedFeatures) throws DbException, SQLException;
    

    public abstract PathTermination2[]
    pathTerminationsByEquipment(Equipment2 equip) throws SQLException, DbException;
    
    public abstract PathTermination2[]
    pathTerminationsByTermination(Termination2 term) throws SQLException, DbException;
    
    public abstract PathTermination2[]
    pathTerminationsByPath(Path2 path) throws SQLException, DbException;

    
    public abstract Feature2[]
    serviceFeatures(Service2 service) throws SQLException;
    
    public abstract Service2
    serviceById(long id) throws SQLException, DbException;
    
    /**
     * Obtains services by name
     * @param name This name is also known as FNN
     * @return
     * @throws SQLException
     * @throws DbException
     */
    public abstract Service2[]
    servicesByName(String name) throws SQLException, DbException;
    
    public abstract Service2[]
    servicesByCustomer(Customer2 customer) throws SQLException, DbException;

    
    //public abstract Customer2
    //customerById(long id) throws SQLException, DbException;
    
    //public abstract Customer2
    //customerByName(String name) throws SQLException, DbException;
    
    
    public abstract Capacity2
    capacityById(long id) throws SQLException, DbException;
    
    public abstract Capacity2
    capacityByName(String name) throws SQLException, DbException;
    
    public abstract Feature2[]
    capacityFeatures(Capacity2 service) throws SQLException;
    
    public abstract Capacity2[]
    capacitiesByLink(Link2 link) throws SQLException, DbException;
}
