/*---------------------------------------------------------------------
 * (C) COPYRIGHT 2014 ALCATEL AUSTRALIA LIMITED
 * 
 * This program contains proprietary information which is a trade secret
 * of ALCATEL AUSTRALIA LIMITED and also is protected under the applicable
 * copyright law. Recipient is to retain this program in confidence and is
 * not permitted to use or make any copy thereof other than as permitted
 * under a written agreement with ALCATEL AUSTRALIA LIMITED.
 *-------------------------------------------------------------------*/
package nokia.rtorkel.robi.db_jdbc._test;

import java.sql.Connection;
import java.sql.SQLException;

import nokia.rtorkel.robi.db_jdbc.DbException;
import nokia.rtorkel.robi.db_jdbc.Equipment2;
import nokia.rtorkel.robi.db_jdbc.DbContextInterface;
import nokia.rtorkel.robi.db_jdbc.DbHandle;
import nokia.rtorkel.robi.db_jdbc.DbHandleImpl;
import nokia.rtorkel.robi.db_jdbc.JdbcManager2;
import nokia.rtorkel.robi.db_jdbc.Link2;
import nokia.rtorkel.robi.db_jdbc.ObjectFormatter;
import nokia.rtorkel.robi.db_jdbc.PathTermination2;
import nokia.rtorkel.robi.db_jdbc.StdoutDbContext;
import nokia.rtorkel.robi.db_jdbc.Termination2;
import nokia.rtorkel.robi.db_jdbc.TransactionMode;

/**
 * Does various traversals through database.
 * 
 * @author rtorkel
 *
 */
public class DbHandleTester
{
    public static void
    main(String[] args)
    {
        if (args.length != 4)
        {
            System.out.println("params are url userName password equipmentType");
            System.exit(-1);
        }
        try
        {
            JdbcManager2 manager =
                    new JdbcManager2(args[0], args[1], args[2], "oracle.jdbc.driver.OracleDriver");
            DbContextInterface context = new StdoutDbContext("DB unit test");
            Connection connection = manager.getConnection();
            DbHandle db = new DbHandleImpl(connection, context, TransactionMode.READ_ONLY);
            testRead(db, args[3]);
        }
        catch (Exception e)
        {
            e.printStackTrace(System.out);
        }
    }
    
    public static boolean
    testRead(DbHandle db,
             String     equipmentType) throws Exception
    {
        Equipment2[] equips = db.equipmentsByType(equipmentType);
        if (equips.length == 0)
        {
            System.out.println("Rejected equipment type " + equipmentType + ", no equipment");
            return false;
        }
        for (Equipment2 equip : equips)
        {
            if (testEquipment(db, equip))
            {
                System.out.println("Success for equipment type " + equipmentType);
                return true;
            }
        }
        return false;
    }
    
    public static boolean
    testEquipment(DbHandle db,
                  Equipment2 equip) throws SQLException, DbException
    {
        System.out.println(ObjectFormatter.toString("Original equipment", equip));
        Equipment2 equipByName = db.equipmentByName(equip.m_name);
        System.out.println(ObjectFormatter.toString("Equipment obtained by name", equipByName));
        Termination2[] terms = db.terminationsByEquipment(equip);
        if (terms.length == 0)
        {
            System.out.println("Rejected equipment " + equip.m_name + ", no terminations");
            return false;
        }
        for (Termination2 term : terms)
        {
            if (testEquipmentTermination(db, term))
            {
                System.out.println("Success for equipment " + equip.m_name);
                return true;
            }
        }
        return false;
    }
    
    public static boolean
    testEquipmentTermination(DbHandle   db,
                             Termination2 term) throws SQLException, DbException
    {
        System.out.println(term.formatWithEquipment("equipment termination"));
        Termination2 term2 = db.terminationById(term.m_id);
        System.out.println(term2.formatWithEquipment("termination obtained by id"));
        if (!testAFacingLinks(db, term2))
        {
            return false;
        }
        if (!testPathTerminations(db, term2))
        {
            return false;
        }
        return true;
    }
    
    public static boolean
    testAFacingLinks(DbHandle   db,
                     Termination2 term) throws SQLException, DbException
    {
        Link2[] aFacingLinks = term.aFacingLinks();
        if (aFacingLinks.length == 0)
        {
            System.out.println("Rejected equipment termination " + term.m_name + ", no a facing links");
            return false;
        }
        for (Link2 aFacingLink : aFacingLinks)
        {
            if (testAFacingLink(db, aFacingLink))
            {
                System.out.println("Success for equipment termination " + term.m_name);
                return true;
            }
        }
        return false;
    }
    
    public static boolean
    testAFacingLink(DbHandle db,
                    Link2      link) throws SQLException, DbException
    {
        System.out.println(link.formatWithTerminations("A facing link"));
        Termination2 aTerm = link.terminationA();
        Link2[] reverseLinks = aTerm.zFacingLinks();
        if (reverseLinks.length == 0)
        {
            throw new RuntimeException("no reverse link");
        }
        for (Link2 reverseLink : reverseLinks)
        {
            if (reverseLink.m_id == link.m_id)
            {
                Termination2 equipTerm2 = link.terminationZ();
                System.out.println(
                        ObjectFormatter.toString("equipment termination on reverse link", equipTerm2));
                System.out.println("Success for A facing link " + link.m_name);
                return true;
            }
        }
        throw new RuntimeException("Could not find matching reverse link");
    }
    
    public static boolean
    testPathTerminations(DbHandle   db,
                         Termination2 term) throws SQLException, DbException
    {
        PathTermination2[] pts = term.pathTerminations();
        if (pts.length == 0)
        {
            System.out.println("Rejected equipment termination " + term.m_name + ", no paths");
            return false;
        }
        for (PathTermination2 pt : pts)
        {
            if (testPathTermination(db, pt))
            {
                return true;
            }
        }
        return false;
    }
    
    public static boolean
    testPathTermination(DbHandle      db,
                        PathTermination2 pt) throws SQLException, DbException
    {
        System.out.println(pt.formatWithEntities("Path to Termination maplet"));
        System.out.println(
                "Success for path termination maplet " +
                pt.path().m_name + " to " + pt.termination().m_name);
        return true;
    }
}
