package nokia.rtorkel.robi.eric_iptnms;

import rasmus_torkel.xml_basic.read.TagNode;

public class Link
{
    public final String     _id;
    public final PhLayerTtp _fromTp;
    public final PhLayerTtp _toTp;
    public final int        _linkId;
    public final String     _name;
    public final String     _state;
    
    @Override
    public String
    toString()
    {
        return _id + " " + _name + " " + getClass().getSimpleName() + " from " + _fromTp._name + " to " + _toTp._name;
    }
    
    public String
    toShortString()
    {
        return _id + " " + _name + " " + getClass().getSimpleName();
    }
    
    public
    Link(TagNode                node,
         EricssonIptnmsEntities entities) throws EntityNotCreatedException
    {
        _id = node.attributeValueE("Id");
        Subnetwork toSubnet = readSubnet(node, "Link.toSN", entities);
        Subnetwork fromSubnet = readSubnet(node, "Link.fromSN", entities);
        _toTp = readPlt(node, "Link.toTP", entities, toSubnet);
        _fromTp = readPlt(node, "Link.fromTP", entities, fromSubnet);
        _linkId = EricssonXmlUtil.nextIntFieldE(node, "Link.linkId");
        _name = EricssonXmlUtil.nextTextFieldE(node, "Link.linkName");
        _state = EricssonXmlUtil.nextEnumFieldE(node, "Link.state", "DTState");
        node.nextChildE("Link.creationDate");
        node.verifyNoMoreChildren();
    }
    
    private Subnetwork
    readSubnet(TagNode                parentNode,
               String                 fieldName,
               EricssonIptnmsEntities entities)
    {
        String subnetId = EricssonXmlUtil.nextIdFieldE(parentNode, fieldName, "SubNetwork");
        Subnetwork subnet = entities.lookUpSubnet(subnetId);
        if (subnet == null)
        {
            throw new RuntimeException("PhLink " + _id + " refers to non-existent subnetwork " + subnetId);
        }
        return subnet;
    }
    
    private PhLayerTtp
    readPlt(TagNode                parentNode,
            String                 fieldName,
            EricssonIptnmsEntities entities,
            Subnetwork             subnet) throws EntityNotCreatedException
    {
        String pltId = EricssonXmlUtil.nextIdFieldE(parentNode, fieldName, "PhLayerTtp");
        PhLayerTtp plt = entities.lookUpPlt(pltId);
        if (plt == null)
        {
            entities.putEliminatedDependentEntity(_id, "Link", pltId, "PhLayerTtp");
            throw new EntityNotCreatedException();
        }
        if (plt._subnet != subnet)
        {
            entities.putEliminatedEntity(
                    _id, "Link",
                    "PhLayerTtp " + pltId + " is on subnetwork " + plt._subnet._id +
                    " but was expected to be on subnetwork " + subnet);
            throw new EntityNotCreatedException();
        }
        return plt;
    }
}
