package nokia.rtorkel.robi.eric_iptnms;

import java.util.HashMap;
import java.util.Iterator;

import rasmus_torkel.text.write.IndentingLineSink;

public class AccessPointSubtypeSummary
{
    String _subtype;
    
    public final OneCategorySummary _phLayerTpMatchesTopoSummary =
            new OneCategorySummary("Has matching PhLayerTtp");
    public final OneCategorySummary _phLayerTpDoesNotMatchTopoSummary =
            new OneCategorySummary("Has PhLayerTtp but topology info does not match");
    public final OneCategorySummary _noPhLayerTpSummary =
            new OneCategorySummary("Does not have PhLayerTtp");
    
    public
    AccessPointSubtypeSummary(String subtype)
    {
        _subtype = subtype;
    }
    
    public static void
    report(HashMap<String,AccessPointSubtypeSummary> subtypeToSummary)
    {
        IndentingLineSink lineSink = new IndentingLineSink();
        lineSink.writeLine("AccessPoint subtype summaries");
        lineSink.incrementLevel();
        Iterator<String> it = subtypeToSummary.keySet().iterator();
        while (it.hasNext())
        {
            String subtype = it.next();
            AccessPointSubtypeSummary summary = subtypeToSummary.get(subtype);
            OneCategorySummary.reportSet(
                    lineSink,
                    summary._subtype,
                    summary._phLayerTpMatchesTopoSummary,
                    summary._phLayerTpDoesNotMatchTopoSummary,
                    summary._noPhLayerTpSummary);
        }
        lineSink.decrementLevel();
        System.out.print(lineSink.toString());;
    }
}
