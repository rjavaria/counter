/*---------------------------------------------------------------------
 * (C) COPYRIGHT 2014 ALCATEL AUSTRALIA LIMITED
 * 
 * This program contains proprietary information which is a trade secret
 * of ALCATEL AUSTRALIA LIMITED and also is protected under the applicable
 * copyright law. Recipient is to retain this program in confidence and is
 * not permitted to use or make any copy thereof other than as permitted
 * under a written agreement with ALCATEL AUSTRALIA LIMITED.
 *-------------------------------------------------------------------*/
package nokia.rtorkel.robi.db_jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Each instance corresponds to a row in equipments plus some associated information.
 * 
 * @author rtorkel
 *
 */
public class Equipment2 extends PrimaryEntity
{
    public
    Equipment2(long       id,
               String     name,
               String     type,
               String     discoveredName,
               DbHandle db)
    {
        super(EntityType.Equipment, id, name, discoveredName, type, db);
    }
    
    public static final PrimaryEntityTable ENTITY_TABLE =
            new PrimaryEntityTable("equipments", "equipment_id", "equipment_name", "equipment_type_id", "discovered_name");
    
    public static final FeatureTable FEATURE_TABLE =
            new FeatureTable("equipment_features", ENTITY_TABLE);
    
    public static Equipment2
    fromResultSet(DbHandleImpl db,
                  ResultSet      rs) throws SQLException, DbException
    {

        long id = rs.getLong(1);
        String name = rs.getString(2);
        long typeId = rs.getLong(3);
        String discoveredName = rs.getString(4);
        String type = db.m_equipTypeMap.getString(typeId);
        if (type == null)
        {
            throw new DbException(
                "Equipment type id " + typeId +
                " for equipment " + name + " does not map to type");
        }
        return new Equipment2(id, name, type, discoveredName, db);
    }

    @Override
    public Feature2[]
    lookUpFeatures() throws SQLException
    {
        return m_db.equipmentFeatures(this);
    }

    @Override
    public PrimaryEntityTable
    entityTable()
    {
        return ENTITY_TABLE;
    }

    @Override
    public FeatureTable
    featureTable()
    {
        return FEATURE_TABLE;
    }
    
    public Network2[]
    subnetworks() throws SQLException, DbException
    {
        return m_db.networksByEquipment(this);
    }
    
    public Termination2[]
    terminations() throws SQLException, DbException
    {
        return m_db.terminationsByEquipment(this);
    }
    
    public void
    formatWithSubnetworks(ObjectFormatter formatter,
                          String          title)
    {
        formatter.appendTitle(title);
        formatter.incrementLevel();
        formatCore(formatter);
        try
        {
            Network2[] subnets = subnetworks();
            formatter.appendTitle("Subnetworks");
            formatter.incrementLevel();
            for (Network2 subnet : subnets)
            {
                formatter.appendLine(subnet.m_name);
            }
            formatter.decrementLevel();
        }
        catch (Exception e)
        {
            formatter.appendField("subnetwork retrieval exception", e.toString());
        }
        formatter.decrementLevel();
    }
    
    public String
    formatWithSubnetworks(String title)
    {
        ObjectFormatter formatter = new ObjectFormatter();
        formatWithSubnetworks(formatter, title);
        return formatter.toString();
    }
}
