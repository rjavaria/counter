package nokia.rtorkel.robi.eric_iptnms;

public class EntityNotCreatedException extends Exception
{
    public
    EntityNotCreatedException()
    {
        super();
    }
    
    public
    EntityNotCreatedException(String                 id,
                              String                 category,
                              String                 reason,
                              EricssonIptnmsEntities entities)
    {
        super();
        entities.putEliminatedEntity(id, category, reason);
    }
    
    public
    EntityNotCreatedException(String                 id,
                              String                 category,
                              String                 referredToId,
                              String                 referredToCategory,
                              EricssonIptnmsEntities entities)
    {
        super();
        entities.putEliminatedDependentEntity(id, category, referredToId, referredToCategory);
    }
}
