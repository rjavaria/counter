package nokia.rtorkel.robi.config;

import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

import org.apache.log4j.xml.DOMConfigurator;

import nokia.rtorkel.robi.db_jdbc.sure.SureDbConfigurer;

public class LogConfigurer
{
    public static File
    fileFromResource(String resourceName)
    {
        ClassLoader loader = SureDbConfigurer.class.getClassLoader();
        URL resourceUrl = loader.getResource(resourceName);
        if (resourceUrl == null)
        {
            String message = "resource " + resourceName + " does not exist";
            throw new RuntimeException(message);
        }
        URI resourceUri;
        try
        {
            resourceUri = resourceUrl.toURI();
        }
        catch (URISyntaxException e)
        {
            String message = "Failed to convert URL " + resourceUrl + " to URI: " + e;
            throw new RuntimeException(message, e);
        }
        File file = new File(resourceUri);
        return file;
    }
    
    public static void
    configureLoggerDom(String resourceName)
    {
        File logConfigFile = fileFromResource(resourceName);
        DOMConfigurator.configure(logConfigFile.toString());
    }
    
    public static void
    configureLoggerDom()
    {
        configureLoggerDom("log4j.xml");
    }
}
