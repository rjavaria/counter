package nokia.rtorkel.robi.eric_iptnms.physterm;

import java.io.File;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import nokia.rtorkel.robi.db_jdbc.DbHandle;
import nokia.rtorkel.robi.db_jdbc.TransactionMode;
import nokia.rtorkel.robi.db_jdbc.sure.SureDbConfigurer;
import rasmus_torkel.config.PropertiesView;

public enum PortNameFinderOption
{
    DbFresh,
    DbReuse,
    Dummy,
    FailAll;
    
    private static final Logger _logger = LogManager.getLogger(PortNameFinderOption.class);
    
    public static PortNameFinder
    makeFinder(PropertiesView propView)
    {
        PortNameFinderOption option =
                (PortNameFinderOption)propView.enumE("portNameFinderOption", PortNameFinderOption.class);
        _logger.debug("option = " + option);
        if (option == DbFresh)
        {
            String dbResourceFileName = propView.stringE("dbResourceFile");
            File mappingFile = getMappingFile(propView);
            PropertiesView dbPropView = SureDbConfigurer.getConfigurationFromResourceFile(dbResourceFileName);
            DbHandle db = SureDbConfigurer.configureHandle(
                    "SureDB", TransactionMode.READ_ONLY, dbPropView, SureDbConfigurer.XDM_DB_PARAM_NAME_PREFIX);
            return PhysTermNames_3Numbers.make(db, propView, mappingFile);
        }
        else if (option == DbReuse)
        {
            File mappingFile = getMappingFile(propView);
            return DbReusePortNameFinder.FROM_XML_FACTORY.fileToObject(mappingFile);
        }
        else if (option == Dummy)
        {
            return new DummyPortNameFinder();
        }
        else if (option == FailAll)
        {
            return new FailAllPortNameFinder();
        }
        else
        {
            throw new RuntimeException("Internal error, no code for option " + option);
        }
    }
    
    private static File
    getMappingFile(PropertiesView propView)
    {
        File mappingDir = propView.fileE("portNameDir");
        if (!mappingDir.exists())
        {
            throw new RuntimeException("directory " + mappingDir + " does not exist");
        }
        if (!mappingDir.isDirectory())
        {
            throw new RuntimeException("directory " + mappingDir + " is not a directory");
        }
        File mappingFile = new File(mappingDir, "portNameMap.xml");
        return mappingFile;
    }
}
