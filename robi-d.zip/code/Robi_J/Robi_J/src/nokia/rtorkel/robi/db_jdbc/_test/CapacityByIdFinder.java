package nokia.rtorkel.robi.db_jdbc._test;

import nokia.rtorkel.robi.db_jdbc.Capacity2;
import nokia.rtorkel.robi.db_jdbc.DbHandle;
import nokia.rtorkel.robi.db_jdbc.DbHandleImpl;
import nokia.rtorkel.robi.db_jdbc.ObjectFormatter;

public class CapacityByIdFinder extends DbUnitTest
{
    public static void
    main(String[] args)
    {
        try
        {
            DbHandleImpl db = makeDbHandle(args, "capacityId");
            testRead(db, args[3]);
        }
        catch (Exception e)
        {
            e.printStackTrace(System.out);
        }
    }
    
    public static void
    testRead(DbHandle db,
             String   idS) throws Exception
    {
        long id = Long.parseLong(idS);
        Capacity2 capacity = db.capacityById(id);
        if (capacity == null)
        {
            System.out.println("No capacity with id " + id);
            return;
        }
        System.out.println(ObjectFormatter.toString("Capacity with id " + id, capacity));
        Capacity2 capacityByName = db.capacityByName(capacity.m_name);
        System.out.println(ObjectFormatter.toString("Capacity with name " + capacity.m_name, capacityByName));
    }
}
