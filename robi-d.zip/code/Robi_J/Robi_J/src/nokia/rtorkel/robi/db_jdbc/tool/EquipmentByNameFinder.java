/*---------------------------------------------------------------------
 * (C) COPYRIGHT 2015 ALCATEL-LUCENT AUSTRALIA LIMITED
 * 
 * This program contains proprietary information which is a trade secret
 * of ALCATEL-LUCENT AUSTRALIA LIMITED and also is protected under the applicable
 * copyright law. Recipient is to retain this program in confidence and is
 * not permitted to use or make any copy thereof other than as permitted
 * under a written agreement with ALCATEL-LUCENT AUSTRALIA LIMITED.
 *-------------------------------------------------------------------*/
package nokia.rtorkel.robi.db_jdbc.tool;

import java.sql.SQLException;

import nokia.rtorkel.robi.db_jdbc.DbException;
import nokia.rtorkel.robi.db_jdbc.Equipment2;
import nokia.rtorkel.robi.db_jdbc.DbLightweightUtil;
import nokia.rtorkel.robi.db_jdbc.DbHandle;

/**
 * Finds equipment by name
 * 
 * @author rtorkel
 */
public class EquipmentByNameFinder
{
    public static void
    main(String[] args)
    {
        DbLightweightUtil.checkArgs(args, 4, "url userName password equipmentName");
        try
        {
            DbHandle db = DbLightweightUtil.makeSilentDb(args);
            read(db, args[3]);
        }
        catch (Exception e)
        {
            e.printStackTrace(System.out);
        }
    }
    
    private static void
    read(DbHandle db,
         String     name) throws SQLException, DbException
    {
        Equipment2 equip = db.equipmentByName(name);
        System.out.println(equip.formatWithSubnetworks(null));
    }
}
