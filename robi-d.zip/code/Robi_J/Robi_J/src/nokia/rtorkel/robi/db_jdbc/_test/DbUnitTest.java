package nokia.rtorkel.robi.db_jdbc._test;

import java.sql.Connection;
import java.sql.SQLException;

import nokia.rtorkel.robi.db_jdbc.DbContextInterface;
import nokia.rtorkel.robi.db_jdbc.DbHandleImpl;
import nokia.rtorkel.robi.db_jdbc.JdbcManager2;
import nokia.rtorkel.robi.db_jdbc.StdoutDbContext;
import nokia.rtorkel.robi.db_jdbc.TransactionMode;

public class DbUnitTest
{
    public static DbHandleImpl
    makeDbHandle(String[] args) throws ClassNotFoundException, SQLException
    {
        if (args.length < 3)
        {
            System.out.println("less than 3 arguments, need at least url, userName, password");
            System.exit(-1);
        }
        JdbcManager2 manager =
                new JdbcManager2(args[0], args[1], args[2], "oracle.jdbc.driver.OracleDriver");
        DbContextInterface context = new StdoutDbContext("DB unit test");
        Connection connection = manager.getConnection();
        DbHandleImpl db = new DbHandleImpl(connection, context, TransactionMode.READ_ONLY);
        return db;
    }
    
    public static DbHandleImpl
    makeDbHandle(String[]   args,
                 String...  extraParamsDescription) throws ClassNotFoundException, SQLException
    {
        showArguments(args);
        if (args.length != 3 + extraParamsDescription.length)
        {
            StringBuilder buf = new StringBuilder("required arguments are url, userName, password");
            for (String extraParamDescription : extraParamsDescription)
            {
                buf.append(", ");
                buf.append(extraParamDescription);
            }
            System.out.println(buf.toString());
            System.exit(-1);
        }
        return makeDbHandle(args);
    }
    
    /*
    public static DbHandleImpl
    makeDbHandle(String[] args,
                 String   extraParam1Desc,
                 String   extraParam2Desc) throws ClassNotFoundException, SQLException
    {
        showArguments(args);
        if (args.length != 5)
        {
            System.out.println("required arguments are url, userName, password, " + extraParam1Desc + ", " + extraParam2Desc);
            System.exit(-1);
        }
        return makeDbHandle(args);
    }
    */
    
    public static void
    showArguments(String[] args)
    {
        System.out.println("args.length = " + args.length);
        for (int i = 0; i < args.length; i++)
        {
            System.out.println("args[" + i + "] = " + args[i]);
        }
    }
}
