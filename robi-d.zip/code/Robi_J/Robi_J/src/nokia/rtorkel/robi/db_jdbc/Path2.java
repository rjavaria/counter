/*---------------------------------------------------------------------
 * (C) COPYRIGHT 2014 ALCATEL AUSTRALIA LIMITED
 * 
 * This program contains proprietary information which is a trade secret
 * of ALCATEL AUSTRALIA LIMITED and also is protected under the applicable
 * copyright law. Recipient is to retain this program in confidence and is
 * not permitted to use or make any copy thereof other than as permitted
 * under a written agreement with ALCATEL AUSTRALIA LIMITED.
 *-------------------------------------------------------------------*/
package nokia.rtorkel.robi.db_jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Each instance corresponds to a row in the paths table and associated information.
 * 
 * @author rtorkel
 *
 */
public class Path2 extends PrimaryEntity
{
    protected
    Path2(long       id,
          String     name,
          String     type,
          String     discoveredName,
          DbHandle db)
    {
        super(EntityType.Path, id, name, type, discoveredName, db);
    }
    
    public static final PrimaryEntityTable ENTITY_TABLE =
            new PrimaryEntityTable("paths", "path_id", "path_name", "path_type_id", "discovered_name");
    
    public static final FeatureTable FEATURE_TABLE =
            new FeatureTable("path_features", ENTITY_TABLE);
    
    public static Path2
    fromResultSet(DbHandleImpl db,
                  ResultSet      rs) throws SQLException, DbException
    {

        long id = rs.getLong(1);
        String name = rs.getString(2);
        long typeId = rs.getLong(3);
        String discoveredName = rs.getString(4);
        String type = db.m_pathTypeMap.getString(typeId);
        if (type == null)
        {
            throw new DbException(
                "Path type id " + typeId +
                " for path " + name + " does not map to type");
        }
        return new Path2(id, name, type, discoveredName, db);
    }

    @Override
    public PrimaryEntityTable
    entityTable()
    {
        return ENTITY_TABLE;
    }

    @Override
    public FeatureTable
    featureTable()
    {
        return FEATURE_TABLE;
    }

    @Override
    public Feature2[]
    lookUpFeatures() throws SQLException
    {
        return m_db.pathFeatures(this);
    }
    
    public Path2[]
    subPaths() throws SQLException, DbException
    {
        return m_db.subpaths(this);
    }
    
    public PathTermination2[]
    pathTerminations() throws SQLException, DbException
    {
        return m_db.pathTerminationsByPath(this);
    }
    
    public Termination2[]
    terminations() throws SQLException, DbException
    {
        return m_db.terminationsByPath(this);
    }
}
