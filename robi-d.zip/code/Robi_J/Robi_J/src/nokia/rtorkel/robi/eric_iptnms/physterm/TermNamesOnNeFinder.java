package nokia.rtorkel.robi.eric_iptnms.physterm;

public abstract class TermNamesOnNeFinder
{
    public abstract String[]
    termNames(String neName) throws Exception;
}
