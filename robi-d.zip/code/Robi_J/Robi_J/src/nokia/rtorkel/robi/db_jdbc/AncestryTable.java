/*---------------------------------------------------------------------
 * (C) COPYRIGHT 2014 ALCATEL AUSTRALIA LIMITED
 * 
 * This program contains proprietary information which is a trade secret
 * of ALCATEL AUSTRALIA LIMITED and also is protected under the applicable
 * copyright law. Recipient is to retain this program in confidence and is
 * not permitted to use or make any copy thereof other than as permitted
 * under a written agreement with ALCATEL AUSTRALIA LIMITED.
 *-------------------------------------------------------------------*/
package nokia.rtorkel.robi.db_jdbc;

/**
 * Represents a table that defines hierarchies of entities of the same type, for example t_path_subpath.
 * 
 * @author rtorkel
 *
 */
public class AncestryTable
{
    public static final AncestryTable PATH_SUBPATH =
            new AncestryTable(Path2.ENTITY_TABLE, "t_path_subpath", "path_id", "subpath_id");
    public static final AncestryTable TERM_SUBTERM =
            new AncestryTable(Termination2.ENTITY_TABLE, "t_term_subterm", "term_id", "subterm_id");
    
    public final PrimaryEntity.PrimaryEntityTable m_entityTable;
    public final String m_tableName;
    public final EntityColumn m_parentColumn;
    public final EntityColumn m_childColumn;
    
    public
    AncestryTable(PrimaryEntity.PrimaryEntityTable entityTable,
                  String                    tableName,
                  String                    parentColumnName,
                  String                    childColumnName)
    {
        m_entityTable = entityTable;
        m_tableName = tableName;
        m_parentColumn = new EntityColumn(tableName, parentColumnName);
        m_childColumn = new EntityColumn(tableName, childColumnName);
    }
}
