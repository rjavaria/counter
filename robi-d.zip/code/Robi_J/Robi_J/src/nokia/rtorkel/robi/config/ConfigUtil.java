package nokia.rtorkel.robi.config;

import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import nokia.rtorkel.robi.db_jdbc.sure.SureDbConfigurer;

public class ConfigUtil
{
    private static final Logger _logger = LogManager.getLogger(ConfigUtil.class);
    
    public static File
    fileFromResource(String resourceName)
    {
        ClassLoader loader = SureDbConfigurer.class.getClassLoader();
        _logger.debug("resourceName = " + resourceName);
        URL resourceUrl = loader.getResource(resourceName);
        if (resourceUrl == null)
        {
            String message = "resource " + resourceName + " does not exist";
            _logger.error(message);
            throw new RuntimeException(message);
        }
        _logger.debug("resourceUrl = " + resourceUrl);
        URI resourceUri;
        try
        {
            resourceUri = resourceUrl.toURI();
        }
        catch (URISyntaxException e)
        {
            String message = "Failed to convert URL " + resourceUrl + " to URI: " + e;
            _logger.error(message, e);
            throw new RuntimeException(message, e);
        }
        _logger.debug("resourceUri " + resourceUri);
        File file = new File(resourceUri);
        _logger.debug("file = " + file);
        return file;
    }
}
