/*---------------------------------------------------------------------
 * (C) COPYRIGHT 2014 ALCATEL AUSTRALIA LIMITED
 * 
 * This program contains proprietary information which is a trade secret
 * of ALCATEL AUSTRALIA LIMITED and also is protected under the applicable
 * copyright law. Recipient is to retain this program in confidence and is
 * not permitted to use or make any copy thereof other than as permitted
 * under a written agreement with ALCATEL AUSTRALIA LIMITED.
 *-------------------------------------------------------------------*/
package nokia.rtorkel.robi.db_jdbc.query;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import nokia.rtorkel.robi.db_jdbc.AncestryTable;
import nokia.rtorkel.robi.db_jdbc.EntityColumn;
import nokia.rtorkel.robi.db_jdbc.DbContextInterface;
import nokia.rtorkel.robi.db_jdbc.LazyPreparedStatement;

/**
 * For retrieval of entities which are related to entities of the same type
 * through a hierarchy.
 * 
 * @author rtorkel
 *
 */
public class AncestryByLongColumn extends LazyPreparedStatement
{
    public
    AncestryByLongColumn(Connection    connection,
                         AncestryTable ancestryTable,
                         EntityColumn  originalIdColumn,
                         EntityColumn  otherIdColumn,
                         DbContextInterface   context)
    {
        super(connection, makeSql(ancestryTable, originalIdColumn, otherIdColumn), context);
    }
    
    private static String
    makeSql(AncestryTable ancestryTable,
            EntityColumn  originalIdColumn,
            EntityColumn  otherIdColumn)
    {
        return  ancestryTable.m_entityTable.makeSimpleSelectClause() +
                "    from " + ancestryTable.m_entityTable.m_tableName + ", " +
                              ancestryTable.m_tableName + LINE_END +
                "    where " + originalIdColumn.m_tabColPhrase + " = ?" + LINE_END +
                "      and " + ancestryTable.m_entityTable.m_idColumn.m_tabColPhrase + " = " +
                               otherIdColumn.m_tabColPhrase + LINE_END;
    }
    
    public ResultSet
    run(long origPathId) throws SQLException
    {
        ensureReady();
        setLong(1, origPathId);
        return executeQuery();
    }
}
