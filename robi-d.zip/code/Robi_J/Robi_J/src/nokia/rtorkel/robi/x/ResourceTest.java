package nokia.rtorkel.robi.x;

import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

public class ResourceTest
{
    public static void
    main(String[] args)
    {
        ResourceTest t = new ResourceTest();
        t.test();
    }
    
    public void
    test()
    {
        showEnvVar("java.home");
        showEnvVar("user.home");
        showEnvVar("java.class.path");
        ClassLoader loader = getClass().getClassLoader();
        URL resourceUrl = loader.getResource("HOLink.xml");
        System.out.println("resourceUrl = " + resourceUrl);
        URI resourceUri;
        try
        {
            resourceUri = resourceUrl.toURI();
        }
        catch (URISyntaxException e)
        {
            e.printStackTrace();
            return;
        }
        System.out.println("resourceUri " + resourceUri);
        File file = new File(resourceUri);
        System.out.println("file = " + file);
    }
    
    public void
    showEnvVar(String name)
    {
        System.out.println(name + " = " + System.getProperty(name));
    }
}
