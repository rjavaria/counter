package nokia.rtorkel.robi.eric_iptnms;

import rasmus_torkel.text.write.IndentingLineSink;

public class MissingRouteComponent implements RouteComponent
{
    String _type;
    String _id;
    String _message;
    
    public
    MissingRouteComponent(String type,
                          String id)
    {
        _type = type;
        _id = id;
        _message = "Missing " + type + " component " + id;
    }

    @Override
    public void
    toIndentingLineSink(IndentingLineSink sink)
    {
        sink.writeLine(_message);
    }
    
    public AccessPoint
    firstAccessPoint()
    {
        return null;
    }
    
    public AccessPoint
    lastAccessPoint()
    {
        return null;
    }
    
    @Override
    public String
    toString()
    {
        return _message;
    }
}
