/*---------------------------------------------------------------------
 * (C) COPYRIGHT 2015 ALCATEL-LUCENT AUSTRALIA LIMITED
 * 
 * This program contains proprietary information which is a trade secret
 * of ALCATEL-LUCENT AUSTRALIA LIMITED and also is protected under the applicable
 * copyright law. Recipient is to retain this program in confidence and is
 * not permitted to use or make any copy thereof other than as permitted
 * under a written agreement with ALCATEL-LUCENT AUSTRALIA LIMITED.
 *-------------------------------------------------------------------*/
package nokia.rtorkel.robi.db_jdbc;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * These are some lightweight functions for people who want to quickly get a database going
 * without the hassle of setting up configuration, etc.
 * It's intended to make it easy to quickly write a Java program to get data out of the database
 * instead of doing database queries.
 * 
 * @author rtorkel
 */
public class DbLightweightUtil
{
    /**
     * Print main class and arguments and checks the arguments against expected number of arguments.
     * Exits program if wrong.
     * @param args           Command line arguments
     * @param expectedArgQty How many arguments are expected
     * @param argQtyWrongMsg What to write if the number of arguments is not what we expect
     */
    public static void
    checkArgs(String[] args,
              int      expectedArgQty,
              String   argQtyWrongMsg)
    {
        StackTraceElement[] stack = Thread.currentThread().getStackTrace();
        String className = stack[stack.length - 1].getClassName();
        System.out.println(className);
        for (int i = 0; i < args.length; i++)
        {
            System.out.println("args[" + i + "] = " + args[i]);
        }
        if (args.length != expectedArgQty)
        {
            System.out.println("We expected " + expectedArgQty + " arguments: " + argQtyWrongMsg);
            System.exit(-1);
        }
    }
    
    /**
     * Initializes a database without the hassle of configuration, etc.
     * 
     * @param args jdbcUrl, userName, password. The idea is that they come from the command line.
     * @return
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    public static DbHandle
    makeDb(String[] args) throws ClassNotFoundException, SQLException
    {
        DbContextInterface context = new StdoutDbContext("DB unit test");
        return makeDb(args, context);
    }
    /**
     * Initializes a database without the hassle of configuration, etc.
     * 
     * @param args jdbcUrl, userName, password. The idea is that they come from the command line.
     * @return
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    public static DbHandle
    makeSilentDb(String[] args) throws ClassNotFoundException, SQLException
    {
        return makeDb(args, SilentDbContext.INSTANCE);
    }
    
    /**
     * Initializes a database without the hassle of configuration, etc.
     * 
     * @param args     jdbcUrl, userName, password. The idea is that they come from the command line.
     * @param context  required by database.
     * @return
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    public static DbHandle
    makeDb(String[]             args,
           DbContextInterface context) throws ClassNotFoundException, SQLException
    {
        JdbcManager2 manager =
                new JdbcManager2(args[0], args[1], args[2], "oracle.jdbc.driver.OracleDriver");
        Connection connection = manager.getConnection();
        DbHandle db = new DbHandleImpl(connection, context, TransactionMode.READ_ONLY);
        return db;
    }
}
