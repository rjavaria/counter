/*---------------------------------------------------------------------
 * (C) COPYRIGHT 2014 ALCATEL AUSTRALIA LIMITED
 * 
 * This program contains proprietary information which is a trade secret
 * of ALCATEL AUSTRALIA LIMITED and also is protected under the applicable
 * copyright law. Recipient is to retain this program in confidence and is
 * not permitted to use or make any copy thereof other than as permitted
 * under a written agreement with ALCATEL AUSTRALIA LIMITED.
 *-------------------------------------------------------------------*/
package nokia.rtorkel.robi.db_jdbc.query;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import nokia.rtorkel.robi.db_jdbc.DbContextInterface;
import nokia.rtorkel.robi.db_jdbc.LazyPreparedStatement;
import nokia.rtorkel.robi.db_jdbc.PathTermination2;
import nokia.rtorkel.robi.db_jdbc.Termination2;

/**
 * For searching for all the path terminations from one equipment.
 * 
 * @author rtorkel
 *
 */
public class PathTerminationsByEquipmentId extends LazyPreparedStatement
{
    public
    PathTerminationsByEquipmentId(Connection connection,
                                  DbContextInterface context)
    {
        super(connection, makeSql(), context);
    }
    
    private static String
    makeSql()
    {
        String term_col_equipId = Termination2.ENTITY_TABLE.m_equipIdColumn.m_tabColPhrase;
        String term_col_termId = Termination2.ENTITY_TABLE.m_idColumn.m_tabColPhrase;
        String pt_col_termId = PathTermination2.ENTITY_TABLE.m_termIdColumn.m_tabColPhrase;
        return  PathTermination2.ENTITY_TABLE.makeSimpleSelectClause() +
                "    from " + Termination2.ENTITY_TABLE.m_tableName + ", " + PathTermination2.ENTITY_TABLE.m_tableName + LINE_END +
                "    where " + term_col_equipId + " = ? " + LINE_END +
                "      and " + pt_col_termId + " = " + term_col_termId;
    }
    
    public ResultSet
    run(long equipId) throws SQLException
    {
        ensureReady();
        setLong(1, equipId);
        return executeQuery();
    }
}
