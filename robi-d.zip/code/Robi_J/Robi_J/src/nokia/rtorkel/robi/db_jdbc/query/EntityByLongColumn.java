/*---------------------------------------------------------------------
 * (C) COPYRIGHT 2014 ALCATEL AUSTRALIA LIMITED
 * 
 * This program contains proprietary information which is a trade secret
 * of ALCATEL AUSTRALIA LIMITED and also is protected under the applicable
 * copyright law. Recipient is to retain this program in confidence and is
 * not permitted to use or make any copy thereof other than as permitted
 * under a written agreement with ALCATEL AUSTRALIA LIMITED.
 *-------------------------------------------------------------------*/
package nokia.rtorkel.robi.db_jdbc.query;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import nokia.rtorkel.robi.db_jdbc.EntityColumn;
import nokia.rtorkel.robi.db_jdbc.EntityTable;
import nokia.rtorkel.robi.db_jdbc.DbContextInterface;
import nokia.rtorkel.robi.db_jdbc.LazyPreparedStatement;

/**
 * For table searches by equality on one numerical (long) column.
 * 
 * @author rtorkel
 *
 */
public class EntityByLongColumn extends LazyPreparedStatement
{
    public
    EntityByLongColumn(Connection   connection,
                       EntityTable  table,
                       EntityColumn column,
                       DbContextInterface  context)
    {
        super(connection, table.makeColumnQuery(column), context);
    }
    
    public ResultSet
    run(long value) throws SQLException
    {
        ensureReady();
        setLong(1, value);
        return executeQuery();
    }
}
