/*---------------------------------------------------------------------
 * (C) COPYRIGHT 2014 ALCATEL AUSTRALIA LIMITED
 * 
 * This program contains proprietary information which is a trade secret
 * of ALCATEL AUSTRALIA LIMITED and also is protected under the applicable
 * copyright law. Recipient is to retain this program in confidence and is
 * not permitted to use or make any copy thereof other than as permitted
 * under a written agreement with ALCATEL AUSTRALIA LIMITED.
 *-------------------------------------------------------------------*/
package nokia.rtorkel.robi.db_jdbc._test;

import java.sql.Connection;
import java.sql.SQLException;

import nokia.rtorkel.robi.db_jdbc.DbException;
import nokia.rtorkel.robi.db_jdbc.Equipment2;
import nokia.rtorkel.robi.db_jdbc.DbContextInterface;
import nokia.rtorkel.robi.db_jdbc.DbHandle;
import nokia.rtorkel.robi.db_jdbc.DbHandleImpl;
import nokia.rtorkel.robi.db_jdbc.JdbcManager2;
import nokia.rtorkel.robi.db_jdbc.ObjectFormatter;
import nokia.rtorkel.robi.db_jdbc.PathTermination2;
import nokia.rtorkel.robi.db_jdbc.StdoutDbContext;
import nokia.rtorkel.robi.db_jdbc.TransactionMode;

/**
 * Find path terminations directly from equipment.
 * 
 * @author rtorkel
 *
 */
public class PathTerminationsFromEquipmentTester
{
    public static void
    main(String[] args)
    {
        if (args.length != 4)
        {
            System.out.println("params are url userName password equipmentType");
            System.exit(-1);
        }
        try
        {
            JdbcManager2 manager =
                    new JdbcManager2(args[0], args[1], args[2], "oracle.jdbc.driver.OracleDriver");
            DbContextInterface context = new StdoutDbContext("DB unit test");
            Connection connection = manager.getConnection();
            DbHandle db = new DbHandleImpl(connection, context, TransactionMode.READ_ONLY);
            testRead(db, args[3]);
        }
        catch (Exception e)
        {
            e.printStackTrace(System.out);
        }
    }
    
    public static void
    testRead(DbHandle db,
             String     equipmentType) throws Exception
    {
        System.out.println("Testing equipment type " + equipmentType);
        Equipment2[] equips = db.equipmentsByType(equipmentType);
        if (equips.length == 0)
        {
            System.out.println("Rejected equipment type " + equipmentType + ", no equipment");
        }
        ObjectFormatter formatter = new ObjectFormatter();
        for (int i = 0; i < equips.length; i++)
        {
            System.out.println("Iteration " + (i + 1) + " of " + equips.length);
            if (testEquipment(db, equips[i], formatter))
            {
                return;
            }
        }
    }
    
    public static boolean
    testEquipment(DbHandle      db,
                  Equipment2      equip,
                  ObjectFormatter formatter) throws SQLException, DbException
    {
        System.out.println("Testing " + equip);
        PathTermination2[] pathTerms = db.pathTerminationsByEquipment(equip);
        if (pathTerms.length == 0)
        {
            System.out.println("No path terminations for " + equip);
            return false;
        }
        formatter.incrementLevel();
        equip.format(formatter, "Equipment");
        formatter.appendTitle("Paths to Equipment Terminations");
        formatter.incrementLevel();
        for (PathTermination2 pathTerm : pathTerms)
        {
            pathTerm.formatWithEntities(formatter, null);
        }
        formatter.decrementLevel();
        formatter.decrementLevel();
        System.out.println(formatter.toString());
        return true;
    }
}
