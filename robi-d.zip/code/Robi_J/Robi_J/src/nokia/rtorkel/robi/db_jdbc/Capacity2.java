package nokia.rtorkel.robi.db_jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;

public class Capacity2 extends PrimaryEntity
{
    public
    Capacity2(EntityType entityType,
              long       id,
              String     name,
              DbHandle db)
    {
        super(entityType, id, name, null, null, db);
        // TODO Auto-generated constructor stub
    }
    
    public static final PrimaryEntityTable ENTITY_TABLE =
            new PrimaryEntityTable("capacity", "capacity_id", "capacity_name", null, null);
    
    public static final FeatureTable FEATURE_TABLE =
            new FeatureTable("capacity_features", ENTITY_TABLE);
    
    public static Capacity2
    fromResultSet(DbHandleImpl db,
                  ResultSet      rs) throws SQLException, DbException
    {

        long id = rs.getLong(1);
        String name = rs.getString(2);
        return new Capacity2(EntityType.Capacity, id, name, db);
    }

    @Override
    public PrimaryEntityTable
    entityTable()
    {
        return ENTITY_TABLE;
    }

    @Override
    public FeatureTable
    featureTable()
    {
        // TODO Auto-generated method stub
        return FEATURE_TABLE;
    }

    @Override
    public Feature2[]
    lookUpFeatures() throws SQLException
    {
        return m_db.capacityFeatures(this);
    }

}
