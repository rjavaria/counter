/*---------------------------------------------------------------------
 * (C) COPYRIGHT 2014 ALCATEL AUSTRALIA LIMITED
 * 
 * This program contains proprietary information which is a trade secret
 * of ALCATEL AUSTRALIA LIMITED and also is protected under the applicable
 * copyright law. Recipient is to retain this program in confidence and is
 * not permitted to use or make any copy thereof other than as permitted
 * under a written agreement with ALCATEL AUSTRALIA LIMITED.
 *-------------------------------------------------------------------*/
package nokia.rtorkel.robi.db_jdbc;

/**
 * Contains various call back functions to be called when certain database events
 * happen. Database activity logging is to occur via the call back functions.
 * 
 * @author rtorkel
 *
 */
public interface DbContextInterface extends DbConstants
{
    /**
     * Returns a label describing the database.
     * For example, "IXDB". This is not a callback function.
     * @return
     */
    public String
    dbLabel();
    
    public void
    finishInitialisation(String message);
    
    public void
    enterFunction(String function);
    
    public void
    showResult(String result);
    
    public void
    setParam(String paramMessage);
    
    public void
    commenceQuery(String query);
    
    public void
    finishQuery();
    
    public void
    commenceUpdate(String update);
    
    public void
    finishUpdate(int rowCount);
    
    public void
    commenceCommit();
    
    public void
    finishCommit();
    
    public void
    commenceRollback();
    
    public void
    finishRollback();
}
