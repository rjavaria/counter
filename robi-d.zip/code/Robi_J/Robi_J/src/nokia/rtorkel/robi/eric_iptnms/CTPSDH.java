package nokia.rtorkel.robi.eric_iptnms;

import rasmus_torkel.xml_basic.read.TagNode;

public abstract class CTPSDH extends CTP
{
    public final int _j;
    public final int _k;
    public final int _m;
    public final int _l;
    
    public
    CTPSDH(TagNode                node,
           EricssonIptnmsEntities entities,
           String                 type)
    {
        super(node.nextChildE("CTP"), entities, type);
        String id = node.attributeValueE("Id");
        if (!_isValid)
        {
            entities.putEliminatedEntityByDifferentId(id, "CTPSDH", _id);
        }
        TagNode sdhTpNode = node.nextChildE("CTPSDH.sDHTP");
        TagNode jklmNode = sdhTpNode.nextChildE("DTJKLM");
        _j = EricssonXmlUtil.nextIntFieldE(jklmNode, "DTJKLM.j");
        _k = EricssonXmlUtil.nextIntFieldE(jklmNode, "DTJKLM.k");
        _l = EricssonXmlUtil.nextIntFieldE(jklmNode, "DTJKLM.l");
        _m = EricssonXmlUtil.nextIntFieldE(jklmNode, "DTJKLM.m");
        StringBuilder buf = new StringBuilder(_name.length() + 24);
        if (_j > 0)
        {
            buf.append("/j=");
            buf.append(_j);
        }
        if (_k > 0)
        {
            buf.append("/k=");
            buf.append(_k);
        }
        if (_l > 0)
        {
            buf.append("/l=");
            buf.append(_l);
        }
        if (_m > 0)
        {
            buf.append("/m=");
            buf.append(_m);
        }
        if (_plt == null)
        {
            if (_isValid)
            {
                entities.putEliminatedEntity(id, _type + " AccessPoint", "has no PhLayerTtp");
                _isValid = false;
            }
            _name = "unknownNe/unknownPort/" + buf.toString();
        }
        else
        {
            _name = _plt._name + buf.toString();
        }
        if (_isValid)
        {
            registerApId(id, entities);
        }
    }
}
