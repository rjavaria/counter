/*---------------------------------------------------------------------
 * (C) COPYRIGHT 2014 ALCATEL AUSTRALIA LIMITED
 * 
 * This program contains proprietary information which is a trade secret
 * of ALCATEL AUSTRALIA LIMITED and also is protected under the applicable
 * copyright law. Recipient is to retain this program in confidence and is
 * not permitted to use or make any copy thereof other than as permitted
 * under a written agreement with ALCATEL AUSTRALIA LIMITED.
 *-------------------------------------------------------------------*/
package nokia.rtorkel.robi.db_jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;


/**
 * @author rtorkel
 *
 * Maps identifiers to strings.
 * <p>
 * While this class may well have potential for other applications it was
 * developed to hold the identifiers and names of type tables such as
 * t_equipment, allowing queries involving types to be made without join. 
 */
public class IdStringMapping
{
    public static class IdStringMaplet
    {
        public final long id;
        public final String name;
        public
        IdStringMaplet(long inId,
                       String inName)
        {
            id = inId;
            name = inName;
        }
    }
    private final IdStringMaplet[] myMaplets;
    private final HashMap<Long,String> myIdToString = new HashMap<Long,String>();
    private final HashMap<String,Long> myStringToId = new HashMap<String,Long>();
    
    /**
     * Constructs the mapping from the specified table and columns.
     * @throws SQLException 
     */
    public
    IdStringMapping(DbHandleImpl db,
                    String         tableName,
                    String         idColumnName,
                    String         stringColumnName) throws SQLException
    {
        this(retrieve(db, tableName, idColumnName, stringColumnName));
    }
    
    /**
     * Constructs the mapping where the query has already been made.
     * @param rs  Result of the query, id column must be in first position
     *            and string column in second position.
     * @throws SQLException 
     */
    public
    IdStringMapping(ResultSet rs) throws SQLException
    {
        ArrayList<IdStringMaplet> mapletAl = new ArrayList<IdStringMaplet>();
        try
        {
            while (rs.next())
            {
                long id = rs.getLong(1);
                String string = rs.getString(2);
                IdStringMaplet maplet = new IdStringMaplet(id, string);
                mapletAl.add(maplet);
                Long idObj = new Long(id);
                myIdToString.put(idObj, string);
                myStringToId.put(string, idObj);
            }
            myMaplets = new IdStringMaplet[mapletAl.size()];
            mapletAl.toArray(myMaplets);
        }
        finally
        {
            rs.close();
        }
    }
    
    private static ResultSet
    retrieve(DbHandleImpl db,
             String         tableName,
             String         idColumnName,
             String         stringColumnName) throws SQLException
    {
        String query = makeQuery(tableName, idColumnName, stringColumnName);
        ResultSet rs = db.executeStraightQuery(query);
        return rs;
    }
    
    private static String
    makeQuery(String tableName,
              String idColumnName,
              String stringColumnName)
    {
        return "select " + idColumnName + ",\n"
             + "       " + stringColumnName + "\n"
             + "    from " + tableName + "\n"
             + "    order by " + idColumnName;
    }
    
    /**
     * Maps from id to string.
     */
    public String
    getString(long id) throws DbException
    {
        String string = (String)myIdToString.get(new Long(id));
        return string;
    }
    
    /**
     * Maps from string to id.
     * @throws IxdbException 
     */
    public long
    getId(String s) throws DbException
    {
        Long idObj = (Long)myStringToId.get(s);
        if (idObj == null)
        {
            throw new DbException("Can not map " + s + " to id");
        }
        return idObj.longValue();
    }
}
