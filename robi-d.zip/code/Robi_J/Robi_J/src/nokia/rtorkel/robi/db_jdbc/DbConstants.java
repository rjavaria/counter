/*---------------------------------------------------------------------
 * (C) COPYRIGHT 2014 ALCATEL AUSTRALIA LIMITED
 * 
 * This program contains proprietary information which is a trade secret
 * of ALCATEL AUSTRALIA LIMITED and also is protected under the applicable
 * copyright law. Recipient is to retain this program in confidence and is
 * not permitted to use or make any copy thereof other than as permitted
 * under a written agreement with ALCATEL AUSTRALIA LIMITED.
 *-------------------------------------------------------------------*/
package nokia.rtorkel.robi.db_jdbc;

/**
 * Useful constants.
 * 
 * @author rtorkel
 *
 */
public interface DbConstants
{
    public static final String LINE_END = System.getProperty("line.separator", "\r\n");
}
