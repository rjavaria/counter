/*---------------------------------------------------------------------
 * (C) COPYRIGHT 2015 ALCATEL-LUCENT AUSTRALIA LIMITED
 * 
 * This program contains proprietary information which is a trade secret
 * of ALCATEL-LUCENT AUSTRALIA LIMITED and also is protected under the applicable
 * copyright law. Recipient is to retain this program in confidence and is
 * not permitted to use or make any copy thereof other than as permitted
 * under a written agreement with ALCATEL-LUCENT AUSTRALIA LIMITED.
 *-------------------------------------------------------------------*/
package nokia.rtorkel.robi.db_jdbc.tool;

import java.sql.SQLException;
import java.util.Arrays;

import nokia.rtorkel.robi.db_jdbc.DbException;
import nokia.rtorkel.robi.db_jdbc.Equipment2;
import nokia.rtorkel.robi.db_jdbc.DbLightweightUtil;
import nokia.rtorkel.robi.db_jdbc.DbHandle;
import nokia.rtorkel.robi.db_jdbc.ObjectFormatter;

public class EquipmentsByTypeFinder
{
    public static void
    main(String[] args)
    {
        DbLightweightUtil.checkArgs(args, 4, "url userName password equipmentType");
        try
        {
            DbHandle db = DbLightweightUtil.makeSilentDb(args);
            read(db, args[3]);
        }
        catch (Exception e)
        {
            e.printStackTrace(System.out);
        }
    }
    
    public static void
    read(DbHandle db,
         String     type) throws SQLException, DbException
    {
        Equipment2 equips[] = db.equipmentsByType(type);
        Arrays.sort(equips);
        ObjectFormatter formatter = new ObjectFormatter();
        formatter.incrementLevel();
        for (Equipment2 equip : equips)
        {
            equip.formatWithSubnetworks(formatter, null);
        }
        formatter.decrementLevel();
        System.out.println(formatter);
    }
}
