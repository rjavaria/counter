package nokia.rtorkel.robi.eric_iptnms;

import rasmus_torkel.xml_basic.read.TagNode;

public class XCTP extends CTP
{
    public
    XCTP(TagNode                node,
         EricssonIptnmsEntities entities)
    {
        super(node.nextChildE("CTP"), entities, node._id._relativeName);
        String id = node.attributeValueE("Id");
        if (_isValid)
        {
            registerApId(id, entities);
        }
        else
        {
            entities.putEliminatedEntityByDifferentId(id, node._id._relativeName, _id);
        }
    }
}
