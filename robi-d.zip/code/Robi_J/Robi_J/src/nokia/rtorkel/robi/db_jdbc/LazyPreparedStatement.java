package nokia.rtorkel.robi.db_jdbc;

/*---------------------------------------------------------------------
 * (C) COPYRIGHT 2014 ALCATEL AUSTRALIA LIMITED
 * 
 * This program contains proprietary information which is a trade secret
 * of ALCATEL AUSTRALIA LIMITED and also is protected under the applicable
 * copyright law. Recipient is to retain this program in confidence and is
 * not permitted to use or make any copy thereof other than as permitted
 * under a written agreement with ALCATEL AUSTRALIA LIMITED.
 *-------------------------------------------------------------------*/
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Encapsulates prepared statements for this package. Subclasses should contain a run function.
 * Example:
 * <pre>
 *  public ResultSet
 *  run(String value) throws SQLException
 *  {
 *      ensureReady();
 *      setString(1, value);
 *      return executeQuery();
 *  }
 * </pre>
 * The first and last statement in the above is standard. The middle statement, and there could
 * be more than one, are for setting the parameters in the query.
 * 
 * @author rtorkel
 *
 */
public abstract class LazyPreparedStatement implements DbConstants
{
    private   final Connection        m_connection;
    protected final String            m_sql;
    protected final DbContextInterface       m_context;
    
    protected       PreparedStatement m_statement;
    
    protected
    LazyPreparedStatement(Connection  connection,
                          String      sql,
                          DbContextInterface context)
    {
        m_connection = connection;
        m_sql = sql;
        m_context = context;
    }
    
    protected synchronized void
    ensureReady() throws SQLException
    {
        if (m_statement == null)
        {
            m_statement = m_connection.prepareStatement(m_sql);
        }
    }
    
    protected void
    setString(int    index,
              String value) throws SQLException
    {
        m_context.setParam(index + ", " + value);
        m_statement.setString(index, value);
    }
    
    protected void
    setLong(int  index,
            long value) throws SQLException
    {
        m_context.setParam(index + ", " + value);
        m_statement.setLong(index, value);
    }
    
    protected ResultSet
    executeQuery() throws SQLException
    {
        m_context.commenceQuery(m_sql);
        return m_statement.executeQuery();
    }
}
