package nokia.rtorkel.robi.eric_iptnms;

import java.io.File;

import rasmus_torkel.text.write.IndentingLineSink;
import rasmus_torkel.xml_basic.read.TagNode;
import rasmus_torkel.xml_basic.read.XmlReadOptions;
import rasmus_torkel.xml_basic.read.impl.XmlReader;

public class PhLink extends Link
{
    public
    PhLink(TagNode                node,
           EricssonIptnmsEntities entities) throws EntityNotCreatedException
    {
        super(node.nextChildE("Link"), entities);
        node.nextChildN("PhLink.trace");
        node.nextChildE("PhLink.customerData");
        node.verifyNoMoreChildren();
        entities.putPhLk(this);
    }
    
    public static void
    load(InputFileDirectory     dir,
         EricssonIptnmsEntities entities)
    {
        File neFile = dir.getInputFile("PhLink");
        TagNode rootNode = XmlReader.xmlFileToRoot(neFile, XmlReadOptions.DEFAULT, "NetworkManager");
        rootNode.nextChildE("Version");
        boolean haveSummary = false;
        do
        {
            TagNode level1Node = rootNode.nextChildE();
            if (level1Node._id._relativeName.equals("SDHLink"))
            {
                try
                {
                    new SDHLink(level1Node, entities);
                }
                catch (EntityNotCreatedException e)
                {
                }
            }
            else if (level1Node._id._relativeName.equals("PDHLink"))
            {
                try
                {
                    new PDHLink(level1Node, entities);
                }
                catch (EntityNotCreatedException e)
                {
                }
            }
            else if (level1Node._id._relativeName.equals("PhotonicLink"))
            {
                try
                {
                    new PhotonicLink(level1Node, entities);
                }
                catch (EntityNotCreatedException e)
                {
                }
            }
            else if (level1Node._id._relativeName.equals("Summary"))
            {
                rootNode.verifyNoMoreChildren();
                haveSummary = true;
            }
            else
            {
                throw new RuntimeException("Node with unexpected name: " + level1Node);
            }
        } while (!haveSummary);
    }
    
    public void
    toIndentingLineSink(IndentingLineSink sink)
    {
        sink.writeLine(toShortString());
        sink.incrementLevel();
        sink.writeLine(_fromTp.toString());
        sink.writeLine(_toTp.toString());
        sink.decrementLevel();
    }
}
