package nokia.rtorkel.tools;

import java.io.File;

import rasmus_torkel.text.read.exception.ReadException;
import rasmus_torkel.xml_basic.read.TagNode;
import rasmus_torkel.xml_basic.read.XmlReadOptions;
import rasmus_torkel.xml_basic.read.impl.XmlReader;

public class XmlValidator
{
    public static void
    main(String[] args)
    {
        File xmlFile = new File(args[0]);
        try
        {
            TagNode rootNode = XmlReader.xmlFileToRoot(xmlFile, XmlReadOptions.DEFAULT);
            rootNode.readRest();
            System.out.println(xmlFile + " is valid XML");
        }
        catch (ReadException e)
        {
            System.out.println("Validation failed: " + e);
        }
    }
}
