package nokia.rtorkel.tools;

import rasmus_torkel.text.read.PerlStyleInput;

public class ResultsAnalyser
{
    public static void
    main(String[] args)
    {
        String dirName = "c:/projects/robi/alu_isn/data2/input_rep3_sql";
        PerlStyleInput sql = new PerlStyleInput(dirName + "/term_name.sql");
        PerlStyleInput results = new PerlStyleInput(dirName + "/term_name_sql.out");
        //System.out.println(sql._label + " to " + results._label);
        while (sql.read())
        {
            if (sql.matchC("^select.+\\'(.+)\\'\\;\\s*$"))
            {
                String termName = sql.group(1);
                String status = "";
                while (status.equals(""))
                {
                    if (!results.read())
                    {
                        throw new RuntimeException("Premature end of results");
                    }
                    if (results._.startsWith("no rows"))
                    {
                        status = "absent";
                    }
                    else if (results.matchC("^\\s*(\\d+)\\s+(\\S+)\\s*$"))
                    {
                        String id = results.group(1);
                        String termName2 = results.group(2);
                        if (!termName2.equals(termName))
                        {
                            throw new RuntimeException("termination name sync problem: " + termName + " vs " + termName2);
                        }
                        status = "present, id = " + id;
                    }
                }
                System.out.println(termName + ": " + status);
            }
        }
    }
}
