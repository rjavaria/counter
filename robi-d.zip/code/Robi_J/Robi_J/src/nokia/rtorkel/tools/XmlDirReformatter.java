package nokia.rtorkel.tools;

import java.io.File;

import rasmus_torkel.xml_basic.tool.XmlReformatter;

public class XmlDirReformatter
{
    public static void
    main(String[] args)
    {
        if (args.length != 2)
        {
            throw new RuntimeException("Need exactly two args, dirWithUnformattedXml and dirForFormattedXml");
        }
        File uDir = new File(args[0]);
        File fDir = new File(args[1]);
        File[] uFiles = uDir.listFiles();
        for (File uFile : uFiles)
        {
            String relName = uFile.getName();
            File fFile = new File(fDir, relName);
            System.out.println("Doing " + uFile + " to " + fFile);
            XmlReformatter.reformat(uFile, fFile);
        }
        System.out.println("Done");
    }
}
