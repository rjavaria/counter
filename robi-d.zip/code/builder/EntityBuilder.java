package com.alu.oss.mdf.rda.ldma.builder;

public interface EntityBuilder<T> {
	public T build(ILdmaContext context);
}






