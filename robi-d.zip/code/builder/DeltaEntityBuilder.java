package com.alu.oss.mdf.rda.ldma.builder;

import java.util.Map;

import com.alu.oss.mdf.rda.ldma.reader.DataFileMap;
import com.alu.oss.mdf.rda.metadata.delta.DeltaEntity;
import com.alu.oss.mdf.rda.metadata.delta.DeltaInsertEntity;

public abstract class DeltaEntityBuilder implements EntityBuilder<DeltaEntity> {
	@Override
	public DeltaEntity build(ILdmaContext context) {

		DeltaEntity entity = new DeltaEntity();
		
		if(context.getOperation().equals("insert"))
		{
			buildInsertEntities(context);
		}
		/*
		//loop
		//{
		EntityBuilder<DeltaInsertEntity> builder = new Level2DeltaInsertEntityBuilder();
		DeltaInsertEntity deltaInsertEntity = builder.build(filesMap); //filesMap can be - new object with data required..
		
		entity.addDeltaInsertEntity(deltaInsertEntity);
		
		//}*/
		
		return entity;
	}
	
	protected abstract DeltaEntity buildInsertEntities(ILdmaContext context);
}
