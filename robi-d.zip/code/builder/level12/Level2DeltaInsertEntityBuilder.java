package com.alu.oss.mdf.rda.ldma.builder.level12;

import java.util.Map;

import com.alu.oss.mdf.rda.ldma.builder.DeltaInsertEntityBuilder;
import com.alu.oss.mdf.rda.ldma.builder.ILdmaContext;
import com.alu.oss.mdf.rda.ldma.reader.DataFileMap;
import com.alu.oss.mdf.rda.metadata.delta.DeltaInsertEntity;

public class Level2DeltaInsertEntityBuilder extends DeltaInsertEntityBuilder {
	@Override
	public DeltaInsertEntity build(ILdmaContext context) {
		// TODO Auto-generated method stub
		return null;
	}
}
