package com.alu.oss.mdf.rda.ldma.builder.level12;

import java.util.Map;

import com.alu.oss.mdf.rda.ldma.builder.ILdmaContext;
import com.alu.oss.mdf.rda.ldma.reader.DataFileMap;

public class L12LdmaContext implements ILdmaContext {

	private String operation;
	
	@Override
	public String getOperation() {
		// TODO Auto-generated method stub
		return operation;
	}

	@Override
	public String getFileLocation() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	public void setOperation(String operation) {
		this.operation = operation; 
	}

	@Override
	public String setOperation() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<String, DataFileMap> getFileMap() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setFileMap(Map<String, DataFileMap> fileMap) {
		// TODO Auto-generated method stub
		
	}

}
