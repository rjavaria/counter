package com.alu.oss.mdf.rda.ldma.builder.level12;

import java.util.Iterator;
import java.util.Map;

import com.alu.oss.mdf.rda.ldma.builder.DeltaEntityBuilder;
import com.alu.oss.mdf.rda.ldma.builder.ILdmaContext;
import com.alu.oss.mdf.rda.ldma.reader.DataFileMap;
import com.alu.oss.mdf.rda.metadata.delta.DeltaEntity;
import com.alu.oss.mdf.rda.metadata.delta.DeltaInsertEntity;

public class Level2DeltaEntityBuilder extends DeltaEntityBuilder {

	@Override
	protected DeltaEntity buildInsertEntities(ILdmaContext context) {
		// TODO Auto-generated method stub
		
		DeltaEntity entity = new DeltaEntity();
		
		
		//loop NGSNG01-ODF-1
		//NGSNG01-ODF-2
		//NGSNG01-ODF-3
		//NGSNG01-ODF-4
		Level2DeltaInsertEntityBuilder builder = new Level2DeltaInsertEntityBuilder();
		DeltaInsertEntity deltaInsertEntity = builder.build(context);
		entity.addDeltaInsertEntity(deltaInsertEntity);
		

		return entity;
	}
}
