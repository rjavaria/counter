package com.alu.oss.mdf.rda.ldma.builder;

import java.util.Map;

import com.alu.oss.mdf.rda.ldma.reader.DataFileMap;

public interface ILdmaContext {
	public String getOperation();
	public String setOperation();
	public String getFileLocation();
	public Map<String, DataFileMap> getFileMap();
	public void setFileMap(Map<String, DataFileMap> fileMap);	
}
