package com.alu.oss.mdf.rda.ldma.builder;

import java.util.Map;

import com.alu.oss.mdf.rda.ldma.reader.DataFileMap;
import com.alu.oss.mdf.rda.metadata.delta.DeltaInsertEntity;

public abstract class DeltaInsertEntityBuilder implements EntityBuilder<DeltaInsertEntity> {


}
