package com.alu.oss.mdf.rda.ldma.builder;

import java.util.Map;

import com.alu.oss.mdf.rda.ldma.builder.level12.Level2DeltaEntityBuilder;
import com.alu.oss.mdf.rda.ldma.reader.DataFileMap;
import com.alu.oss.mdf.rda.metadata.delta.DeltaEntity;
import com.alu.oss.mdf.rda.metadata.sure.EntityType;

public class LdmaModelFactory {
	public DeltaEntity create(String levelType, Map<String, DataFileMap> filesMap) {
		
		if(levelType.equals("Level2")) {
			EntityBuilder<DeltaEntity> entity = new Level2DeltaEntityBuilder();
			return entity.build(filesMap);
		}
		//else if()
		return null;
	}
}
