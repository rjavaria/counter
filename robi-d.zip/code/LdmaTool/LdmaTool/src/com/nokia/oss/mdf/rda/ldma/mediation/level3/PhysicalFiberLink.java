package com.nokia.oss.mdf.rda.ldma.mediation.level3;

import java.util.Map;

import com.nokia.oss.mdf.rda.ldma.mediation.entity.EntityElement;

public class PhysicalFiberLink extends EntityElement {

	public PhysicalFiberLink(Map<String, String> rowMap) {
		super(rowMap);
	}

	@Override
	protected String constructName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected String constructType() {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	protected String constructDiscoveredName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected Map<String, String> constructFeatures() {
		// TODO Auto-generated method stub
		return null;
	}
}
