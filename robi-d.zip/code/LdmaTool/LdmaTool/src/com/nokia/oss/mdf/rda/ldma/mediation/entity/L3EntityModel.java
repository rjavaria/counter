package com.nokia.oss.mdf.rda.ldma.mediation.entity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.nokia.oss.mdf.rda.ldma.common.LdmaConstants;
import com.nokia.oss.mdf.rda.ldma.mediation.level3.PhysicalFiberCoreLink;
import com.nokia.oss.mdf.rda.ldma.reader.DataFileMap;

public class L3EntityModel implements IEntityComponent {

	//private String siteCode;
	private String linkId;
	
	private Map<String, List<EntityElement>> component = new HashMap<>();
	private List<EntityElement> phyFiberCoreList = new ArrayList<>();
//	private List<EntityElement> phyFiberList = new ArrayList<>();
//	private List<EntityElement> muxOdfList = new ArrayList<>();

	public L3EntityModel(String linkId) {
		this.linkId = linkId;
		component.put(LdmaConstants.Level3EntityType.PHY_FIBER_CORE_LINK, phyFiberCoreList);
		//component.put(LdmaConstants.Level3EntityType.PHY_FIBER_LINK, phyFiberList);
		//component.put(LdmaConstants.Level3EntityType.MUX_ODF_LINK, muxOdfList);
	}
	
	@Override
	public void createAll(Map<String, DataFileMap> fileMaps) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void createAll(DataFileMap fileMap) {
		int numRows = fileMap.getNumberOfRows();		
		for(int i=0; i<numRows; i++) {
			Map<String, String> rowMap = fileMap.getRow(LdmaConstants.ROW+(i+1));
			String linkId = rowMap.get(LdmaConstants.Level3PHYSICALCOREFILE.COLUMN_A);
			if(this.linkId.equals(linkId)) {
				create(rowMap);
			}
		}
	}

	@Override
	public void create(Map<String, String> rowMap) {
		EntityElement phyFiberCore = new PhysicalFiberCoreLink(rowMap);
		phyFiberCore.add(phyFiberCoreList);
		
//		EntityElement odfTray = new ODFTray(rowMap);
//		odfTray.add(trayList);
//		
//		String numPorts = rowMap.get(LdmaConstants.Level12FILE1.COLUMN_E);
//		int portCounts = Integer.parseInt(numPorts);
//		for(int i=1; i<=portCounts; i++) {
//			EntityElement odfTrayPort = new ODFTrayPort(rowMap, String.valueOf(i));
//			odfTrayPort.add(trayPortList);
//		}
	}
	
	@Override
	public Map<String, List<EntityElement>> getAll() {
		return component;
	}
	
	@Override
	public String printComponent(String name) {
		StringBuilder builder = new StringBuilder();
		
		Set<String> keys = component.keySet();
		Iterator<String> iter = keys.iterator();
		builder.append("====== "+name +" ======\n");
		while(iter.hasNext())
		{
			String key = iter.next();
			List<EntityElement> entites = component.get(key);
			Iterator<EntityElement> iterEntites = entites.iterator();
			while(iterEntites.hasNext()) {
				EntityElement entity = iterEntites.next();
				builder.append(entity.toString());
			}
		}
		builder.append("=====================");
		return builder.toString();
	}
	
	public String getLinkId() {
		return linkId;
	}

	public void setLinkId(String linkId) {
		this.linkId = linkId;
	}

	public List<EntityElement> getPhyFiberCoreList() {
		return phyFiberCoreList;
	}

	public void setPhyFiberCoreList(List<EntityElement> phyFiberCoreList) {
		this.phyFiberCoreList = phyFiberCoreList;
	}
}

