package com.nokia.oss.mdf.rda.ldma.builder;

import com.alu.oss.mdf.rda.metadata.delta.DeltaEntity;
import com.nokia.oss.mdf.rda.ldma.builder.level12.Level12DeltaEntityBuilder;
import com.nokia.oss.mdf.rda.ldma.builder.level3.Level3DeltaEntityBuilder;
import com.nokia.oss.mdf.rda.ldma.common.LdmaConstants;
import com.nokia.oss.mdf.rda.ldma.common.LdmaException;
import com.nokia.oss.mdf.rda.ldma.context.ILdmaContext;

public class LdmaModelFactory {
	private static LdmaModelFactory instance;
	
	private LdmaModelFactory() {
		
	}
	
	public static LdmaModelFactory getInstance()
	{
		if(null == instance)
			instance = new LdmaModelFactory();
		return instance;
	}
	
	public DeltaEntity create(ILdmaContext context) 
		               throws LdmaException {
		final String METHOD = "LdmaModelFactory::create#";
		System.out.println(METHOD+"Entering..");
		
		EntityBuilder<DeltaEntity> entity = null;
		if(LdmaConstants.LevelType.LEVEL12.equals(context.getLevel())) {
			entity = new Level12DeltaEntityBuilder();
		}
		else if(LdmaConstants.LevelType.LEVEL3.equals(context.getLevel())) {
			entity = new Level3DeltaEntityBuilder();
			
		}
		else {
			String message = "Unsupported level : "+context.getLevel();
			System.out.println(METHOD+message);
            throw new LdmaException(message);
		}
		return entity.build(context);
	}
}
