package com.nokia.oss.mdf.rda.ldma.builder.level3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.alu.oss.mdf.rda.metadata.delta.DeltaEntity;
import com.alu.oss.mdf.rda.metadata.delta.DeltaInsertEntity;
import com.nokia.oss.mdf.rda.ldma.builder.DeltaEntityBuilder;
import com.nokia.oss.mdf.rda.ldma.builder.EntityBuilder;
import com.nokia.oss.mdf.rda.ldma.builder.level3.Level3DeltaInsertEntityBuilder;
import com.nokia.oss.mdf.rda.ldma.common.LdmaConstants;
import com.nokia.oss.mdf.rda.ldma.common.LdmaException;
import com.nokia.oss.mdf.rda.ldma.context.ILdmaContext;
import com.nokia.oss.mdf.rda.ldma.mediation.entity.EntityElement;
import com.nokia.oss.mdf.rda.ldma.mediation.entity.IEntityComponent;
import com.nokia.oss.mdf.rda.ldma.mediation.entity.L3EntityModel;
import com.nokia.oss.mdf.rda.ldma.reader.DataFileMap;

public class Level3DeltaEntityBuilder extends DeltaEntityBuilder {
	@Override
	protected DeltaEntity createForInsert(ILdmaContext context)
			throws LdmaException {

		final String METHOD = "Level3DeltaEntityBuilder::createForInsert#";
		System.out.println(METHOD + "Entering...");
		DeltaEntity deltaEntity = new DeltaEntity();
		EntityBuilder<DeltaInsertEntity> insertEntityBuilder = new
				Level3DeltaInsertEntityBuilder();
		DataFileMap fileMap = getLevel3PhysicalCoreFile(context);
		
		List<String> linkIds = getAllLinkIds(context);
		
		//System.out.println(METHOD + "All Link IDs : "+linkIds);
		Iterator<String> iter = linkIds.iterator();
		while(iter.hasNext()) {
			String linkId = iter.next();
			IEntityComponent l3Model = new L3EntityModel(linkId);
			l3Model.createAll(fileMap);
			
			System.out.println(l3Model.printComponent(linkId));
			
			Map<String, List<EntityElement>> linkComponent = l3Model.getAll();
			
			Set<String> keys = linkComponent.keySet();
			Iterator<String> iterComponents = keys.iterator();
			while(iterComponents.hasNext()) {
				String key = iterComponents.next();
				List<EntityElement> entites = linkComponent.get(key);
				Iterator<EntityElement> iterEntites = entites.iterator();
				while(iterEntites.hasNext()) {
					context.setCurrentEntity(iterEntites.next());
					DeltaInsertEntity deltaInsertEntity = insertEntityBuilder.build(context);
					deltaEntity.addDeltaInsertEntity(deltaInsertEntity);
				}
			}
		}
		return deltaEntity;
	}
	
	private List<String> getAllLinkIds(ILdmaContext context) {
		
		DataFileMap fileMap = getLevel3PhysicalCoreFile(context);
		
		int numRows = fileMap.getNumberOfRows();
		List<String> linkIdList = new ArrayList<>();
		for(int i=0; i<numRows; i++) {
			Map<String, String> rowMap = fileMap.getRow(LdmaConstants.ROW+(i+1));
			String linkId = rowMap.get(LdmaConstants.Level3PHYSICALCOREFILE.COLUMN_A);
			if(!linkIdList.contains(linkId))
				linkIdList.add(linkId);
		}
		
		return linkIdList;
	}
	
	
	private DataFileMap getLevel3PhysicalCoreFile(ILdmaContext context) {
		Map<String, DataFileMap> filesMap = context.getFilesMap();
		
		Set<String> keys = filesMap.keySet();		
		Iterator<String> iter = keys.iterator();
		String key = iter.next();
		
		return filesMap.get(key);
	}
}

