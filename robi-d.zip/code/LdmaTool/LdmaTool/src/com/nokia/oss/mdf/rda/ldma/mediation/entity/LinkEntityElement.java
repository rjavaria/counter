package com.nokia.oss.mdf.rda.ldma.mediation.entity;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public abstract class LinkEntityElement {
	
	private Map<String, String> rowData;
	private String name;
	private String discoveredName;
	private String id;
	private String type;
	Map<String, String> features = new HashMap<String, String>();
	
	public LinkEntityElement(Map<String, String> rowMap) {
		this.rowData = rowMap;
		this.name = constructName();
		this.type = constructType();
		this.discoveredName = constructDiscoveredName();
		this.features = constructFeatures();
	}
	
	public LinkEntityElement(Map<String, String> rowMap, String id) {
		this.rowData = rowMap;
		this.id = id;
		this.name = constructName();
		this.type = constructType();
		this.discoveredName = constructDiscoveredName();
		this.features = constructFeatures();
	}
	
	protected abstract String constructName(); 
	protected abstract String constructDiscoveredName();
	protected abstract String constructType();
	protected abstract Map<String, String> constructFeatures();
		
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Map<String, String> getFeatures() {
		return features;
	}

	public void setFeatures(Map<String, String> features) {
		this.features = features;
	}

	public void setRowData(Map<String, String> rowData) {
		this.rowData = rowData;
	}

	protected Map<String, String> getRowData() {
		return rowData;
	}
	
	public String getDiscoveredName() {
		return discoveredName;
	}

	public void setDiscoveredName(String name) {
		this.discoveredName = name;
	}
	
	protected void add(List<LinkEntityElement> list) {
		Iterator<LinkEntityElement> iter = list.iterator();
		
		boolean bExist = false;
		
		while(iter.hasNext()) {
			LinkEntityElement entity = iter.next();
			String entityName = entity.getName();
			if(this.name.equals(entityName)) {
				bExist = true;
				break;
			}
		}
		
		if(!bExist) {
			list.add(this);
		}
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("{");
		builder.append("name : "+this.name);
		builder.append(", ");
		builder.append("type : "+this.type);
		builder.append(", ");
		builder.append("discoveredName : "+this.discoveredName);
		builder.append("}\n");
		return builder.toString();
	}
}


