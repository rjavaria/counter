package com.nokia.oss.mdf.rda.ldma.common;

public class LdmaUtils {
	/*
	
	public static String getSitecode1FromLink(String linkId){
		//SYBLG04-SYSDR01-1-F_Core 1-48-Tube-34
		String sitecode1;
		String[] tokens = linkId.split("-");
		return sitecode1 = tokens[0];			
	}
	
	public static String getSitecode2FromLink(String linkId){
		//SYBLG04-SYSDR01-1-F_Core 1-48-Tube-34
		String sitecode2;
		String[] tokens = linkId.split("-");
		return sitecode2 = tokens[1];			
	}
	
	public static String getSite1ODFFromLink(String linkId){
		//SYBLG04-SYSDR01-1-F_Core 1-48-Tube-34
		String sitecode2;
		String[] tokens = linkId.split("-");
		return sitecode2 = tokens[1];			
	}
	
	public static String getSite2ODFFromLink(String linkId){
		//SYBLG04-SYSDR01-1-F_Core 1-48-Tube-34
		String sitecode2;
		String[] tokens = linkId.split("-");
		return sitecode2 = tokens[1];			
	}
	
	public static String getSite1ODFTrayFromLink(String linkId){
		//SYBLG04-SYSDR01-1-F_Core 1-48-Tube-34
		String sitecode2;
		String[] tokens = linkId.split("-");
		return sitecode2 = tokens[1];			
	}
	
	public static String getSite1ODFTrayPortFromLink(String linkId){
		//SYBLG04-SYSDR01-1-F_Core 1-48-Tube-34
		String sitecode2;
		String[] tokens = linkId.split("-");
		return sitecode2 = tokens[1];			
	}
	
*/
}
