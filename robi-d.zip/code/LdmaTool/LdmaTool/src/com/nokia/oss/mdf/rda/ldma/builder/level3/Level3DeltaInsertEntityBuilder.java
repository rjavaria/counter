package com.nokia.oss.mdf.rda.ldma.builder.level3;

import com.alu.oss.mdf.rda.metadata.delta.DeltaInsertEntity;
import com.alu.oss.mdf.rda.metadata.sure.Entity;
import com.alu.oss.mdf.rda.metadata.sure.LinkEntity;
import com.alu.oss.mdf.rda.metadata.sure.TerminationEntity;
import com.nokia.oss.mdf.rda.ldma.builder.EntityBuilder;
import com.nokia.oss.mdf.rda.ldma.common.LdmaConstants;
import com.nokia.oss.mdf.rda.ldma.common.LdmaException;
import com.nokia.oss.mdf.rda.ldma.context.ILdmaContext;
import com.nokia.oss.mdf.rda.ldma.mediation.entity.EntityElement;
import com.nokia.oss.mdf.rda.ldma.mediation.entity.LinkEntityElement;
import com.nokia.oss.mdf.rda.ldma.mediation.level3.PhysicalFiberCoreLink;

public class Level3DeltaInsertEntityBuilder  implements EntityBuilder<DeltaInsertEntity> {
	@Override
	public DeltaInsertEntity build(ILdmaContext context) throws LdmaException {
		
		EntityElement entityElement = context.getCurrentEntity();
		String entityType = entityElement.getType();
		if(LdmaConstants.Level3EntityType.PHY_FIBER_CORE_LINK.equals(entityType) ) {
			LinkEntity entity = new LinkEntity();
			entity.setName(entityElement.getName());
			entity.setType(entityElement.getType());
			entity.setDiscoveredName(entityElement.getDiscoveredName());
			entity.setaTermName(((PhysicalFiberCoreLink)entityElement).getaTerminationName());
			entity.setzTermName(((PhysicalFiberCoreLink)entityElement).getzTerminationName());
			return new DeltaInsertEntity(entity);
		}
//		else if(LdmaConstants.Level12EntityType.ODF_TRAYPORT.equals(entityType) ||
//		    LdmaConstants.Level12EntityType.ODF_PORT.equals(entityType)) {
//			Entity entity = new TerminationEntity();
//			entity.setName(entityElement.getName());
//			entity.setType(entityElement.getType());
//			return new DeltaInsertEntity(entity);
//		}
		else {
			String message = "Could not build DeltaInsertEntity. Invalid Level-3 entity type : "+entityType;
			throw new LdmaException(message);
		}
	}
}
