package com.alu.oss.mdf.rda.ldma.common;

public class MappingException extends Exception
{
	private static final long serialVersionUID = 1L;

	public MappingException()
    {
        super();
    }

    public MappingException(String s)
    {
        super(s);
    }
}
