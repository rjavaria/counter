package com.alu.oss.mdf.rda.ldma.builder.entity;

import java.util.HashMap;
import java.util.Map;

public class EntityElement {
	
	private String name;
	private String type;
	Map<String, String> features = new HashMap<String, String>();
	
	
	
	//Later  LInk Entity Element extends Entity Element

}
