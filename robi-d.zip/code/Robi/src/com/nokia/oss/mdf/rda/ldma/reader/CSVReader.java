package com.alu.oss.mdf.rda.ldma.reader;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CSVReader {
	
	public DataFileMap readFile(String fileName) {
		
		DataFileMap dataFMap = new DataFileMap();
		
		try {
			BufferedReader reader = new BufferedReader(new FileReader(fileName));
			
			String line = "";
			 try {
				int linenum = 0;
				List<String> columnList = new ArrayList<>();
				while ((line = reader.readLine()) != null) 
				 {
					String key = "row" + linenum;
					line.trim();
					if(linenum == 0) {
						String[] headers = line.split(",");
						for(String header : headers) {
							columnList.add(header);
						}
					}
					else {
						dataFMap.addRow(key, columnList, line);
			  		}
					linenum ++;
				 }
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return dataFMap;
	}
}
	
