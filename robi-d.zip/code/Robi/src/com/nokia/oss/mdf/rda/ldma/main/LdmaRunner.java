package com.alu.oss.mdf.rda.ldma.main;

import java.io.FileNotFoundException;

import com.alu.oss.mdf.rda.ldma.common.MappingException;
import com.alu.oss.mdf.rda.ldma.server.ILdmaInvoker;
import com.alu.oss.mdf.rda.ldma.server.LdmaInvokerImpl;
import com.alu.oss.mdf.rda.metadata.delta.DeltaEntity;
import com.alu.oss.mdf.rda.metadata.delta.DeltaInsertEntity;
import com.alu.oss.mdf.rda.metadata.sure.EquipmentEntity;
import com.alu.oss.mdf.rda.metadata.sure.TerminationEntity;

public class LdmaRunner {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ILdmaInvoker invoker = new LdmaInvokerImpl();
		
		//delta format - insert, update - mixed opeations?
		
		///insert - Chassis
		
		//-entityName "ODFTrayPort" -operation "Insert" 
		
		
		//String operation = args[0];
		String operation = "insert";
		//String srcFileLocation = args[1];
		String srcFileLocation = "c:/Users/ddhawan/Desktop/Robi/LDMA_Files/CSV";
		//String entityName = args[2];
		//String entityName = "ODFTrayPort";
		//String entityName = "EquipmentOrTermination";
		//String entityName = "Link";
		String entityName = "Equipment";
		
		//Termination
//		TerminationEntity termEntity = new TerminationEntity();
//		termEntity.setName("NGSNG01-ODF-1/TP");
//		termEntity.setType("ODF Fiber Link Port");
//		
//		DeltaInsertEntity insertEntity = new DeltaInsertEntity();
//		
//		insertEntity.setTerminationEntity(termEntity);
//		
//		DeltaEntity entity = new DeltaEntity();
//		entity.addDeltaInsertEntity(insertEntity);
//		
//		//Equipment -ODF Chassis
//		EquipmentEntity equipEntity = new EquipmentEntity();
//		String equipName = "NGSNG01-ODF-1";
//		equipEntity.setName(equipName);
//		
		//do the marshalling to build delta xml..
		
		try {
			invoker.execute(operation, srcFileLocation, entityName);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace(); 
		} catch (MappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
