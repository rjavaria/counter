package com.alu.oss.mdf.rda.ldma.server;

import java.io.FileNotFoundException;

import com.alu.oss.mdf.rda.ldma.common.MappingException;

public interface ILdmaInvoker {
	public void execute(String operation, String srcFileLocation, String entityName)	
			throws FileNotFoundException, MappingException;
}
