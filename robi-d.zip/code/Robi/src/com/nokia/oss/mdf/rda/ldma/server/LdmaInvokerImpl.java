package com.alu.oss.mdf.rda.ldma.server;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

import com.alu.oss.mdf.rda.ldma.builder.ILdmaContext;
import com.alu.oss.mdf.rda.ldma.builder.LdmaModelFactory;
import com.alu.oss.mdf.rda.ldma.builder.level12.L12LdmaContext;
import com.alu.oss.mdf.rda.ldma.common.MappingException;
import com.alu.oss.mdf.rda.ldma.mapping.MappingBean;
import com.alu.oss.mdf.rda.ldma.mapping.MappingEngine;
import com.alu.oss.mdf.rda.ldma.reader.CSVReader;
import com.alu.oss.mdf.rda.ldma.reader.DataFileMap;

public class LdmaInvokerImpl implements ILdmaInvoker {

	@Override
	public void execute(String operation, String srcFileNameLocation,
			String entityName) throws FileNotFoundException {

		/*
		entityName = ALL
		entityName = Link
		*/
		String dirName = "c:/Users/ddhawan/Desktop/Robi/LDMA_Files/CSV";
		String[] fileList = {"c:/Users/ddhawan/Desktop/Robi/LDMA_Files/CSV/Site with ODF Tray Port Into.csv"};
		
//	dirName + "Physicalfiberlink.csv", 
//		 dirName + "Physical Fiber core info.csv",		
		//"Physical Fiber HH info"
//							 "MUX -ODF sample data"
//							 "Mux Link sample data Report"
//							 "LDMA _Feedback_04012015"};
		
		Map<String, DataFileMap> filesMap = new HashMap<String, DataFileMap>();

		//get all files from srcFileNameLocation
		for(String file : fileList) {
			CSVReader reader = new CSVReader();
			// Reading the CSV file
			DataFileMap fileMap = reader.readFile(file);
				 
			filesMap.put(file, fileMap);

			ILdmaContext l12Context = new L12LdmaContext();
            l12Context.setFileMap(filesMap);
			
			LdmaModelFactory.getInstance().create("Level12", filesMap);
						
			System.out.println();
		}
		
		//Read the mapping file
		//Don't have to use mapping
//		Map<String, MappingBean> mappingList = MappingEngine.getInstance().parseXml(new FileInputStream(new File("C:\\Users\\ddhawan\\Desktop\\Robi\\Code\\2904\\Robi\\src\\ldmamapping.xml")));
//		
//		MappingBean linkMappingBean = mappingList.get("LINK");
//		
//		Map<String, String> mappedAttr = linkMappingBean.getMapAttrs();
		
		
		//MappingEngine.getInstance().map 
		
		
		//OutputStream output = reader.read(io);
		
		//Map excel o/p to MDF delta format
		
		
		//Build the MDF delta objects from mapping
		
		//Generate xml based on operation name
		
	}
}
