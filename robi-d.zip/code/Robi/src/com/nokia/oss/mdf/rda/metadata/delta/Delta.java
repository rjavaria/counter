package com.alu.oss.mdf.rda.metadata.delta;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlTransient;

import com.alu.oss.mdf.rda.metadata.RDAMetadata;
import com.alu.oss.mdf.rda.metadata.discovery.ReconciliationGroup;

@XmlTransient
public abstract class Delta implements RDAMetadata, Comparable<Delta>
{

	private static final long serialVersionUID = 8912039217025251745L;

	@XmlElement(name="DeltaSequenceNumber", required=false)
	protected String sequence;

	@XmlElement(name="ReconGroup", required=false)
	protected ReconciliationGroup reconciliationGroup;
	
	@XmlElementWrapper(name="ReconParents", required=false)
	@XmlElement(name="ReconParent", required=false)
	protected List<String> reconParents;
	
	@XmlElementWrapper(name="Roots", required=false)
	@XmlElement(name="Root", required=false)
	protected List<String> roots;
	
	public String getSequence() {
		return sequence;
	}

	public void setSequence(String sequence) {
		this.sequence = sequence;
	}

	public int compareTo(Delta o) 
	{
		try
		{
			int sequence_this = Integer.parseInt(getSequence());
			int sequence_other = Integer.parseInt(o.getSequence());
		
			return sequence_this - sequence_other;
		}catch(NumberFormatException e)
		{
			return 0;
		}
	}
	
	public List<String> getRootEntityName()
	{
		return roots==null ? roots=new ArrayList<String>(): roots;
	}
	
	public List<String> getReconParentEntityName()
	{
		return reconParents == null ? reconParents=new ArrayList<String>() : reconParents;
	}
	
	public abstract String getEntityName();
	
}
