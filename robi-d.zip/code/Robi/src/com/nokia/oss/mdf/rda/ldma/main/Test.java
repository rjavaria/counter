package com.alu.oss.mdf.rda.ldma.main;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		char ch = 'A';
		System.out.println("val : "+ch);
		ch++;
		System.out.println("val : "+ch);
		
		/*
		 * Read first line of CSV and get header info
		 * Get column name - A,B,C
		 * Create list of column names - A,B,C
		 * for (each line in CSV)
		 * {
		 * 		String[] tokens = line.split(',');
		 *      int i = 0;
		 *      String key = "rec"+i;
		 *      int j =0;
		 *      for(String token : tokens)
		 *      {
		 *      	rowMap.put(colList(j), token);
		 *          j++;
		 *      }
		 *      fullMap.put(key, rowMap);
		 *      i++;
		 * }
		 */
		
	}

}
