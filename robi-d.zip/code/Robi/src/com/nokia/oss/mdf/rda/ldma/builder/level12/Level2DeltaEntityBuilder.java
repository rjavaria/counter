package com.alu.oss.mdf.rda.ldma.builder.level12;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.alu.oss.mdf.rda.ldma.builder.DeltaEntityBuilder;
import com.alu.oss.mdf.rda.ldma.builder.ILdmaContext;
import com.alu.oss.mdf.rda.ldma.builder.entity.EntityElement;
import com.alu.oss.mdf.rda.ldma.reader.DataFileMap;
import com.alu.oss.mdf.rda.metadata.delta.DeltaEntity;
import com.alu.oss.mdf.rda.metadata.delta.DeltaInsertEntity;

public class Level2DeltaEntityBuilder extends DeltaEntityBuilder {

	@Override
	protected DeltaEntity buildInsertEntities(ILdmaContext context) {
		// TODO Auto-generated method stub
		
		DeltaEntity entity = new DeltaEntity();
		
		
		//loop NGSNG01-ODF-1
		//NGSNG01-ODF-2
		//NGSNG01-ODF-3
		//NGSNG01-ODF-4
		
		Map<String, DataFileMap> filesMap = context.getFileMap();
		
		//DataFileMap fileMap = fileMap.get("fileName");
		
		Set<String> iter = filesMap.keySet();		
		String fileName = iter.iterator().next();
		DataFileMap fileMap = filesMap.get(fileName);
		
		int rows = fileMap.getNumberOfRows();
		
		for(int i=0; i<rows; i++) {
			Map<String, String> rowMap = fileMap.getRow("row"+i);
			
			String siteCode = rowMap.get("Site Code");	
			String ODFNumber = rowMap.get("ODF Number");
			String name = (siteCode +"-ODF-"+ ODFNumber);
			String type = "ODF Chassis";
			String locationName = siteCode;
			String networkName = "PASSIVE.net"; //need to put this in config file
			
			List<String> chassisList = new ArrayList<>();	
			
			chassisList.add(name);
		
			EntityElement entityElement = new EntityElement();
			entityElement= buildChasis(rowMap);
			
		}
		
		
		
		Level2DeltaInsertEntityBuilder builder = new Level2DeltaInsertEntityBuilder();
		DeltaInsertEntity deltaInsertEntity = builder.build(context);
		entity.addDeltaInsertEntity(deltaInsertEntity);

		return entity;
	}
	
	public EntityElement buildChasis(Map rowMap)
	{
		EntityElement entityElement = new EntityElement();
		
		//make unique chassi obj
		return entityElement;
	}
}
