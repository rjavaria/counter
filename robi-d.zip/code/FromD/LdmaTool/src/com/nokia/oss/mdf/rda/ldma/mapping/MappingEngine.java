package com.nokia.oss.mdf.rda.ldma.mapping;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

import com.nokia.oss.mdf.rda.ldma.common.MappingException;

public class MappingEngine {
	
	private static MappingEngine instance = new MappingEngine();
    /**
     * @return the instance
     */
    public static MappingEngine getInstance()
    {
        return instance;
    }
    
    /**
     * 
     * @param in
     * @return
     * @throws MappingException
     */
	public Map<String, MappingBean> parseXml(InputStream in) 
			throws MappingException {
		Map<String, MappingBean> allMappings = null;
		
		try {
			MappingHandler handler = new MappingHandler();
			
			XMLReader parser = XMLReaderFactory.createXMLReader();
			
			parser.setContentHandler(handler);
			
			InputSource source = new InputSource(in);
			
			parser.parse(source);
			
			allMappings = handler.getMappingHolder();
		}
		catch (SAXException e) {
            e.printStackTrace();
            throw new MappingException(e.getMessage());
        } catch (IOException e) {
            e.printStackTrace();
            throw new MappingException(e.getMessage());
        } finally {
 
        }
		return allMappings;
	}	
}
