package com.nokia.oss.mdf.rda.ldma.builder.level12;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.alu.oss.mdf.rda.metadata.delta.DeltaEntity;
import com.alu.oss.mdf.rda.metadata.delta.DeltaInsertEntity;
import com.nokia.oss.mdf.rda.ldma.builder.DeltaEntityBuilder;
import com.nokia.oss.mdf.rda.ldma.builder.EntityBuilder;
import com.nokia.oss.mdf.rda.ldma.common.LdmaConstants;
import com.nokia.oss.mdf.rda.ldma.common.LdmaException;
import com.nokia.oss.mdf.rda.ldma.context.ILdmaContext;
import com.nokia.oss.mdf.rda.ldma.mediation.entity.EntityElement;
import com.nokia.oss.mdf.rda.ldma.mediation.entity.IEntityComponent;
import com.nokia.oss.mdf.rda.ldma.mediation.entity.L12EntityModel;
import com.nokia.oss.mdf.rda.ldma.reader.DataFileMap;

public class Level12DeltaEntityBuilder extends DeltaEntityBuilder {
	@Override
	protected DeltaEntity createForInsert(ILdmaContext context)
			throws LdmaException {

		final String METHOD = "Level12DeltaEntityBuilder::createForInsert#";
		System.out.println(METHOD + "Entering...");
		DeltaEntity deltaEntity = new DeltaEntity();
		EntityBuilder<DeltaInsertEntity> insertEntityBuilder = new
				Level12DeltaInsertEntityBuilder();
		DataFileMap fileMap = getLevel12File1(context);
		
		List<String> siteCodes = getAllSiteCodes(context);
		
		System.out.println(METHOD + "All site codes : "+siteCodes);
		Iterator<String> iter = siteCodes.iterator();
		while(iter.hasNext()) {
			String siteCode = iter.next();
			IEntityComponent l12Model = new L12EntityModel(siteCode);
			l12Model.createAll(fileMap);
			
			//System.out.println(l12Model.printComponent(siteCode));
			
			Map<String, List<EntityElement>> siteComponent = l12Model.getAll();
			
			Set<String> keys = siteComponent.keySet();
			Iterator<String> iterComponents = keys.iterator();
			while(iterComponents.hasNext()) {
				String key = iterComponents.next();
				List<EntityElement> entites = siteComponent.get(key);
				Iterator<EntityElement> iterEntites = entites.iterator();
				while(iterEntites.hasNext()) {
					context.setCurrentEntity(iterEntites.next());
					DeltaInsertEntity deltaInsertEntity = insertEntityBuilder.build(context);
					deltaEntity.addDeltaInsertEntity(deltaInsertEntity);
				}
			}
		}
		return deltaEntity;
	}
	
	@Override
	protected DeltaEntity createForUpdate(ILdmaContext context)
			throws LdmaException {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	protected DeltaEntity createForDelete(ILdmaContext context)
			throws LdmaException {
		// TODO Auto-generated method stub
		return null;
	}

	private List<String> getAllSiteCodes(ILdmaContext context) {
		
		DataFileMap fileMap = getLevel12File1(context);
		
		int numRows = fileMap.getNumberOfRows();
		List<String> siteCodeList = new ArrayList<>();
		for(int i=0; i<numRows; i++) {
			Map<String, String> rowMap = fileMap.getRow(LdmaConstants.ROW+(i+1));
			String siteCode = rowMap.get(LdmaConstants.Level12FILE1.COLUMN_A);
			if(!siteCodeList.contains(siteCode))
				siteCodeList.add(siteCode);
		}
		
		return siteCodeList;
	}
	
	private DataFileMap getLevel12File1(ILdmaContext context) {
		Map<String, DataFileMap> filesMap = context.getFilesMap();
		
		Set<String> keys = filesMap.keySet();		
		Iterator<String> iter = keys.iterator();
		String key = iter.next();
		
		return filesMap.get(key);
	}
}
