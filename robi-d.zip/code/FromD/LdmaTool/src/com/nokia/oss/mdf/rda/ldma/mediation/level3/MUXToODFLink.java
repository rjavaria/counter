package com.nokia.oss.mdf.rda.ldma.mediation.level3;

import java.util.Map;

import com.nokia.oss.mdf.rda.ldma.common.LdmaConstants;
import com.nokia.oss.mdf.rda.ldma.mediation.entity.EntityElement;

public class MUXToODFLink extends EntityElement {
	
	private String aTerminationName; 
	private String zTerminationName; 

	public MUXToODFLink(Map<String, String> rowMap) {
		super(rowMap);
		aTerminationName = constructATerminationName();
		zTerminationName = constructZTerminationName();
	}


	private String constructATerminationName() {
		// TODO Auto-generated method stub
		return null;
	}
	
	private String constructZTerminationName() {
		//DHGUL58-ODF-1/1/1
		StringBuilder builder = new StringBuilder();
		builder.append(getRowData().get(LdmaConstants.Level3MUXTOODFFILE.COLUMN_A)); 
		builder.append(LdmaConstants.HYPHEN);
		builder.append(LdmaConstants.Level12EntityType.ODF); 
		builder.append(LdmaConstants.HYPHEN);
		builder.append(getRowData().get(LdmaConstants.Level3MUXTOODFFILE.COLUMN_F)); 
		builder.append(LdmaConstants.SLASH);
		builder.append(getRowData().get(LdmaConstants.Level3MUXTOODFFILE.COLUMN_G)); 
		builder.append(LdmaConstants.SLASH);
		builder.append(getRowData().get(LdmaConstants.Level3MUXTOODFFILE.COLUMN_H)); 
		return builder.toString();
	}

	@Override
	protected String constructName() {
		// <AEndTermination>:<ZEndTermination>
		//1-DHGUL58_OSN35_1/1/4/SEP/port=2:DHGUL58-ODF-1/1/1

		StringBuilder builder = new StringBuilder();
		builder.append(getRowData().get(LdmaConstants.Level3PHYSICALCOREFILE.COLUMN_A));
		builder.append(LdmaConstants.HYPHEN); 
		builder.append(getRowData().get(LdmaConstants.Level3PHYSICALCOREFILE.COLUMN_B)); 
		return builder.toString();
	}

	@Override
	protected String constructType() {
		return LdmaConstants.Level3EntityType.MUX_ODF_LINK;	
	}
	
	@Override
	protected Map<String, String> constructFeatures() {
		Map<String, String> features = getFeatures();
		features.put(LdmaConstants.Features.MuxToOdf[0], 
				LdmaConstants.Level3EntityType.L3_L4_FLOE_END_POINT);
		return features;
	}
	
	@Override
	protected String constructDiscoveredName() {
		return constructName();
	}

	public String getaTerminationName() {
		return aTerminationName;
	}

	public void setaTerminationName(String aTerminationName) {
		this.aTerminationName = aTerminationName;
	}

	public String getzTerminationName() {
		return zTerminationName;
	}

	public void setzTerminationName(String zTerminationName) {
		this.zTerminationName = zTerminationName;
	}
}
