package com.nokia.oss.mdf.rda.ldma.builder;

import com.nokia.oss.mdf.rda.ldma.common.LdmaException;
import com.nokia.oss.mdf.rda.ldma.context.ILdmaContext;

public interface EntityBuilder<T> {
	public T build(ILdmaContext context) throws LdmaException;
}






