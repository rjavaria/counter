package com.nokia.oss.mdf.rda.ldma.server;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import com.alu.oss.mdf.rda.metadata.delta.DeltaEntity;
import com.nokia.oss.mdf.rda.ldma.builder.LdmaModelFactory;
import com.nokia.oss.mdf.rda.ldma.common.LdmaConstants;
import com.nokia.oss.mdf.rda.ldma.common.LdmaException;
import com.nokia.oss.mdf.rda.ldma.context.ILdmaContext;
import com.nokia.oss.mdf.rda.ldma.context.L12LdmaContext;
import com.nokia.oss.mdf.rda.ldma.context.L3LdmaContext;
import com.nokia.oss.mdf.rda.ldma.reader.CSVReader;
import com.nokia.oss.mdf.rda.ldma.reader.DataFileMap;

public class LdmaInvokerImpl implements ILdmaInvoker {
	@Override
	public void execute(String level, String operation) 
				throws LdmaException {
		final String METHOD = "LdmaInvokerImpl:execute#";
		
		System.out.println(METHOD +"Executing...");
		
		String baseDir = System.getProperty("user.dir");
		System.out.println(METHOD +"Base directory is : "+baseDir);
		
		String level12DataDir = baseDir + File.separator + "data" 
										+ File.separator + "input" 
										+ File.separator + "level12"
										+ File.separator;
		System.out.println(METHOD +"Level12 input data directory is : "+level12DataDir);
		
		String level3DataDir = baseDir + File.separator + "data" 
									   + File.separator + "input" 
									   + File.separator + "level3"
									   + File.separator;
		System.out.println(METHOD +"Level3 input data directory is : "+level3DataDir);
		
		System.out.println(METHOD +"Running Ldma to generate xml for level : "+level);
		if(LdmaConstants.LevelType.LEVEL12.equals(level)) {
			executeLevel12(level, operation, level12DataDir);
		}
		else if(LdmaConstants.LevelType.LEVEL3.equals(level)) {
			executeLevel3(level, operation, level3DataDir);
		}
		else if(LdmaConstants.LevelType.ALL.equals(level)) {
			executeLevel12(LdmaConstants.LevelType.LEVEL12, operation, level12DataDir);
			executeLevel3(LdmaConstants.LevelType.LEVEL3, operation, level3DataDir);
		}
		else {
			throw new LdmaException("Invalid level type : it should be "
										+LdmaConstants.LevelType.LEVEL12+", "
										+LdmaConstants.LevelType.LEVEL3+" or "
										+LdmaConstants.LevelType.ALL);
		}
	}
	
	private void executeLevel12(String level, String operation, String dataDir) throws LdmaException {
		final String METHOD = "LdmaInvokerImpl:executeLevel12#";
		System.out.println(METHOD+"Starting for : "+level);
		
		String[] filesList = LdmaConstants.LdmaFiles.LEVEL12FILES;
		
		Map<String, DataFileMap> filesMap = new HashMap<String, DataFileMap>();
		for(String file : filesList) {
			CSVReader reader = new CSVReader();
			DataFileMap fileMap = reader.readFile(dataDir+file);
			
			filesMap.put(file, fileMap);
		}
		ILdmaContext context = new L12LdmaContext(level, operation, filesMap);
		DeltaEntity entity = LdmaModelFactory.getInstance().create(context);
		
		generateXml(level, entity);
		System.out.println(METHOD+"Finished successfully for : "+level);
	}
	
	private void executeLevel3(String level, String operation, String dataDir) throws LdmaException {
		final String METHOD = "LdmaInvokerImpl:executeLevel3#";
		System.out.println(METHOD+"Starting for : "+level);
		
		String[] filesList = LdmaConstants.LdmaFiles.LEVEL3FILES;
		Map<String, DataFileMap> filesMap = new HashMap<String, DataFileMap>();
		for(String file : filesList) {
			CSVReader reader = new CSVReader();
			DataFileMap fileMap = reader.readFile(dataDir+file);
			
			filesMap.put(file, fileMap);
		}
		ILdmaContext context = new L3LdmaContext(level, operation, filesMap);
		DeltaEntity entity = LdmaModelFactory.getInstance().create(context);
		
		generateXml(level, entity);
		System.out.println(METHOD+"Finished successfully for : "+level);
	}
	
	private void generateXml(String level, DeltaEntity entity) throws LdmaException{
		final String METHOD = "LdmaInvokerImpl:generateXml#";
		System.out.println("Generating xml for : "+level);
		//generate xml from DeltaEntity
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(DeltaEntity.class);
			Marshaller m = jaxbContext.createMarshaller();
			m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			
			if(LdmaConstants.LevelType.LEVEL12.equals(level)) {
				m.marshal(entity, new File("C:\\Data\\output12.xml"));
				System.out.println(METHOD +"Successfully generated output12.xml for : "+level);
			}
			else if(LdmaConstants.LevelType.LEVEL3.equals(level)) {
				m.marshal(entity, new File("C:\\Data\\output3.xml"));
				System.out.println(METHOD +"Successfully generated output3.xml for : "+level);
			}
			else if(LdmaConstants.LevelType.ALL.equals(level)) {
				m.marshal(entity, new File("C:\\Data\\output12.xml"));
				System.out.println(METHOD +"Successfully generated output12.xml for : level12");
				m.marshal(entity, new File("C:\\Data\\output3.xml"));
				System.out.println(METHOD +"Successfully generated output3.xml for : level3");
			}
			
		} catch (JAXBException e) {
			e.printStackTrace();
			throw new LdmaException(e.getMessage());
		}
	}
}
