package com.nokia.oss.mdf.rda.ldma.common;

public class LdmaException extends Exception {
	private static final long serialVersionUID = -2995341914627282198L;

	public LdmaException() {
		super();
	}
	
	public LdmaException(String s) {
		super(s);
	}
}
