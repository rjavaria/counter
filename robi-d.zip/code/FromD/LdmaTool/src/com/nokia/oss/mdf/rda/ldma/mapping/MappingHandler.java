package com.nokia.oss.mdf.rda.ldma.mapping;

import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;


public class MappingHandler extends DefaultHandler {

	private String currentRuleId = null;
	private String currentOperation = null;
	private Map<String, MappingBean> mappingHolder = new HashMap<String, MappingBean>();
	private Stack<String> elementStack = new Stack<String>();
	private Stack<MappingBean> objectStack = new Stack<MappingBean>();	
	
	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {
		
		this.elementStack.push(qName);
		
		if(MappingConstants.MAPPING.equals(qName)) {
			MappingBean bean = new MappingBean();
			
			if(attributes != null && attributes.getLength() == 1) {
				currentRuleId = attributes.getValue(0);
				bean.setRuleId(currentRuleId);
			}
			this.objectStack.push(bean);
		}
		
		if(MappingConstants.MAP.equals(qName)) {
			if(attributes != null && attributes.getLength() == 1) {
				currentOperation = attributes.getValue(0);
			}
		}
		else if(MappingConstants.LIST.equals(qName)) {
			if(attributes != null && attributes.getLength() == 1) {
				currentOperation = attributes.getValue(0);
			}
		}
		
		if(MappingConstants.ENTRY.equals(qName)) {
			MappingBean bean = (MappingBean)this.objectStack.peek();
			
			if(currentOperation.equals(MappingConstants.MAP)) {
				String key = attributes.getValue(attributes.getQName(0));
				String value = attributes.getValue(attributes.getQName(1));
				bean.storeMapAttr(key, value);
			}
			else if(currentOperation.equals(MappingConstants.ADD)) {
				String key = attributes.getValue(attributes.getQName(0));
				String value = attributes.getValue(attributes.getQName(1));
				bean.storeAddAttr(key, value);
			}
		}
	}
	
	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		this.elementStack.pop();
		
		if(MappingConstants.MAPPING.equals(qName)) {
			MappingBean bean = this.objectStack.pop();
			this.mappingHolder.put(currentRuleId, bean);
		}
	}
	
	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		
		String value = new String(ch, start, length);
		if(value.length() == 0) {
			return;
		}
		
		if(MappingConstants.VALUE.equals(currentElement())) {
			MappingBean bean = (MappingBean)this.objectStack.peek();
			if(currentOperation.equals(MappingConstants.DELETE)) {
				bean.storeDeleteAttr(value);
			}
		}
	}
	
	private String currentElement()
    {
		return this.elementStack.peek();
    }
	
	public Map<String, MappingBean> getMappingHolder() {
		return mappingHolder;
	}
}
