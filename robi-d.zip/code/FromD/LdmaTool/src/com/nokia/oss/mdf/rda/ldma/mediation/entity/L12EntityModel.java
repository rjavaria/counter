package com.nokia.oss.mdf.rda.ldma.mediation.entity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.nokia.oss.mdf.rda.ldma.common.LdmaConstants;
import com.nokia.oss.mdf.rda.ldma.mediation.level12.ODFChassis;
import com.nokia.oss.mdf.rda.ldma.mediation.level12.ODFPort;
import com.nokia.oss.mdf.rda.ldma.mediation.level12.ODFTray;
import com.nokia.oss.mdf.rda.ldma.mediation.level12.ODFTrayPort;
import com.nokia.oss.mdf.rda.ldma.reader.DataFileMap;

public class L12EntityModel implements IEntityComponent {

	private String siteCode;
	
	private Map<String, List<EntityElement>> component = new HashMap<>();
	private List<EntityElement> chassisList = new ArrayList<>();
	private List<EntityElement> trayList = new ArrayList<>();
	private List<EntityElement> trayPortList = new ArrayList<>();
	private List<EntityElement> portList = new ArrayList<>();
	

	public L12EntityModel(String siteCode) {
		this.siteCode = siteCode;
		component.put(LdmaConstants.Level12EntityType.ODF_CHASSIS, chassisList);
		component.put(LdmaConstants.Level12EntityType.ODF_TRAY, trayList);
		component.put(LdmaConstants.Level12EntityType.ODF_TRAYPORT, trayPortList);
		component.put(LdmaConstants.Level12EntityType.ODF_PORT, portList);
	}
	
	@Override
	public void createAll(Map<String, DataFileMap> fileMaps) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void createAll(DataFileMap fileMap) {
		int numRows = fileMap.getNumberOfRows();		
		for(int i=0; i<numRows; i++) {
			Map<String, String> rowMap = fileMap.getRow(LdmaConstants.ROW+(i+1));
			String siteCode = rowMap.get(LdmaConstants.Level12FILE1.COLUMN_A);
			if(this.siteCode.equals(siteCode)) {
				create(rowMap);
			}
		}
	}

	@Override
	public void create(Map<String, String> rowMap) {
		if(doExist(LdmaConstants.Level12EntityType.ODF_CHASSIS, rowMap)) {
			EntityElement odfChassis = new ODFChassis(rowMap);
			odfChassis.add(chassisList);
		}
		
		if(doExist(LdmaConstants.Level12EntityType.ODF_TRAY, rowMap)) {
			EntityElement odfTray = new ODFTray(rowMap);
			odfTray.add(trayList);
		}
		if(doExist(LdmaConstants.Level12EntityType.ODF_PORT, rowMap)) {
			EntityElement odfTray = new ODFPort(rowMap);
			odfTray.add(portList);
		}
		
		String numPorts = rowMap.get(LdmaConstants.Level12FILE1.COLUMN_E);
		if(null != numPorts && !numPorts.trim().equals("")) {
			int portCounts = Integer.parseInt(numPorts);
			if(portCounts > 0) {
				for(int i=1; i<=portCounts; i++) {
					EntityElement odfTrayPort = new ODFTrayPort(rowMap, String.valueOf(i));
					odfTrayPort.add(trayPortList);
				}
			}
		}
	}
	
	@Override
	public boolean doExist(String entity, Map<String, String> rowMap) {
		boolean bExist = true;
		if(LdmaConstants.Level12EntityType.ODF_CHASSIS.equals(entity)) {
			String odfNumber = rowMap.get(LdmaConstants.Level12FILE1.COLUMN_C);
			if(null == odfNumber || odfNumber.trim().equals("")) {
				bExist = false;
			}
		}
		else if(LdmaConstants.Level12EntityType.ODF_TRAY.equals(entity)) {
			String trayNumber = rowMap.get(LdmaConstants.Level12FILE1.COLUMN_D);
			if(null == trayNumber || trayNumber.trim().equals("")) {
				bExist = false;
			}
		}
		else if(LdmaConstants.Level12EntityType.ODF_PORT.equals(entity)) {
			String odfNumber = rowMap.get(LdmaConstants.Level12FILE1.COLUMN_C);
			if(null == odfNumber || odfNumber.trim().equals("")) {
				bExist = false;
			}
		}
		return bExist;	
	}
	
	@Override
	public Map<String, List<EntityElement>> getAll() {
		return component;
	}
	
	@Override
	public String printComponent(String name) {
		StringBuilder builder = new StringBuilder();
		
		Set<String> keys = component.keySet();
		Iterator<String> iter = keys.iterator();
		builder.append("====== "+name +" ======\n");
		while(iter.hasNext())
		{
			String key = iter.next();
			List<EntityElement> entites = component.get(key);
			Iterator<EntityElement> iterEntites = entites.iterator();
			while(iterEntites.hasNext()) {
				EntityElement entity = iterEntites.next();
				builder.append(entity.toString());
			}
		}
		builder.append("=====================");
		return builder.toString();
	}
	
	public String getSiteCode() {
		return siteCode;
	}

	public void setSiteCode(String siteCode) {
		this.siteCode = siteCode;
	}

	public List<EntityElement> getChassisList() {
		return chassisList;
	}

	public void setChassisList(List<EntityElement> chassisList) {
		this.chassisList = chassisList;
	}
}
