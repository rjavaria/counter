package com.nokia.oss.mdf.rda.ldma.context;

import java.util.Map;

import com.nokia.oss.mdf.rda.ldma.mediation.entity.EntityElement;
import com.nokia.oss.mdf.rda.ldma.reader.DataFileMap;

public interface ILdmaContext {
	public String getOperation();
	public String getLevel();
	public Map<String, DataFileMap> getFilesMap();
	public EntityElement getCurrentEntity();
	public void setCurrentEntity(EntityElement entityElem);
}
