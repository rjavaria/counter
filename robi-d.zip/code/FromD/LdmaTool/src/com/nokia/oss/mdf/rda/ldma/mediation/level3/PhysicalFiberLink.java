package com.nokia.oss.mdf.rda.ldma.mediation.level3;

import java.util.Map;

import com.nokia.oss.mdf.rda.ldma.common.LdmaConstants;
import com.nokia.oss.mdf.rda.ldma.mediation.entity.EntityElement;

public class PhysicalFiberLink extends EntityElement {

	private String aTerminationName; 
	private String zTerminationName;
	private Map<String, Map<String, String>> additionalFields;
	
	public PhysicalFiberLink(Map<String, String> rowMap, 
							 Map<String, Map<String, String>> additionalFields,
							 boolean bFeatConstruct) {
		super(rowMap, bFeatConstruct);
		this.additionalFields = additionalFields;
		constructFeatures();
		aTerminationName = constructATerminationName();
		zTerminationName = constructZTerminationName();
	}

	@Override
	protected String constructName() {
		return getRowData().get(LdmaConstants.Level3PHYSICALFIBERFILE.COLUMN_A);
	}

	@Override
	protected String constructType() {
		return LdmaConstants.Level3EntityType.PHY_FIBER_LINK;
	}
	
	@Override
	protected String constructDiscoveredName() {
		return constructName();
	}

	@Override
	protected Map<String, String> constructFeatures() {
		Map<String, String> features = getFeatures();
		features.put(LdmaConstants.Features.PhysicalFiberLink[0], 
				getRowData().get(LdmaConstants.Level3PHYSICALFIBERFILE.COLUMN_F));
		features.put(LdmaConstants.Features.PhysicalFiberLink[1], 
				getRowData().get(LdmaConstants.Level3PHYSICALFIBERFILE.COLUMN_J));
		features.put(LdmaConstants.Features.PhysicalFiberLink[2], 
				getRowData().get(LdmaConstants.Level3PHYSICALFIBERFILE.COLUMN_K));
		features.put(LdmaConstants.Features.PhysicalFiberLink[3], 
				getRowData().get(LdmaConstants.Level3PHYSICALFIBERFILE.COLUMN_L));
		
		String linkName = getRowData().get(LdmaConstants.Level3PHYSICALFIBERFILE.COLUMN_A);
		String[] tokens = linkName.split(LdmaConstants.HYPHEN);
		features.put(LdmaConstants.Features.PhysicalFiberLink[4], tokens[2]);
		features.put(LdmaConstants.Features.PhysicalFiberLink[5], 
				LdmaConstants.Level3EntityType.L3_L4_FLOE_END_POINT);

		
		Map<String, String> extraFeatures = additionalFields.get(LdmaConstants.FEATURES);
		features.putAll(extraFeatures);
		return features;
	}
	
	protected String constructATerminationName() {
		StringBuilder builder = new StringBuilder();
		builder.append(getRowData().get(LdmaConstants.Level3PHYSICALFIBERFILE.COLUMN_B));
		builder.append(LdmaConstants.HYPHEN);
		builder.append(LdmaConstants.Level12EntityType.ODF); 
		builder.append(LdmaConstants.HYPHEN);
		
		Map<String, String> extraInfo = additionalFields.get(LdmaConstants.EXTRAINFO);
		builder.append(extraInfo.get(LdmaConstants.Level3PHYSICALCOREFILE.COLUMN_C));
		
		builder.append(LdmaConstants.SLASH);
		builder.append(LdmaConstants.Level12EntityType.TP);
		return builder.toString();
	}
	
	protected String constructZTerminationName() {
		StringBuilder builder = new StringBuilder();
		builder.append(getRowData().get(LdmaConstants.Level3PHYSICALFIBERFILE.COLUMN_D));
		builder.append(LdmaConstants.HYPHEN);
		builder.append(LdmaConstants.Level12EntityType.ODF); 
		builder.append(LdmaConstants.HYPHEN);
		
		Map<String, String> extraInfo = additionalFields.get(LdmaConstants.EXTRAINFO);
		builder.append(extraInfo.get(LdmaConstants.Level3PHYSICALCOREFILE.COLUMN_F));
		
		builder.append(LdmaConstants.SLASH);
		builder.append(LdmaConstants.Level12EntityType.TP);
		return builder.toString();
	}

	public String getaTerminationName() {
		return aTerminationName;
	}

	public void setaTerminationName(String aTerminationName) {
		this.aTerminationName = aTerminationName;
	}

	public String getzTerminationName() {
		return zTerminationName;
	}

	public void setzTerminationName(String zTerminationName) {
		this.zTerminationName = zTerminationName;
	}
}
