package com.nokia.oss.mdf.rda.ldma.context;

import java.util.Map;

import com.nokia.oss.mdf.rda.ldma.mediation.entity.EntityElement;
import com.nokia.oss.mdf.rda.ldma.reader.DataFileMap;

public class L3LdmaContext implements ILdmaContext {

	private String operation;
	private String level;
	private Map<String, DataFileMap> filesMap;
	private EntityElement entityElement; 
	
	public L3LdmaContext(String level, String operation,
						  Map<String, DataFileMap> filesMap) {
		this.operation = operation;
		this.level = level;
		this.filesMap = filesMap;
	}
	
	@Override
	public String getOperation() {
		return operation;
	}

	@Override
	public String getLevel() {
		return level;
	}

	@Override
	public Map<String, DataFileMap> getFilesMap() {
		return filesMap;
	}

	@Override
	public void setCurrentEntity(EntityElement entityElem) {
		this.entityElement = entityElem;
	}
	
	@Override
	public EntityElement getCurrentEntity() {
		return entityElement;
	}
}
