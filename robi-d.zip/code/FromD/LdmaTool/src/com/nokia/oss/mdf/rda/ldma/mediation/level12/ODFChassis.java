package com.nokia.oss.mdf.rda.ldma.mediation.level12;

import java.util.Map;

import com.nokia.oss.mdf.rda.ldma.common.LdmaConstants;
import com.nokia.oss.mdf.rda.ldma.mediation.entity.EntityElement;

public class ODFChassis extends EntityElement {
	
	private String locationName;
	private String networkName;
	public ODFChassis(Map<String, String> rowMap) {
		super(rowMap);
		locationName = constructLocationName();
		networkName = constructNetworkName();
	}

	@Override
	protected String constructName() {
		StringBuilder builder = new StringBuilder();
		builder.append(getRowData().get(LdmaConstants.Level12FILE1.COLUMN_A));
		builder.append(LdmaConstants.HYPHEN);
		builder.append(LdmaConstants.Level12EntityType.ODF);
		builder.append(LdmaConstants.HYPHEN);
		builder.append(getRowData().get(LdmaConstants.Level12FILE1.COLUMN_C));
		return builder.toString();
	}
	
	@Override
	protected String constructDiscoveredName() {
		return constructName();
	}
	
	@Override
	protected String constructType() {
		return LdmaConstants.Level12EntityType.ODF_CHASSIS;
	}
	
	@Override
	protected Map<String, String> constructFeatures() {
		Map<String, String> features = getFeatures();
		features.put(LdmaConstants.Features.ODFChassis[0], 
				LdmaConstants.Level12EntityType.L1_L2_FLOE_END_POINT);
		return features;
	}
	
	protected String constructLocationName() {
		StringBuilder builder = new StringBuilder();
		builder.append(getRowData().get(LdmaConstants.Level12FILE1.COLUMN_A));
		return builder.toString();
	}
	
	protected String constructNetworkName() {
		return LdmaConstants.ODF_CHASSIS_NETWORK_NAME;
	}

	public String getLocationName() {
		return locationName;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	public String getNetworkName() {
		return networkName;
	}

	public void setNetworkName(String networkName) {
		this.networkName = networkName;
	}
	
	
}
