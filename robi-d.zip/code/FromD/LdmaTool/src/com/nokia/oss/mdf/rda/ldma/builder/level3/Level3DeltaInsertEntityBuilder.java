package com.nokia.oss.mdf.rda.ldma.builder.level3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.alu.oss.mdf.rda.metadata.delta.DeltaInsertEntity;
import com.alu.oss.mdf.rda.metadata.sure.FeatureEntity;
import com.alu.oss.mdf.rda.metadata.sure.LinkEntity;
import com.nokia.oss.mdf.rda.ldma.builder.EntityBuilder;
import com.nokia.oss.mdf.rda.ldma.common.LdmaException;
import com.nokia.oss.mdf.rda.ldma.context.ILdmaContext;
import com.nokia.oss.mdf.rda.ldma.mediation.entity.EntityElement;
import com.nokia.oss.mdf.rda.ldma.mediation.level3.PhysicalFiberCoreLink;
import com.nokia.oss.mdf.rda.ldma.mediation.level3.PhysicalFiberLink;

public class Level3DeltaInsertEntityBuilder  implements EntityBuilder<DeltaInsertEntity> {
	@Override
	public DeltaInsertEntity build(ILdmaContext context) throws LdmaException {
		
		EntityElement entityElement = context.getCurrentEntity();
		//String entityType = entityElement.getType();
		//if(LdmaConstants.Level3EntityType.PHY_FIBER_CORE_LINK.equals(entityType) ) {
		LinkEntity entity = new LinkEntity();
		entity.setName(entityElement.getName());
		entity.setType(entityElement.getType());
		entity.setDiscoveredName(entityElement.getDiscoveredName());
		
		if(entityElement instanceof PhysicalFiberLink) {
			entity.setaTermName(((PhysicalFiberLink)entityElement).getaTerminationName());
			entity.setzTermName(((PhysicalFiberLink)entityElement).getzTerminationName());
		}
		else if(entityElement instanceof PhysicalFiberCoreLink) {
			entity.setaTermName(((PhysicalFiberCoreLink)entityElement).getaTerminationName());
			entity.setzTermName(((PhysicalFiberCoreLink)entityElement).getzTerminationName());
		
		}
		
		//add features
		Map<String, String> features = entityElement.getFeatures();
		if(null != features) {
			List<FeatureEntity> featureEntities = new ArrayList<>();
			
			Set<String> keys = features.keySet();
			Iterator<String> iter = keys.iterator();
			while(iter.hasNext()) {
				String key = iter.next();
				FeatureEntity featureEntity = new FeatureEntity(key, features.get(key));
				featureEntities.add(featureEntity);
			}
			entity.setFeatureEntities(featureEntities);
		}
		return new DeltaInsertEntity(entity);
			
			/*
		else {
			String message = "Could not build DeltaInsertEntity. Invalid Level-3 entity type : "+entityType;
			throw new LdmaException(message);
		}*/
	}
}
