package com.nokia.oss.mdf.rda.ldma.mediation.level12;
import java.util.Map;

import com.nokia.oss.mdf.rda.ldma.common.LdmaConstants;
import com.nokia.oss.mdf.rda.ldma.mediation.entity.EntityElement;

public class ODFPort extends EntityElement {

	public ODFPort(Map<String, String> rowMap) {
		super(rowMap);
	}
	
	@Override
	protected String constructName() {
		StringBuilder builder = new StringBuilder();
		builder.append(getRowData().get(LdmaConstants.Level12FILE1.COLUMN_A));
		builder.append(LdmaConstants.HYPHEN);
		builder.append(LdmaConstants.Level12EntityType.ODF);
		builder.append(LdmaConstants.HYPHEN);
		builder.append(getRowData().get(LdmaConstants.Level12FILE1.COLUMN_C));
		builder.append(LdmaConstants.SLASH);
		builder.append(LdmaConstants.Level12EntityType.TP);
		return builder.toString();
	}

	@Override
	protected String constructDiscoveredName() {
		return constructName();
	}
	
	@Override
	protected String constructType() {
		return LdmaConstants.Level12EntityType.ODF_PORT;
	}
	
	@Override
	protected Map<String, String> constructFeatures() {
		Map<String, String> features = getFeatures();
		features.put(LdmaConstants.Features.ODFPorts[0], 
				LdmaConstants.Level12EntityType.L1_L2_FLOE_END_POINT);
		return features;
	}
}
