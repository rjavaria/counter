package com.nokia.oss.mdf.rda.ldma.builder.level3;


import com.alu.oss.mdf.rda.metadata.delta.DeltaAssociation;
import com.alu.oss.mdf.rda.metadata.sure.EntityType;
import com.nokia.oss.mdf.rda.ldma.builder.EntityBuilder;
import com.nokia.oss.mdf.rda.ldma.common.LdmaConstants;
import com.nokia.oss.mdf.rda.ldma.common.LdmaException;
import com.nokia.oss.mdf.rda.ldma.context.ILdmaContext;
import com.nokia.oss.mdf.rda.ldma.mediation.entity.EntityElement;

public class Level3DeltaAssociationEntityBuilder  implements EntityBuilder<DeltaAssociation> {
	@Override
	public DeltaAssociation build(ILdmaContext context) throws LdmaException {
		
		EntityElement entityElement = context.getCurrentEntity();
		
		DeltaAssociation entity = new DeltaAssociation();
		
		entity.setParentEntityName(entityElement.getName());
		entity.setParentEntityType(EntityType.LINK);
		
		String name = entityElement.getName();
		String childEntityName = name.substring(0, name.lastIndexOf('-'));
		entity.setChildEntityName(childEntityName);
		entity.setChildEntityType(EntityType.LINK);
		entity.setChildType(LdmaConstants.Level3EntityType.PHY_FIBER_CORE_LINK);
		
		return entity;
	}
}
