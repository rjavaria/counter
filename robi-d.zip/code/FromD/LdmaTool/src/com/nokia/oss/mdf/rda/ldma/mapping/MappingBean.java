package com.nokia.oss.mdf.rda.ldma.mapping;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;


public class MappingBean {
	private String ruleId;
		
	private Map<String, String> mapAttrs = new LinkedHashMap<String, String>();
	private Map<String, String> addAttrs = new LinkedHashMap<String, String>();
	private List<String> deleteAttrs = new ArrayList<String>();

	public String getRuleId() {
		return ruleId;
	}

	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}
	
	public Map<String, String> getMapAttrs() {
		return mapAttrs;
	}

	public void setMapAttrs(Map<String, String> mapAttrs) {
		this.mapAttrs = mapAttrs;
	}

	public Map<String, String> getAddAttrs() {
		return addAttrs;
	}

	public void setAddAttrs(Map<String, String> addAttrs) {
		this.addAttrs = addAttrs;
	}

	public List<String> getDeleteAttrs() {
		return deleteAttrs;
	}

	public void setDeleteAttrs(List<String> deleteAttrs) {
		this.deleteAttrs = deleteAttrs;
	}

	public void storeMapAttr(String key, String vnokiae) {
		mapAttrs.put(key, vnokiae);
	}
	
	public void storeAddAttr(String key, String vnokiae) {
		addAttrs.put(key, vnokiae);
	}
	
	public void storeDeleteAttr(String vnokiae) {
		deleteAttrs.add(vnokiae);
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder("RuleId = "+ruleId);
		builder.append(", Map attributes = "+mapAttrs);
		builder.append(", Add attributes = "+addAttrs);
		builder.append(", Delete attributes = "+deleteAttrs);
		return builder.toString();
	}
}
