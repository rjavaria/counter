package com.nokia.oss.mdf.rda.ldma.main;

import com.nokia.oss.mdf.rda.ldma.common.LdmaException;
import com.nokia.oss.mdf.rda.ldma.server.ILdmaInvoker;
import com.nokia.oss.mdf.rda.ldma.server.LdmaInvokerImpl;

public class LdmaRunner {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		ILdmaInvoker invoker = new LdmaInvokerImpl();
		
		String operation = "Insert";
		//String level = "Level12";
		String level = "Level3";
		
		try {
			invoker.execute(level, operation);
		} catch (LdmaException e) {
			System.out.println("LdmaException ::" +e.getMessage());
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
	}
}
