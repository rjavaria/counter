package com.nokia.oss.mdf.rda.ldma.builder.level3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.alu.oss.mdf.rda.metadata.delta.DeltaAssociation;
import com.alu.oss.mdf.rda.metadata.delta.DeltaEntity;
import com.alu.oss.mdf.rda.metadata.delta.DeltaInsertEntity;
import com.alu.oss.mdf.rda.metadata.delta.DeltaUpdateEntity;
import com.nokia.oss.mdf.rda.ldma.builder.DeltaEntityBuilder;
import com.nokia.oss.mdf.rda.ldma.builder.EntityBuilder;
import com.nokia.oss.mdf.rda.ldma.builder.level3.Level3DeltaInsertEntityBuilder;
import com.nokia.oss.mdf.rda.ldma.common.LdmaConstants;
import com.nokia.oss.mdf.rda.ldma.common.LdmaException;
import com.nokia.oss.mdf.rda.ldma.context.ILdmaContext;
import com.nokia.oss.mdf.rda.ldma.mediation.entity.EntityElement;
import com.nokia.oss.mdf.rda.ldma.mediation.entity.IEntityComponent;
import com.nokia.oss.mdf.rda.ldma.mediation.entity.L3PhyFiberCoreLinkModel;
import com.nokia.oss.mdf.rda.ldma.mediation.entity.L3PhyFiberLinkModel;
import com.nokia.oss.mdf.rda.ldma.reader.DataFileMap;

public class Level3DeltaEntityBuilder extends DeltaEntityBuilder {
	private EntityBuilder<DeltaInsertEntity> insertEntityBuilder = null;
	private EntityBuilder<DeltaUpdateEntity> updateEntityBuilder = null;
	private EntityBuilder<DeltaAssociation> assocEntityBuilder = null;
	
	@Override
	protected DeltaEntity createForInsert(ILdmaContext context)
			throws LdmaException {

		final String METHOD = "Level3DeltaEntityBuilder::createForInsert#";
		System.out.println(METHOD + "Entering...");
		DeltaEntity deltaEntity = new DeltaEntity();
		EntityBuilder<DeltaInsertEntity> insertEntityBuilder = new
				Level3DeltaInsertEntityBuilder();
		
		/**
		 * 2.1	Physical Fiber Link
		 */
		//buildPhyFiberLinkEntites(context, deltaEntity);
		
		/**
		 * 2.2	Physical Fiber Core Link 
		 */
		buildPhyFiberCoreLinkEntites(context, deltaEntity);
		
		
		return deltaEntity;
	}
	
	@Override
	protected DeltaEntity createForUpdate(ILdmaContext context)
			throws LdmaException {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	protected DeltaEntity createForDelete(ILdmaContext context)
			throws LdmaException {
		// TODO Auto-generated method stub
		return null;
	}
	
	private void addOperationEntity(ILdmaContext context, DeltaEntity deltaEntity) 
			throws LdmaException {
		if(LdmaConstants.OperationType.INSERT.equals(context.getOperation())) {
			DeltaInsertEntity deltaInsertEntity = getInsertEntityBuilder().build(context);
			deltaEntity.addDeltaInsertEntity(deltaInsertEntity);
		}
		else if(LdmaConstants.OperationType.UPDATE.equals(context.getOperation())) {
			DeltaUpdateEntity deltaUpdateEntity = getUpdateEntityBuilder().build(context);
			deltaEntity.addDeltaUpdateEntity(deltaUpdateEntity);
		}
	}
	
	private EntityBuilder<DeltaInsertEntity> getInsertEntityBuilder() {
		if(null == insertEntityBuilder) {
			insertEntityBuilder = new Level3DeltaInsertEntityBuilder();
		}
		return insertEntityBuilder;
	}
	
	private EntityBuilder<DeltaUpdateEntity> getUpdateEntityBuilder() {
		if(null == updateEntityBuilder) {
			updateEntityBuilder = new Level3DeltaUpdateEntityBuilder();
		}
		return updateEntityBuilder;
	}
	
	private EntityBuilder<DeltaAssociation> getAssocEntityBuilder() {
		if(null == assocEntityBuilder) {
			assocEntityBuilder = new Level3DeltaAssociationEntityBuilder();
		}
		return assocEntityBuilder;
	}
	
	/*
	 * ======= START ======  2.1	Physical Fiber Link  ======= START =======
	 */	
	private void buildPhyFiberLinkEntites(ILdmaContext context, DeltaEntity deltaEntity) 
			throws LdmaException {
		IEntityComponent model = new L3PhyFiberLinkModel(null);
		model.createAll(context.getFilesMap());
		
		Map<String, List<EntityElement>> components = model.getAll();
		
		Set<String> keys = components.keySet();
		Iterator<String> iterComponents = keys.iterator();
		while(iterComponents.hasNext()) {
			String key = iterComponents.next();
			List<EntityElement> entites = components.get(key);
			Iterator<EntityElement> iterEntites = entites.iterator();
			while(iterEntites.hasNext()) {
				context.setCurrentEntity(iterEntites.next());
				addOperationEntity(context, deltaEntity);
			}
		}
	}
	/*
	 * ======= END ======  2.1	Physical Fiber Link  ======= END =======
	 */
	
	/*
	 * ======= START ======  2.2	Physical Fiber Core Link ======= START =======
	 */
	private List<String> getAllLinkIds(ILdmaContext context) {
		
		DataFileMap fileMap = getLevel3PhysicalCoreFile(context);
		
		int numRows = fileMap.getNumberOfRows();
		List<String> linkIdList = new ArrayList<>();
		for(int i=0; i<numRows; i++) {
			Map<String, String> rowMap = fileMap.getRow(LdmaConstants.ROW+(i+1));
			String linkId = rowMap.get(LdmaConstants.Level3PHYSICALCOREFILE.COLUMN_A);
			if(!linkIdList.contains(linkId))
				linkIdList.add(linkId);
		}
		
		return linkIdList;
	}
	
	
	private DataFileMap getLevel3PhysicalCoreFile(ILdmaContext context) {
		Map<String, DataFileMap> filesMap = context.getFilesMap();
		
		Set<String> keys = filesMap.keySet();		
		Iterator<String> iter = keys.iterator();
		String key = iter.next();
		
		return filesMap.get(key);
	}
	
	private void buildPhyFiberCoreLinkEntites(ILdmaContext context, DeltaEntity deltaEntity) 
					throws LdmaException {
		DataFileMap fileMap = getLevel3PhysicalCoreFile(context);
		
		List<String> linkIds = getAllLinkIds(context);
		
		//System.out.println(METHOD + "All Link IDs : "+linkIds);
		Iterator<String> iter = linkIds.iterator();
		while(iter.hasNext()) {
			String linkId = iter.next();
			IEntityComponent l3Model = new L3PhyFiberCoreLinkModel(linkId);
			l3Model.createAll(fileMap);
			
			System.out.println(l3Model.printComponent(linkId));
			
			Map<String, List<EntityElement>> linkComponent = l3Model.getAll();
			
			Set<String> keys = linkComponent.keySet();
			Iterator<String> iterComponents = keys.iterator();
			while(iterComponents.hasNext()) {
				String key = iterComponents.next();
				List<EntityElement> entites = linkComponent.get(key);
				Iterator<EntityElement> iterEntites = entites.iterator();
				while(iterEntites.hasNext()) {
					context.setCurrentEntity(iterEntites.next());
					DeltaInsertEntity deltaInsertEntity = getInsertEntityBuilder().build(context);
					DeltaAssociation deltaAddAssociation = getAssocEntityBuilder().build(context);
					deltaEntity.addDeltaAddAssociation(deltaAddAssociation);
					deltaEntity.addDeltaInsertEntity(deltaInsertEntity);
				}
			}
		}
	}
	/*
	 * ======= END ======  2.2	Physical Fiber Core Link ======= END =======
	 */
}

