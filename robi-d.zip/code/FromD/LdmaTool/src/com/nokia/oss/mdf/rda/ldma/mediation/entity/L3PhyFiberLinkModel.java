package com.nokia.oss.mdf.rda.ldma.mediation.entity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.nokia.oss.mdf.rda.ldma.common.LdmaConstants;
import com.nokia.oss.mdf.rda.ldma.mediation.level3.PhysicalFiberLink;
import com.nokia.oss.mdf.rda.ldma.reader.DataFileMap;

public class L3PhyFiberLinkModel extends L3EntityModel {

	private List<EntityElement> phyFiberLinkList = new ArrayList<>();
	private Map<String, DataFileMap> refFileMaps = null;
	public L3PhyFiberLinkModel(String linkId) {
		super(linkId);
		getAll().put(LdmaConstants.Level3EntityType.PHY_FIBER_LINK, phyFiberLinkList);
	}
	
	@Override
	public void createAll(Map<String, DataFileMap> fileMaps) {

		//Set<String> fileNames = fileMaps.keySet();
		//Iterator<String> iter = fileNames.iterator();
		this.refFileMaps = fileMaps;
		DataFileMap phyFiberLinkFM = fileMaps.get(LdmaConstants.LdmaFileName.LEVEL3PHYFIBERLINK);
		
		int numRows = phyFiberLinkFM.getNumberOfRows();		
		for(int i=0; i<numRows; i++) {
			Map<String, String> rowMap = phyFiberLinkFM.getRow(LdmaConstants.ROW+(i+1));
			create(rowMap);
		}
	}

	@Override
	public void createAll(DataFileMap fileMap) {
		// TODO Auto-generated method stub

	}

	@Override
	public void create(Map<String, String> rowMap) {
		EntityElement link = new PhysicalFiberLink(rowMap, getAdditionalFields(rowMap), false);
		phyFiberLinkList.add(link);
	}
	
	/**
	 * This function gets extra information from other CSV files.. 
	 * @param rowMap
	 * @return
	 */
	private Map<String, Map<String, String>> getAdditionalFields(Map<String, String> rowMap) {
		
		Map<String, Map<String, String>> extras = new HashMap<String, Map<String, String>>();
		
		extras.put(LdmaConstants.FEATURES, getExtraFeatures(rowMap));
		extras.put(LdmaConstants.EXTRAINFO, getExtraInfo(rowMap));
		return extras;
	}
	
	private Map<String, String> getExtraFeatures(Map<String, String> rowMap) {
		Map<String, String> features = new HashMap<String, String>();
		String linkCode = rowMap.get(LdmaConstants.Level3PHYSICALFIBERFILE.COLUMN_A);
		DataFileMap phyFiberHHInfoFM = refFileMaps.get(LdmaConstants.LdmaFileName.LEVEL3PHYFIBERHHINFO);
		
		int numRows = phyFiberHHInfoFM.getNumberOfRows();		
		for(int i=0; i<numRows; i++) {
			Map<String, String> row = phyFiberHHInfoFM.getRow(LdmaConstants.ROW+(i+1));
			String phyLinkName = row.get(LdmaConstants.Level3PHYSICALFIBERHHFILE.COLUMN_A);
			if(linkCode.equals(phyLinkName)) {
				buildHHFeatures(row, features);
			}
		}
		
		return features;
	}
	
	private Map<String, String> getExtraInfo(Map<String, String> rowMap) {
		Map<String, String> info = new HashMap<String, String>();
		
		String linkCode = rowMap.get(LdmaConstants.Level3PHYSICALFIBERFILE.COLUMN_A);
		DataFileMap pnyFiberCoreInfoFM = refFileMaps.get(LdmaConstants.LdmaFileName.LEVEL3PHYFIBERCOREINFO);
		
		int numRows = pnyFiberCoreInfoFM.getNumberOfRows();		
		for(int i=0; i<numRows; i++) {
			Map<String, String> row = pnyFiberCoreInfoFM.getRow(LdmaConstants.ROW+(i+1));
			String phyLinkName = row.get(LdmaConstants.Level3PHYSICALCOREFILE.COLUMN_A);
			if(linkCode.equals(phyLinkName)) {
				//Get ODF number from Column C of Physical Fiber core info.xlsx to build a Term name
				info.put(LdmaConstants.Level3PHYSICALCOREFILE.COLUMN_C, 
							row.get(LdmaConstants.Level3PHYSICALCOREFILE.COLUMN_C));
				//Get ODF number from Column F of Physical Fiber core info.xlsx to build z Term name
				info.put(LdmaConstants.Level3PHYSICALCOREFILE.COLUMN_F, 
						row.get(LdmaConstants.Level3PHYSICALCOREFILE.COLUMN_F));
				break;
			}
		}
		
		return info;
	}
	
	private void buildHHFeatures(Map<String, String> row, Map<String, String> extraInfo) {
		
		//HH-<x> x from Column B 
		String feat1Name = "HH" + LdmaConstants.HYPHEN + row.get(LdmaConstants.Level3PHYSICALFIBERHHFILE.COLUMN_B);
		
		//lat=<lat>_long =<long>
		//example lat=23.78184_long=90.41583
		//lat from Column D
		//long from Column C of  Physical Fiber HH info.xlsx
		String lat = (row.get(LdmaConstants.Level3PHYSICALFIBERHHFILE.COLUMN_D) != null) ?
					  row.get(LdmaConstants.Level3PHYSICALFIBERHHFILE.COLUMN_D) : "Unknown";
		
		String feat1Val = "lat=" + lat + LdmaConstants.UNDER_SCORE+ 
				           "long=" + row.get(LdmaConstants.Level3PHYSICALFIBERHHFILE.COLUMN_C);
		extraInfo.put(feat1Name, feat1Val);
		
		//HH-<x>-Comments	Refers to the Hand Hole Number x comments
		//x from Column B
		String feat2Name = "HH" + LdmaConstants.HYPHEN + row.get(LdmaConstants.Level3PHYSICALFIBERHHFILE.COLUMN_B)
								+ LdmaConstants.HYPHEN + "Comments";
		 
		//comments from Column E of Physical Fiber HH info.xlsx
		String feat2Val =  row.get(LdmaConstants.Level3PHYSICALFIBERHHFILE.COLUMN_E);
		extraInfo.put(feat2Name, feat2Val);
	}
}
