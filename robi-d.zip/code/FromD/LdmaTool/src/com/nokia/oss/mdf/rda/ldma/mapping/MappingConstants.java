package com.nokia.oss.mdf.rda.ldma.mapping;

public interface MappingConstants {
	public final String MAPPING = "mapping";
	public final String MAP = "map";
	public final String ADD = "add";
	public final String DELETE = "delete";
	public final String LIST = "list";
	public final String ENTRY = "entry";
	public final String KEY = "key";
	public final String VALUE = "value";
}
