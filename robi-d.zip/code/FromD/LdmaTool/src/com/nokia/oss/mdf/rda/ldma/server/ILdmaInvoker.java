package com.nokia.oss.mdf.rda.ldma.server;

import com.nokia.oss.mdf.rda.ldma.common.LdmaException;

public interface ILdmaInvoker {
	/**
	 * 
	 * @param level
	 * @param operation
	 * @throws LdmaException
	 */
	public void execute(String level, String operation) 
			throws LdmaException;
}
