package com.nokia.oss.mdf.rda.ldma.builder;

import com.alu.oss.mdf.rda.metadata.delta.DeltaEntity;
import com.nokia.oss.mdf.rda.ldma.common.LdmaConstants;
import com.nokia.oss.mdf.rda.ldma.common.LdmaException;
import com.nokia.oss.mdf.rda.ldma.context.ILdmaContext;

public abstract class DeltaEntityBuilder implements EntityBuilder<DeltaEntity> {
	
	@Override
	public DeltaEntity build(ILdmaContext context) throws LdmaException {
		final String METHOD = "DeltaEntityBuilder::build#";
		System.out.println(METHOD+"Entering...");
		DeltaEntity entity = null;
		String operation = context.getOperation();
		if(LdmaConstants.OperationType.INSERT.equals(operation)) {
			entity = createForInsert(context);
		}
		else {
			String message = "Unsupported operation : "+operation;
			System.out.println(message+METHOD);
            throw new LdmaException(message);
		}
		return entity;
	}
	
	protected abstract DeltaEntity createForInsert(ILdmaContext context)
			throws LdmaException;
	protected abstract DeltaEntity createForUpdate(ILdmaContext context)
			throws LdmaException;
	protected abstract DeltaEntity createForDelete(ILdmaContext context)
			throws LdmaException;
}
