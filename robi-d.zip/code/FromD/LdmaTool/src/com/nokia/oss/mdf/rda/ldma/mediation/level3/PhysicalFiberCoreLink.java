package com.nokia.oss.mdf.rda.ldma.mediation.level3;

import java.util.Map;

import com.nokia.oss.mdf.rda.ldma.common.LdmaConstants;
import com.nokia.oss.mdf.rda.ldma.mediation.entity.EntityElement;

public class PhysicalFiberCoreLink extends EntityElement {

	private String aTerminationName; 
	private String zTerminationName; 
	public PhysicalFiberCoreLink(Map<String, String> rowMap) {
		super(rowMap);
		aTerminationName = constructATerminationName();
		zTerminationName = constructZTerminationName();
	}

	@Override
	protected String constructName() {
		StringBuilder builder = new StringBuilder();
		builder.append(getRowData().get(LdmaConstants.Level3PHYSICALCOREFILE.COLUMN_A));
		builder.append(LdmaConstants.HYPHEN); 
		builder.append(getRowData().get(LdmaConstants.Level3PHYSICALCOREFILE.COLUMN_B)); 
		return builder.toString();
	}

	@Override
	protected String constructType() {
		return LdmaConstants.Level3EntityType.PHY_FIBER_CORE_LINK;		
	}
	
	@Override
	protected String constructDiscoveredName() {
		return constructName();
	}
	
	@Override
	protected Map<String, String> constructFeatures() {
		Map<String, String> features = getFeatures();
		features.put(LdmaConstants.Features.PhysicalFiberCore[0], 
				LdmaConstants.Level3EntityType.L3_L4_FLOE_END_POINT);
		return features;
	}
	
	protected String constructATerminationName() {
		//NGSNG01-ODF-1/1/1
		//Link Id NGSNG01-DHMJH28-1-F_Core 1-24-Ribbon
		StringBuilder builder = new StringBuilder();
		String linkId = getRowData().get(LdmaConstants.Level3PHYSICALCOREFILE.COLUMN_A);
		String[] tokens = linkId.split("-");
		builder.append(tokens[0]);
		builder.append(LdmaConstants.HYPHEN);
		builder.append(LdmaConstants.Level12EntityType.ODF); 
		builder.append(LdmaConstants.HYPHEN);
		builder.append(getRowData().get(LdmaConstants.Level3PHYSICALCOREFILE.COLUMN_C)); 
		builder.append(getRowData().get(LdmaConstants.Level3PHYSICALCOREFILE.COLUMN_D)); 
		builder.append(getRowData().get(LdmaConstants.Level3PHYSICALCOREFILE.COLUMN_E)); 
		return builder.toString();
	}
	
	protected String constructZTerminationName() {
		StringBuilder builder = new StringBuilder();
		String linkId = getRowData().get(LdmaConstants.Level3PHYSICALCOREFILE.COLUMN_A);
		String[] tokens = linkId.split("-");
		builder.append(tokens[1]);
		builder.append(LdmaConstants.HYPHEN);
		builder.append(LdmaConstants.Level12EntityType.ODF); 
		builder.append(LdmaConstants.HYPHEN);
		builder.append(getRowData().get(LdmaConstants.Level3PHYSICALCOREFILE.COLUMN_F)); 
		builder.append(getRowData().get(LdmaConstants.Level3PHYSICALCOREFILE.COLUMN_G)); 
		builder.append(getRowData().get(LdmaConstants.Level3PHYSICALCOREFILE.COLUMN_H)); 
		return builder.toString();
	}

	public String getaTerminationName() {
		return aTerminationName;
	}

	public void setaTerminationName(String aTerminationName) {
		this.aTerminationName = aTerminationName;
	}

	public String getzTerminationName() {
		return zTerminationName;
	}

	public void setzTerminationName(String zTerminationName) {
		this.zTerminationName = zTerminationName;
	}
}
