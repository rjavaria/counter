package com.nokia.oss.mdf.rda.ldma.mediation.entity;

import java.util.List;
import java.util.Map;

import com.nokia.oss.mdf.rda.ldma.reader.DataFileMap;

public interface IEntityComponent {
	/**
	 * 
	 * @param fileMaps complete(all rows) data of multiple CSV files
	 */
	public void createAll(Map<String, DataFileMap> fileMaps);
	
	/**
	 * 
	 * @param fileMap complete(all rows) data of a CSV file
	 */
	public void createAll(DataFileMap fileMap);
	
	/**
	 * 
	 * @param rowMap one row data of a file record
	 */
	public void create(Map<String, String> rowMap);
	
	/**
	 * 
	 * @param entity
	 * @param rowMap one row data of a file record
	 * @return true/false if component exists or not
	 */
	public boolean doExist(String entity, Map<String, String> rowMap);
	
	/**
	 * 
	 * @return
	 */
	public Map<String, List<EntityElement>> getAll();
	
	/**
	 * 
	 * @param name component unique name
	 * @return String print complete component details
	 */
	public String printComponent(String name);
}
