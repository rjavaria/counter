package com.nokia.oss.mdf.rda.ldma.mediation.entity;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.nokia.oss.mdf.rda.ldma.common.LdmaConstants;
import com.nokia.oss.mdf.rda.ldma.mediation.level3.PhysicalFiberCoreLink;
import com.nokia.oss.mdf.rda.ldma.reader.DataFileMap;

public class L3PhyFiberCoreLinkModel extends L3EntityModel {
//private String linkId;
	
	private List<EntityElement> phyFiberCoreList = new ArrayList<>();

	public L3PhyFiberCoreLinkModel(String linkId) {
		super(linkId);
		getAll().put(LdmaConstants.Level3EntityType.PHY_FIBER_CORE_LINK, phyFiberCoreList);
	}	

	@Override
	public void createAll(DataFileMap fileMap) {
		int numRows = fileMap.getNumberOfRows();		
		for(int i=0; i<numRows; i++) {
			Map<String, String> rowMap = fileMap.getRow(LdmaConstants.ROW+(i+1));
			String linkId = rowMap.get(LdmaConstants.Level3PHYSICALCOREFILE.COLUMN_A);
			if(this.getL3EntityId().equals(linkId)) {
				create(rowMap);
			}
		}
	}
	
	@Override
	public void create(Map<String, String> rowMap) {
		if(doExist(LdmaConstants.Level3EntityType.PHY_FIBER_CORE_LINK, rowMap)) {
			EntityElement phyFiberCore = new PhysicalFiberCoreLink(rowMap);
			phyFiberCore.add(phyFiberCoreList);
		}			
	}
	
	
	@Override
	public boolean doExist(String entity, Map<String, String> rowMap) {
		boolean bExist = true;

			String linkId = rowMap.get(LdmaConstants.Level3PHYSICALCOREFILE.COLUMN_A);
			if(null == linkId || linkId.trim().equals("")) {
				bExist = false;
				}
			else{
				String[] tokens = linkId.split("-");
				if(null == tokens || tokens.equals("")) {
				bExist = false;
				}
			}
			String core = rowMap.get(LdmaConstants.Level3PHYSICALCOREFILE.COLUMN_B);
			String site1Odf = rowMap.get(LdmaConstants.Level3PHYSICALCOREFILE.COLUMN_C);
			String site1OdfTray = rowMap.get(LdmaConstants.Level3PHYSICALCOREFILE.COLUMN_D);
			String site1OdfTrayPort = rowMap.get(LdmaConstants.Level3PHYSICALCOREFILE.COLUMN_E);
			String site2Odf = rowMap.get(LdmaConstants.Level3PHYSICALCOREFILE.COLUMN_F);
			String site2OdfTray = rowMap.get(LdmaConstants.Level3PHYSICALCOREFILE.COLUMN_G);
			String site2OdfTrayPort = rowMap.get(LdmaConstants.Level3PHYSICALCOREFILE.COLUMN_H);
			if(null == core || core.trim().equals("") || core.trim().equals("undefined") || core.trim().equals("null")) {
				bExist = false;
				}
			if(null == site1Odf || site1Odf.trim().equals("") || site1Odf.trim().equals("undefined") || site1Odf.trim().equals("null")) {
				bExist = false;
				}	
			if(null == site1OdfTray || site1OdfTray.trim().equals("") || site1OdfTray.trim().equals("undefined") || site1OdfTray.trim().equals("null")) {
				bExist = false;
				}	
			if(null == site1OdfTrayPort || site1OdfTrayPort.trim().equals("") || site1OdfTrayPort.trim().equals("undefined") || site1OdfTrayPort.trim().equals("null")) {
				bExist = false;
				}	
			if(null == site2Odf || site2Odf.trim().equals("") || site2Odf.trim().equals("undefined") || site2Odf.trim().equals("null")) {
				bExist = false;
				}	
			if(null == site2OdfTray || site2OdfTray.trim().equals("") || site2OdfTray.trim().equals("undefined") || site2OdfTray.trim().equals("null")) {
				bExist = false;
				}	
			if(null == site2OdfTrayPort || site2OdfTrayPort.trim().equals("") || site2OdfTrayPort.trim().equals("undefined") || site2OdfTrayPort.trim().equals("null")) {
				bExist = false;
				}	
			
		
		return bExist;	
	}

	@Override
	public void createAll(Map<String, DataFileMap> fileMaps) {
		// TODO Auto-generated method stub
		
	}
}
