package com.nokia.oss.mdf.rda.ldma.builder.level3;

import com.alu.oss.mdf.rda.metadata.delta.DeltaUpdateEntity;
import com.nokia.oss.mdf.rda.ldma.builder.EntityBuilder;
import com.nokia.oss.mdf.rda.ldma.common.LdmaConstants;
import com.nokia.oss.mdf.rda.ldma.common.LdmaException;
import com.nokia.oss.mdf.rda.ldma.context.ILdmaContext;
import com.nokia.oss.mdf.rda.ldma.mediation.entity.EntityElement;

public class Level3DeltaUpdateEntityBuilder  implements EntityBuilder<DeltaUpdateEntity> {
	@Override
	public DeltaUpdateEntity build(ILdmaContext context) throws LdmaException {
		
		EntityElement entityElement = context.getCurrentEntity();
		String entityType = entityElement.getType();
		if(LdmaConstants.Level3EntityType.PHY_FIBER_CORE_LINK.equals(entityType) ) {
			
			return new DeltaUpdateEntity();
		}
		else {
			String message = "Could not build DeltaInsertEntity. Invalid Level-3 entity type : "+entityType;
			throw new LdmaException(message);
		}
	}
}
