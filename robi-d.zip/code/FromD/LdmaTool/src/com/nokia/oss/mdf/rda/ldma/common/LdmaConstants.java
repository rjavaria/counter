package com.nokia.oss.mdf.rda.ldma.common;

public final class LdmaConstants {
	
	public final static String ROW = "row";
	public final static String HYPHEN = "-";
	public final static String SLASH = "/";
	public final static String UNDER_SCORE = "_";
	
	public final static String FEATURES = "features";
	public final static String EXTRAINFO = "extrainfo";
	public final static String ODF_CHASSIS_NETWORK_NAME = "PASSIVE.net";
	
	public static class OperationType {
		public final static String INSERT = "Insert";
		public final static String UPDATE = "Update";
		public final static String DELETE = "Delete";
	}
	
	public static class LevelType {
		public final static String LEVEL12 = "Level12";
		public final static String LEVEL3 = "Level3";
		public final static String ALL = "AllLevels";
	}
	
	public static class LdmaFileName {
		public final static String LEVEL12FILENAME = "Site with ODF Tray Port Into.csv";
		public final static String LEVEL3PHYFIBERLINK = "Physicalfiberlink.csv";
		public final static String LEVEL3PHYFIBERHHINFO = "Physical Fiber HH info.csv";
		public final static String LEVEL3PHYFIBERCOREINFO = "Physical Fiber core info.csv";
		public final static String LEVEL3MUXLINKSAMPLEDATAREPORT = "Mux Link sample data Report.csv";
	}
	
	public static class LdmaFiles {
		public final static String[] LEVEL12FILES = { "Site with ODF Tray Port Into.csv" };
		public final static String[] LEVEL3FILES = { "Physicalfiberlink.csv",
													 "Physical Fiber HH info.csv",
													 "Physical Fiber core info.csv",
													 //"Mux Link sample data Report.csv",
													 "MUX -ODF sample data.csv"
													};
	}
	
	public static class Level12FILE1 {
		public final static String COLUMN_A = "Site Code";
		public final static String COLUMN_B = "Site Name";
		public final static String COLUMN_C = "ODF Number";
		public final static String COLUMN_D = "Tray No.";
		public final static String COLUMN_E = "Ports";
	}
	
	public static class Level12EntityType {
		public final static String ODF = "ODF";
		public final static String ODF_CHASSIS = "ODF Chassis";
		public final static String ODF_TRAY = "ODF Tray";
		public final static String ODF_TRAYPORT = "ODF Tray Port";
		public final static String ODF_PORT = "ODF Port";
		public final static String L1_L2_FLOE_END_POINT = "LDMA L1/L2";
		public final static String TP = "TP";
	}
	
	public static class Level3EntityType {
		public final static String PHY_FIBER_LINK = "Physical Fiber Link";
		public final static String PHY_FIBER_CORE_LINK = "Physical Fiber Core Link";
		public final static String MUX_ODF_LINK = "MUX-ODF Link";
		public final static String MUX_MUX_LINK = "MUX-MUX link";
		public final static String MICROWAVE_LINK = "Microwave link";
		public final static String L3_L4_FLOE_END_POINT = "LDMA L3/L4"; 
	}
	
	public static class Level3PHYSICALCOREFILE {
		public final static String COLUMN_A = "Physical Fiber Link";
		public final static String COLUMN_B = "Core";
		public final static String COLUMN_C = "Site 1 Odf";
		public final static String COLUMN_D = "Site 1 Odf Tray";
		public final static String COLUMN_E = "Site 1 Odf Tray Port";
		public final static String COLUMN_F = "Site 2 Odf";
		public final static String COLUMN_G = "Site 2 Odf Tray";
		public final static String COLUMN_H = "Site 2 Odf Tray Port";
	}
	//Level3PHYSICALFIBERLINK
	//Link Code,Site 1 Code,Site 1 Name,Site 2 Code,Site 2 Name,Core,Bandwidth,Tx,Rx,Length,PathType,FiberType
	public static class Level3PHYSICALFIBERFILE {
		public final static String COLUMN_A = "Link Code";
		public final static String COLUMN_B = "Site 1 Code";
		public final static String COLUMN_C = "Site 1 Name";
		public final static String COLUMN_D = "Site 2 Code";
		public final static String COLUMN_E = "Site 2 Name";
		public final static String COLUMN_F = "Core";
		public final static String COLUMN_G = "Bandwidth";
		public final static String COLUMN_H = "Tx";
		public final static String COLUMN_I = "Rx";
		public final static String COLUMN_J = "Length";
		public final static String COLUMN_K = "PathType";
		public final static String COLUMN_L = "FiberType";
	}
	//Level3PHYSICALFIBERHH
	//Physical Fiber Link,HH No,Longitude,Latitude,Comment
	public static class Level3PHYSICALFIBERHHFILE {
		public final static String COLUMN_A = "Physical Fiber Link";
		public final static String COLUMN_B = "HH No";
		public final static String COLUMN_C = "Longitude";
		public final static String COLUMN_D = "Latitude";
		public final static String COLUMN_E = "Comment";
	}
	
	//Level3MUXODF
	//Site Code,NE Name (L1),Shelf(L2),Slot(L2),Port(L2),NE Name (L1) Odf,NE Name (L1) Odf Tray,
	//NE Name (L1) Odf Tray Port
	public static class Level3MUXTOODFFILE {
		public final static String COLUMN_A = "Site Code";
		public final static String COLUMN_B = "NE Name (L1)";
		public final static String COLUMN_C = "Shelf(L2)";
		public final static String COLUMN_D = "Slot(L2)";
		public final static String COLUMN_E = "Port(L2)";
		public final static String COLUMN_F = "NE Name (L1) Odf";
		public final static String COLUMN_G = "NE Name (L1) Odf Tray";
		public final static String COLUMN_H = "NE Name (L1) Odf Tray Port";
	}
	
	//Level3MUXMUX
	//Link Id,Site1Code,Site2Code,Site1Name,Site2Name,StmCapacity,Mux1Name,Mux2Name,Mux1Slot,Mux1Port,
	//Mux2Slot,Mux2Port,Mux1Vendor,Mux2Vendor,Protection,LMSPSlot1,LMSPPort1,LMSPSlot2,LMSPPort2,
	//FiberOpticalType,FOTRobiSlot,FOTRobiPort,FOTLease,Date,Status,Link Type,,Commercial Zone,Comments
	
	public static class Level3MUXTOMUXFILE {
		public final static String COLUMN_A = "Link Id";
		public final static String COLUMN_B = "Site1Code";
		public final static String COLUMN_C = "Site2Code";
		public final static String COLUMN_D = "Site1Name";
		public final static String COLUMN_E = "Site2Name";
		public final static String COLUMN_F = "StmCapacity";
		public final static String COLUMN_G = "Mux1Name";
		public final static String COLUMN_H = "Mux2Name";
		public final static String COLUMN_I = "Mux1Slot";
		public final static String COLUMN_J = "Mux1Port";
		public final static String COLUMN_K = "Mux2Slot";
		public final static String COLUMN_L = "Mux2Port";
		public final static String COLUMN_T = "FiberOpticalType";
		public final static String COLUMN_U = "FOTRobiSlot";
		public final static String COLUMN_V = "FOTRobiPort";
		public final static String COLUMN_W = "FOTLease";
	}
	
	public static class Features {
	    public final static String[] ODFTrays = { "TrayPorts","floeEndPoint"};
	    public final static String[] ODFPorts = { "floeEndPoint"};
	    public final static String[] ODFChassis = { "floeEndPoint"};
	    public final static String[] ODFTrayPorts = { "floeEndPoint"};
	    public final static String[] PhysicalFiberCore = { "floeEndPoint"};
	    public final static String[] MuxToOdf = { "floeEndPoint"};
	    public final static String[] PhysicalFiberLink = {  "Cores",
															"Length",
															"PathType",
															"FiberType",
															"PathNumber",
															"FiberType",
															"Comments",
															"Status",	
															"floeEndPoint"
														 };
	}
}
