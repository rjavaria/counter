package com.nokia.oss.mdf.rda.ldma.reader;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.nokia.oss.mdf.rda.ldma.common.LdmaConstants;
import com.nokia.oss.mdf.rda.ldma.common.LdmaException;

public class CSVReader {
	
	public DataFileMap readFile(String fileName) throws LdmaException {
		
		final String METHOD = "DataFileMap::readFile#";
		System.out.println(METHOD+"Reading data file : "+fileName);
		DataFileMap dataFMap = new DataFileMap();
		
		try {
			BufferedReader reader = new BufferedReader(new FileReader(fileName));
			
			String line = "";
			 try {
				int linenum = 0;
				List<String> columnList = new ArrayList<>();
				while ((line = reader.readLine()) != null) 
				 {
					String key = LdmaConstants.ROW + linenum;
					line.trim();
					if(linenum == 0) {
						String[] headers = line.split(",");
						for(String header : headers) {
							columnList.add(header);
						}
					}
					else {
						dataFMap.addRow(key, columnList, line);
			  		}
					linenum ++;
				 }
			} catch (IOException e) {
				throw new LdmaException(e.getMessage());
			}
		} catch (FileNotFoundException e) {
			throw new LdmaException(e.getMessage());
		}
		return dataFMap;
	}
	
	private String[] split(String line) {
		String otherThanQuote = " [^\"] ";
        String quotedString = String.format(" \" %s* \" ", otherThanQuote);
        String regex = String.format("(?x) "+ // enable comments, ignore white spaces
                ",                         "+ // match a comma
                "(?=                       "+ // start positive look ahead
                "  (                       "+ //   start group 1
                "    %s*                   "+ //     match 'otherThanQuote' zero or more times
                "    %s                    "+ //     match 'quotedString'
                "  )*                      "+ //   end group 1 and repeat it zero or more times
                "  %s*                     "+ //   match 'otherThanQuote'
                "  $                       "+ // match the end of the string
                ")                         ", // stop positive look ahead
                otherThanQuote, quotedString, otherThanQuote);

        String[] tokens = line.split(regex, -1);
        return tokens;
	}
}
	
