package com.nokia.oss.mdf.rda.ldma.mediation.entity;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public abstract class L3EntityModel implements IEntityComponent {

	private String l3EntityId;	
	private Map<String, List<EntityElement>> component = new HashMap<>();
	
	public L3EntityModel(String entityId) {
		this.l3EntityId = entityId;
	}
	
	@Override
	public boolean doExist(String entity, Map<String, String> rowMap) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Map<String, List<EntityElement>> getAll() {
		return component;
	}

	@Override
	public String printComponent(String name) {
		StringBuilder builder = new StringBuilder();
		
		Set<String> keys = component.keySet();
		Iterator<String> iter = keys.iterator();
		builder.append("====== "+name +" ======\n");
		while(iter.hasNext())
		{
			String key = iter.next();
			List<EntityElement> entites = component.get(key);
			Iterator<EntityElement> iterEntites = entites.iterator();
			while(iterEntites.hasNext()) {
				EntityElement entity = iterEntites.next();
				builder.append(entity.toString());
			}
		}
		builder.append("=====================");
		return builder.toString();
	}

	public String getL3EntityId() {
		return l3EntityId;
	}

	public void setL3EntityId(String l3EntityId) {
		this.l3EntityId = l3EntityId;
	}
}
