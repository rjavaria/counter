package com.alu.oss.mdf.rda.ldma.main;

import java.io.FileNotFoundException;

import com.alu.oss.mdf.rda.ldma.common.MappingException;
import com.alu.oss.mdf.rda.ldma.server.ILdmaInvoker;
import com.alu.oss.mdf.rda.ldma.server.LdmaInvokerImpl;

public class LdmaRunner {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ILdmaInvoker invoker = new LdmaInvokerImpl();
		
		//delta format - insert, update - mixed opeations?
		
		///insert - Chassis
		
		//-entityName "ODFTrayPort" -operation "Insert" 
		
		
		String operation = args[0];
		String srcFileLocation = args[1];
		String entityName = args[2];
		try {
			invoker.execute(operation, srcFileLocation, entityName);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
