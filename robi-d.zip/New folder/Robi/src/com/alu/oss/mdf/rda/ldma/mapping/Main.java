package com.alu.oss.mdf.rda.ldma.mapping;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.alu.oss.mdf.rda.ldma.common.MappingException;
import com.alu.oss.mdf.rda.ldma.generatedOld.NetworkEntity;
import com.alu.oss.mdf.rda.metadata.delta.DeltaInsertEntity;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		MappingEngine engine = new MappingEngine();
		
		try {
			Map<String, MappingBean> mappingList = engine.parseXml(new FileInputStream(new File("C:\\Data\\ldmamapping.xml")));
			Iterator<String> iter = mappingList.keySet().iterator();
			while(iter.hasNext()) {
				String key = iter.next();
				System.out.println("Entity Name : "+key);
				System.out.println(mappingList.get(key));
				
//				NetworkEntity entity = new NetworkEntity();
//				List<NetworkEntity.Link> links = entity.getLink();
//				Iterator<NetworkEntity.Link> iter1 = links.iterator();
//				while(iter1.hasNext()) {
//					NetworkEntity.Link link = iter1.next();
//					String aTermName = link.getATerminationName();
//					link.setATerminationName(valuefromcsv);
//				}
			}
			
			DeltaInsertEntity entity = new DeltaInsertEntity();
		//	linkEntity
			//entity.setLinkEntity(DeltaInsertEntity.linkEntity);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
