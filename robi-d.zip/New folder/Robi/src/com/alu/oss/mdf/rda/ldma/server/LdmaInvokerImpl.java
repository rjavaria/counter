package com.alu.oss.mdf.rda.ldma.server;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

import com.alu.oss.mdf.rda.ldma.common.MappingException;
import com.alu.oss.mdf.rda.ldma.mapping.MappingBean;
import com.alu.oss.mdf.rda.ldma.mapping.MappingEngine;
import com.alu.oss.mdf.rda.ldma.reader.CSVReader;
import com.alu.oss.mdf.rda.ldma.reader.DataFileMap;

public class LdmaInvokerImpl implements ILdmaInvoker {

	@Override
	public void execute(String operation, String srcFileNameLocation,
			String entityName) throws FileNotFoundException, MappingException {

		/*
		entityName = ALL
		entityName = Link
		*/
		String[] fileList = {"1.csv", "2.csv"};
		
		Map<String, DataFileMap> filesMap = new HashMap<String, DataFileMap>();

		//get all files from srcFileNameLocation
		for(String file : fileList) {
			CSVReader reader = new CSVReader();
			// Reading the CSV file
			DataFileMap fileMap = reader.readFile(file);
			
			filesMap.put(file, fileMap);
		}
		
		//Read the mapping file
		Map<String, MappingBean> mappingList = MappingEngine.getInstance().parseXml(new FileInputStream(new File("C:\\Data\\ldmamapping.xml")));
		
		MappingBean linkMappingBean = mappingList.get("LINK");
		
		Map<String, String> mappedAttr = linkMappingBean.getMapAttrs();
		
		
		//MappingEngine.getInstance().map 
		
		
		//OutputStream output = reader.read(io);
		
		//Map excel o/p to MDF delta format
		
		
		//Build the MDF delta objects from mapping
		
		//Generate xml based on operation name
		
	}
}
